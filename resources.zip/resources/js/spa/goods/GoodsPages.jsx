import React from 'react';

function Card({ title, text }) {
  return <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm"><h2 className="text-lg font-semibold text-slate-900">{title}</h2><p className="mt-2 text-sm text-slate-500">{text}</p></div>;
}

export function GoodsHomePage({ Layout }) {
  return <Layout><div className="mx-auto grid max-w-5xl gap-4 p-6 md:grid-cols-3"><Card title="Goods Index" text="React + Tailwind replacement for backend/goods/index.blade.php" /><Card title="Goods Create" text="React + Tailwind replacement for backend/goods/create.blade.php" /><Card title="Goods Edit" text="React + Tailwind replacement for backend/goods/edit.blade.php" /></div></Layout>;
}
