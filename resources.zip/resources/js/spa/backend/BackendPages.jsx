import React, { useEffect, useState } from 'react';
import axios from 'axios';

const xhrJson = { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' };

function Shell({ Layout, title, children }) {
    return (
        <Layout>
            <div className="mx-auto max-w-6xl space-y-6 p-6">
                <h1 className="text-2xl font-bold text-slate-900">{title}</h1>
                {children}
            </div>
        </Layout>
    );
}

export function BackendDashboardPage({ Layout }) {
    const [data, setData] = useState(null);
    useEffect(() => {
        axios.get('/dashboard', { headers: xhrJson }).then((r) => setData(r.data?.data || {}));
    }, []);
    return (
        <Shell Layout={Layout} title="Backend Dashboard">
            <div className="rounded border bg-white p-4 text-xs">
                <pre>{JSON.stringify(data, null, 2)}</pre>
            </div>
        </Shell>
    );
}

export function BackendDashboardTablePage({ Layout }) {
    const [term, setTerm] = useState('monthly');
    const [rows, setRows] = useState([]);
    const load = async (t) => {
        const { data } = await axios.get(`/dashboardUpdate/${t}`, { headers: xhrJson });
        setRows(data?.data?.collection_summary || []);
    };
    useEffect(() => { load(term); }, []); // eslint-disable-line react-hooks/exhaustive-deps
    return (
        <Shell Layout={Layout} title="Backend Dashboard Table">
            <div className="flex gap-2">
                {['daily', 'weekly', 'monthly', 'yearly'].map((t) => (
                    <button key={t} className={`rounded px-3 py-1 text-sm ${term === t ? 'bg-blue-600 text-white' : 'border'}`} onClick={() => { setTerm(t); load(t); }}>
                        {t}
                    </button>
                ))}
            </div>
            <div className="rounded border bg-white p-4 text-sm">
                {Array.isArray(rows) && rows.length ? rows.map((r, i) => <div key={i} className="border-b py-2">{JSON.stringify(r)}</div>) : <p className="text-slate-500">No summary rows.</p>}
            </div>
        </Shell>
    );
}

export function BackendDashboardPdfPage({ Layout }) {
    return (
        <Shell Layout={Layout} title="Backend Dashboard PDF">
            <div className="rounded border bg-white p-4 text-sm">
                <a href="/dashboard/export-pdf" className="rounded bg-blue-600 px-3 py-2 text-white">Download Dashboard PDF</a>
            </div>
        </Shell>
    );
}

export function BackendMasterPage({ Layout }) {
    return <Shell Layout={Layout} title="Backend Master"><div className="rounded border bg-white p-4 text-sm">Backend master SPA shell.</div></Shell>;
}

export function BackendMenuAutocompletePage({ Layout }) {
    const [q, setQ] = useState('');
    const [rows, setRows] = useState([]);
    const search = async (value) => {
        const { data } = await axios.post('/search-menu-data', { search: value }, { headers: xhrJson });
        setRows(Array.isArray(data) ? data : []);
    };
    return (
        <Shell Layout={Layout} title="Backend Menu Autocomplete">
            <input className="w-full rounded border px-3 py-2" value={q} onChange={(e) => { const v = e.target.value; setQ(v); search(v); }} placeholder="Search menu..." />
            <div className="rounded border bg-white p-4 text-sm">
                {rows.map((r, i) => <div key={i} className="border-b py-2">{r.title} - {r.route_name}</div>)}
                {!rows.length ? <p className="text-slate-500">Type to search menus.</p> : null}
            </div>
        </Shell>
    );
}
