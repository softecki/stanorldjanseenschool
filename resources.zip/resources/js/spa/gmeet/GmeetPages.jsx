import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link, useNavigate, useParams } from 'react-router-dom';

const xhrJson = { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' };

export function GmeetListPage({ Layout }) {
  const [rows, setRows] = useState([]);
  const [meta, setMeta] = useState({});
  const [filters, setFilters] = useState({ class: '', section: '', subject: '' });
  const [err, setErr] = useState('');

  const load = async () => {
    try {
      const r = await axios.get('/liveclass/gmeet', { headers: xhrJson });
      setRows(r.data?.data?.data || r.data?.data || []);
      setMeta(r.data?.meta || {});
    } catch (ex) { setErr(ex.response?.data?.message || 'Failed to load.'); }
  };
  useEffect(() => { load(); }, []);

  const search = async (e) => {
    e.preventDefault();
    try {
      const r = await axios.post('/liveclass/gmeet/search', filters, { headers: xhrJson });
      setRows(r.data?.data?.data || r.data?.data || []);
      setMeta((m) => ({ ...m, ...(r.data?.meta || {}) }));
    } catch (ex) { setErr(ex.response?.data?.message || 'Search failed.'); }
  };

  const remove = async (id) => {
    if (!window.confirm('Delete this meeting?')) return;
    try { await axios.delete(`/liveclass/gmeet/delete/${id}`, { headers: xhrJson }); load(); }
    catch (ex) { setErr(ex.response?.data?.message || 'Delete failed.'); }
  };

  return <Layout><div className="mx-auto max-w-7xl space-y-4 p-6">
    <div className="flex items-center justify-between">
      <h1 className="text-2xl font-bold text-slate-900">{meta.title || 'Gmeet'}</h1>
      <Link to="/liveclass/gmeet/create" className="rounded bg-blue-600 px-4 py-2 text-sm font-medium text-white">Create</Link>
    </div>
    <form onSubmit={search} className="grid gap-2 rounded-xl border bg-white p-4 md:grid-cols-4">
      <select className="rounded border px-3 py-2" value={filters.class} onChange={(e) => setFilters({ ...filters, class: e.target.value })}>
        <option value="">Class</option>
        {(meta.classes || []).map((c) => { const v = c.class?.id || c.id; const n = c.class?.name || c.name; return <option key={v} value={v}>{n}</option>; })}
      </select>
      <input className="rounded border px-3 py-2" placeholder="Section id" value={filters.section} onChange={(e) => setFilters({ ...filters, section: e.target.value })} />
      <input className="rounded border px-3 py-2" placeholder="Subject id" value={filters.subject} onChange={(e) => setFilters({ ...filters, subject: e.target.value })} />
      <button className="rounded bg-slate-800 px-4 py-2 text-sm font-medium text-white">Search</button>
    </form>
    {err ? <p className="text-sm text-red-600">{err}</p> : null}
    <div className="overflow-hidden rounded-xl border bg-white">
      <table className="min-w-full text-sm"><thead className="bg-slate-50 text-left text-xs uppercase text-slate-600"><tr><th className="px-4 py-3">Title</th><th className="px-4 py-3">Class/Section</th><th className="px-4 py-3">Time</th><th className="px-4 py-3 text-right">Actions</th></tr></thead>
      <tbody>{rows.map((r)=><tr key={r.id} className="border-t"><td className="px-4 py-3"><a className="text-blue-700" href={r.gmeet_link} target="_blank" rel="noreferrer">{r.title || `Meeting #${r.id}`}</a></td><td className="px-4 py-3">{r.classes_id}/{r.section_id}</td><td className="px-4 py-3">{r.start} - {r.end}</td><td className="px-4 py-3 text-right"><Link className="mr-3 text-blue-600" to={`/liveclass/gmeet/${r.id}/edit`}>Edit</Link><button onClick={()=>remove(r.id)} className="text-red-600">Delete</button></td></tr>)}</tbody></table>
    </div>
  </div></Layout>;
}

export function GmeetFormPage({ Layout, edit = false }) {
  const { id } = useParams();
  const nav = useNavigate();
  const [meta, setMeta] = useState({});
  const [form, setForm] = useState({ title: '', gmeet_link: '', class: '', section: '', subject: '', start: '', end: '', status: 1, description: '' });
  const [err, setErr] = useState('');

  useEffect(() => {
    const url = edit ? `/liveclass/gmeet/edit/${id}` : '/liveclass/gmeet/create';
    axios.get(url, { headers: xhrJson }).then((r) => {
      setMeta(r.data?.meta || {});
      if (edit) {
        const g = r.data?.data?.gmeet || {};
        setForm({ title: g.title || '', gmeet_link: g.gmeet_link || '', class: g.classes_id || '', section: g.section_id || '', subject: g.subject_id || '', start: g.start || '', end: g.end || '', status: Number(g.status ?? 1), description: g.description || '' });
      }
    }).catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));
  }, [edit, id]);

  const submit = async (e) => {
    e.preventDefault();
    try {
      if (edit) await axios.put(`/liveclass/gmeet/update/${id}`, form, { headers: xhrJson });
      else await axios.post('/liveclass/gmeet/store', form, { headers: xhrJson });
      nav('/liveclass/gmeet');
    } catch (ex) { setErr(ex.response?.data?.message || 'Save failed.'); }
  };

  return <Layout><div className="mx-auto max-w-3xl space-y-4 p-6">
    <h1 className="text-2xl font-bold text-slate-900">{meta.title || (edit ? 'Edit gmeet' : 'Create gmeet')}</h1>
    {err ? <p className="text-sm text-red-600">{err}</p> : null}
    <form onSubmit={submit} className="grid gap-3 rounded-xl border bg-white p-6">
      <input className="rounded border px-3 py-2" placeholder="Title" value={form.title} onChange={(e)=>setForm({ ...form, title: e.target.value })} required />
      <input className="rounded border px-3 py-2" placeholder="Gmeet link" value={form.gmeet_link} onChange={(e)=>setForm({ ...form, gmeet_link: e.target.value })} required />
      <select className="rounded border px-3 py-2" value={form.class} onChange={(e)=>setForm({ ...form, class: e.target.value })} required>
        <option value="">Select class</option>
        {(meta.classes || []).map((c) => { const v = c.class?.id || c.id; const n = c.class?.name || c.name; return <option key={v} value={v}>{n}</option>; })}
      </select>
      <input className="rounded border px-3 py-2" placeholder="Section id" value={form.section} onChange={(e)=>setForm({ ...form, section: e.target.value })} required />
      <input className="rounded border px-3 py-2" placeholder="Subject id (optional)" value={form.subject} onChange={(e)=>setForm({ ...form, subject: e.target.value })} />
      <div className="grid gap-3 md:grid-cols-2"><input type="datetime-local" className="rounded border px-3 py-2" value={form.start} onChange={(e)=>setForm({ ...form, start: e.target.value })} required /><input type="datetime-local" className="rounded border px-3 py-2" value={form.end} onChange={(e)=>setForm({ ...form, end: e.target.value })} required /></div>
      <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={!!Number(form.status)} onChange={(e)=>setForm({ ...form, status: e.target.checked ? 1 : 0 })} /> Active</label>
      <textarea className="rounded border px-3 py-2" placeholder="Description" value={form.description} onChange={(e)=>setForm({ ...form, description: e.target.value })} />
      <div className="flex gap-2"><button className="rounded bg-blue-600 px-4 py-2 text-white">Save</button><Link to="/liveclass/gmeet" className="rounded border px-4 py-2">Cancel</Link></div>
    </form>
  </div></Layout>;
}
