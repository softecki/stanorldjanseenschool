import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link, useNavigate, useParams } from 'react-router-dom';

const xhrJson = { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' };

function Shell({ Layout, children }) {
    return (
        <Layout>
            <div className="mx-auto max-w-4xl space-y-6 p-6">{children}</div>
        </Layout>
    );
}

function paginateRows(r) {
    const p = r.data?.data;
    if (Array.isArray(p?.data)) return p.data;
    if (Array.isArray(p)) return p;
    return [];
}

/* --- Notice board --- */

export function NoticeBoardListPage({ Layout }) {
    const [rows, setRows] = useState([]);
    const [meta, setMeta] = useState({});
    const [err, setErr] = useState('');
    const load = () =>
        axios
            .get('/communication/notice-board', { headers: xhrJson })
            .then((r) => {
                setRows(paginateRows(r));
                setMeta(r.data?.meta ?? {});
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));

    useEffect(() => {
        load();
    }, []);

    const remove = async (id) => {
        if (!window.confirm('Delete this notice?')) return;
        try {
            await axios.delete(`/communication/notice-board/delete/${id}`, { headers: xhrJson });
            load();
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Delete failed.');
        }
    };

    return (
        <Shell Layout={Layout}>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900">{meta.title || 'Notice board'}</h1>
                </div>
                <Link
                    to="/communication/notice-board/create"
                    className="inline-flex rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
                >
                    Create
                </Link>
            </div>
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
                <table className="min-w-full divide-y divide-slate-200 text-sm">
                    <thead className="bg-slate-50 text-left text-xs font-semibold uppercase text-slate-600">
                        <tr>
                            <th className="px-4 py-3">Title</th>
                            <th className="px-4 py-3 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {rows.map((row) => (
                            <tr key={row.id} className="hover:bg-slate-50/80">
                                <td className="px-4 py-3 font-medium text-slate-900">{row.title}</td>
                                <td className="px-4 py-3 text-right">
                                    <Link className="mr-3 font-medium text-blue-600 hover:text-blue-800" to={`/communication/notice-board/${row.id}/edit`}>
                                        Edit
                                    </Link>
                                    <Link className="mr-3 font-medium text-slate-600 hover:text-slate-800" to={`/communication/notice-board/${row.id}/translate`}>
                                        Translate
                                    </Link>
                                    <button type="button" className="text-sm text-red-600 hover:text-red-800" onClick={() => remove(row.id)}>
                                        Delete
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                {!rows.length ? <p className="px-4 py-8 text-center text-sm text-slate-500">No notices yet.</p> : null}
            </div>
        </Shell>
    );
}

export function NoticeBoardFormPage({ Layout, edit = false }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [meta, setMeta] = useState({});
    const [roles, setRoles] = useState([]);
    const [form, setForm] = useState({
        title: '',
        publish_date: '',
        date: '',
        description: '',
        status: 1,
        is_visible_web: 0,
        visible_to: [],
    });
    const [file, setFile] = useState(null);
    const [err, setErr] = useState('');
    const [busy, setBusy] = useState(false);

    useEffect(() => {
        if (!edit) {
            axios.get('/communication/notice-board/create', { headers: xhrJson }).then((r) => {
                setMeta(r.data?.meta || {});
                setRoles(r.data?.meta?.roles || []);
            });
            return;
        }
        axios
            .get(`/communication/notice-board/edit/${id}`, { headers: xhrJson })
            .then((r) => {
                setMeta(r.data?.meta || {});
                const nb = r.data?.data?.['notice-board'] ?? r.data?.data;
                setRoles(r.data?.data?.roles || r.data?.meta?.roles || []);
                setForm({
                    title: nb?.title ?? '',
                    publish_date: nb?.publish_date ? nb.publish_date.slice(0, 16) : '',
                    date: nb?.date ?? '',
                    description: nb?.description ?? '',
                    status: nb?.status ?? 1,
                    is_visible_web: nb?.is_visible_web ? 1 : 0,
                    visible_to: Array.isArray(nb?.visible_to) ? nb.visible_to : [],
                });
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));
    }, [edit, id]);

    const toggleRole = (rid) => {
        const id = Number(rid);
        setForm((f) => {
            const set = new Set((f.visible_to || []).map(Number));
            if (set.has(id)) set.delete(id);
            else set.add(id);
            return { ...f, visible_to: [...set] };
        });
    };

    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        setBusy(true);
        try {
            const fd = new FormData();
            fd.append('title', form.title);
            fd.append('publish_date', form.publish_date);
            fd.append('date', form.date);
            fd.append('description', form.description);
            fd.append('status', String(form.status));
            fd.append('is_visible_web', String(form.is_visible_web));
            form.visible_to.forEach((v) => fd.append('visible_to[]', v));
            if (file) fd.append('attachment', file);
            if (edit) {
                fd.append('_method', 'PUT');
                await axios.post(`/communication/notice-board/update/${id}`, fd, {
                    headers: { ...xhrJson, 'Content-Type': 'multipart/form-data' },
                });
            } else {
                await axios.post('/communication/notice-board/store', fd, {
                    headers: { ...xhrJson, 'Content-Type': 'multipart/form-data' },
                });
            }
            nav('/communication/notice-board');
        } catch (ex) {
            const msg = ex.response?.data?.message || ex.response?.data?.errors;
            setErr(typeof msg === 'object' ? JSON.stringify(msg) : msg || 'Save failed.');
        } finally {
            setBusy(false);
        }
    };

    return (
        <Shell Layout={Layout}>
            <h1 className="text-2xl font-bold text-slate-900">{meta.title || (edit ? 'Edit notice' : 'Create notice')}</h1>
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <form onSubmit={submit} className="grid max-w-2xl gap-4 rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
                <label className="text-sm font-medium text-slate-700">
                    Title
                    <input
                        className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                        value={form.title}
                        onChange={(e) => setForm({ ...form, title: e.target.value })}
                        required
                    />
                </label>
                <label className="text-sm font-medium text-slate-700">
                    Publish date
                    <input
                        type="datetime-local"
                        className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                        value={form.publish_date}
                        onChange={(e) => setForm({ ...form, publish_date: e.target.value })}
                        required
                    />
                </label>
                <label className="text-sm font-medium text-slate-700">
                    Date
                    <input
                        type="date"
                        className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                        value={form.date}
                        onChange={(e) => setForm({ ...form, date: e.target.value })}
                        required
                    />
                </label>
                <label className="text-sm font-medium text-slate-700">
                    Description
                    <textarea
                        className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                        rows={5}
                        value={form.description}
                        onChange={(e) => setForm({ ...form, description: e.target.value })}
                        required
                    />
                </label>
                <label className="text-sm font-medium text-slate-700">
                    Attachment
                    <input type="file" accept="image/*" className="mt-1 w-full text-sm" onChange={(e) => setFile(e.target.files?.[0] || null)} />
                </label>
                <label className="text-sm font-medium text-slate-700">
                    Status
                    <select className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2" value={form.status} onChange={(e) => setForm({ ...form, status: Number(e.target.value) })}>
                        <option value={1}>Active</option>
                        <option value={0}>Inactive</option>
                    </select>
                </label>
                <label className="text-sm font-medium text-slate-700">
                    Visible on website
                    <select
                        className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                        value={form.is_visible_web}
                        onChange={(e) => setForm({ ...form, is_visible_web: Number(e.target.value) })}
                    >
                        <option value={1}>Yes</option>
                        <option value={0}>No</option>
                    </select>
                </label>
                <div>
                    <p className="text-sm font-medium text-slate-700">Visible to roles</p>
                    <div className="mt-2 flex flex-wrap gap-3">
                        {roles.map((r) => (
                            <label key={r.id} className="flex items-center gap-2 text-sm text-slate-700">
                                <input type="checkbox" checked={form.visible_to.includes(r.id)} onChange={() => toggleRole(r.id)} />
                                {r.name}
                            </label>
                        ))}
                    </div>
                </div>
                <div className="flex gap-2">
                    <button type="submit" disabled={busy} className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-50">
                        {busy ? 'Saving…' : 'Save'}
                    </button>
                    <Link to="/communication/notice-board" className="rounded-md border border-slate-300 px-4 py-2 text-sm text-slate-700">
                        Cancel
                    </Link>
                </div>
            </form>
        </Shell>
    );
}

export function NoticeBoardTranslatePage({ Layout }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [meta, setMeta] = useState({});
    const [langs, setLangs] = useState([]);
    const [titles, setTitles] = useState({});
    const [descriptions, setDescriptions] = useState({});
    const [err, setErr] = useState('');
    const [busy, setBusy] = useState(false);

    useEffect(() => {
        axios
            .get(`/communication/notice-board/translate/${id}`, { headers: xhrJson })
            .then((r) => {
                setMeta(r.data?.meta || {});
                const langsList = r.data?.data?.languages || [];
                setLangs(langsList);
                const tr = r.data?.data?.translates || {};
                const nb = r.data?.data?.notice_board;
                const t = {};
                const d = {};
                langsList.forEach((l) => {
                    const code = l.code;
                    const row = tr[code]?.[0];
                    t[code] = row?.title ?? nb?.title ?? '';
                    d[code] = row?.description ?? nb?.description ?? '';
                });
                setTitles(t);
                setDescriptions(d);
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));
    }, [id]);

    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        setBusy(true);
        try {
            const fd = new FormData();
            langs.forEach((l) => {
                const code = l.code || String(l.id);
                fd.append(`title[${code}]`, titles[code] ?? '');
                fd.append(`description[${code}]`, descriptions[code] ?? '');
            });
            fd.append('_method', 'PUT');
            await axios.post(`/communication/notice-board/translate/update/${id}`, fd, {
                headers: { ...xhrJson, 'Content-Type': 'multipart/form-data' },
            });
            nav('/communication/notice-board');
        } catch (ex) {
            const msg = ex.response?.data?.message || ex.response?.data?.errors;
            setErr(typeof msg === 'object' ? JSON.stringify(msg) : msg || 'Save failed.');
        } finally {
            setBusy(false);
        }
    };

    return (
        <Shell Layout={Layout}>
            <h1 className="text-2xl font-bold text-slate-900">{meta.title || 'Translate notice'}</h1>
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <form onSubmit={submit} className="grid max-w-2xl gap-4 rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
                {langs.map((l) => {
                    const code = l.code || String(l.id);
                    return (
                        <div key={code} className="space-y-2 rounded-lg border border-slate-100 p-3">
                            <p className="text-sm font-semibold text-slate-800">{l.name || code}</p>
                            <input
                                className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
                                placeholder="Title"
                                value={titles[code] ?? ''}
                                onChange={(e) => setTitles({ ...titles, [code]: e.target.value })}
                            />
                            <textarea
                                className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
                                placeholder="Description"
                                rows={3}
                                value={descriptions[code] ?? ''}
                                onChange={(e) => setDescriptions({ ...descriptions, [code]: e.target.value })}
                            />
                        </div>
                    );
                })}
                <div className="flex gap-2">
                    <button type="submit" disabled={busy} className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-50">
                        {busy ? 'Saving…' : 'Save translations'}
                    </button>
                    <Link to="/communication/notice-board" className="rounded-md border border-slate-300 px-4 py-2 text-sm text-slate-700">
                        Cancel
                    </Link>
                </div>
            </form>
        </Shell>
    );
}

/* --- SMS templates --- */

export function SmsTemplateListPage({ Layout }) {
    const [rows, setRows] = useState([]);
    const [meta, setMeta] = useState({});
    const [err, setErr] = useState('');
    const load = () =>
        axios
            .get('/communication/template', { headers: xhrJson })
            .then((r) => {
                setRows(paginateRows(r));
                setMeta(r.data?.meta ?? {});
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));

    useEffect(() => {
        load();
    }, []);

    const remove = async (tid) => {
        if (!window.confirm('Delete this template?')) return;
        try {
            await axios.delete(`/communication/template/delete/${tid}`, { headers: xhrJson });
            load();
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Delete failed.');
        }
    };

    const runDelivery = async () => {
        try {
            const { data } = await axios.get('/communication/template/delivery', { headers: xhrJson });
            alert(data?.message || 'Delivery sync completed.');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Delivery failed.');
        }
    };

    return (
        <Shell Layout={Layout}>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900">{meta.title || 'SMS / Mail templates'}</h1>
                </div>
                <div className="flex flex-wrap gap-2">
                    <button type="button" onClick={runDelivery} className="rounded-md border border-slate-300 px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">
                        Sync delivery reports
                    </button>
                    <Link to="/communication/template/create" className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700">
                        Create
                    </Link>
                </div>
            </div>
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
                <table className="min-w-full divide-y divide-slate-200 text-sm">
                    <thead className="bg-slate-50 text-left text-xs font-semibold uppercase text-slate-600">
                        <tr>
                            <th className="px-4 py-3">Title</th>
                            <th className="px-4 py-3">Type</th>
                            <th className="px-4 py-3 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {rows.map((row) => (
                            <tr key={row.id} className="hover:bg-slate-50/80">
                                <td className="px-4 py-3 font-medium text-slate-900">{row.title}</td>
                                <td className="px-4 py-3 uppercase">{row.type}</td>
                                <td className="px-4 py-3 text-right">
                                    <Link className="mr-3 font-medium text-blue-600 hover:text-blue-800" to={`/communication/template/${row.id}/edit`}>
                                        Edit
                                    </Link>
                                    <button type="button" className="text-sm text-red-600 hover:text-red-800" onClick={() => remove(row.id)}>
                                        Delete
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                {!rows.length ? <p className="px-4 py-8 text-center text-sm text-slate-500">No templates yet.</p> : null}
            </div>
        </Shell>
    );
}

export function SmsTemplateFormPage({ Layout, edit = false }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [meta, setMeta] = useState({});
    const [form, setForm] = useState({ title: '', type: 'sms', sms_description: '', mail_description: '' });
    const [file, setFile] = useState(null);
    const [err, setErr] = useState('');
    const [busy, setBusy] = useState(false);

    useEffect(() => {
        if (!edit) {
            axios.get('/communication/template/create', { headers: xhrJson }).then((r) => setMeta(r.data?.meta || {}));
            return;
        }
        axios
            .get(`/communication/template/edit/${id}`, { headers: xhrJson })
            .then((r) => {
                setMeta(r.data?.meta || {});
                const t = r.data?.data?.template ?? r.data?.data;
                setForm({
                    title: t?.title ?? '',
                    type: t?.type ?? 'sms',
                    sms_description: t?.sms_description ?? '',
                    mail_description: t?.mail_description ?? '',
                });
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));
    }, [edit, id]);

    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        setBusy(true);
        try {
            const fd = new FormData();
            fd.append('title', form.title);
            fd.append('type', form.type);
            if (form.type === 'sms') fd.append('sms_description', form.sms_description);
            else {
                fd.append('mail_description', form.mail_description);
                if (file) fd.append('attachment', file);
            }
            if (edit) {
                fd.append('_method', 'PUT');
                await axios.post(`/communication/template/update/${id}`, fd, {
                    headers: { ...xhrJson, 'Content-Type': 'multipart/form-data' },
                });
            } else {
                await axios.post('/communication/template/store', fd, {
                    headers: { ...xhrJson, 'Content-Type': 'multipart/form-data' },
                });
            }
            nav('/communication/template');
        } catch (ex) {
            const msg = ex.response?.data?.message || ex.response?.data?.errors;
            setErr(typeof msg === 'object' ? JSON.stringify(msg) : msg || 'Save failed.');
        } finally {
            setBusy(false);
        }
    };

    return (
        <Shell Layout={Layout}>
            <h1 className="text-2xl font-bold text-slate-900">{meta.title || (edit ? 'Edit template' : 'Create template')}</h1>
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <form onSubmit={submit} className="grid max-w-2xl gap-4 rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
                <label className="text-sm font-medium text-slate-700">
                    Title
                    <input
                        className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                        value={form.title}
                        onChange={(e) => setForm({ ...form, title: e.target.value })}
                        required
                    />
                </label>
                <label className="text-sm font-medium text-slate-700">
                    Type
                    <select className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
                        <option value="sms">SMS</option>
                        <option value="mail">Mail</option>
                    </select>
                </label>
                {form.type === 'sms' ? (
                    <label className="text-sm font-medium text-slate-700">
                        SMS body
                        <textarea
                            className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                            rows={4}
                            value={form.sms_description}
                            onChange={(e) => setForm({ ...form, sms_description: e.target.value })}
                            required
                        />
                    </label>
                ) : (
                    <>
                        <label className="text-sm font-medium text-slate-700">
                            Mail body
                            <textarea
                                className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                                rows={4}
                                value={form.mail_description}
                                onChange={(e) => setForm({ ...form, mail_description: e.target.value })}
                                required
                            />
                        </label>
                        <label className="text-sm font-medium text-slate-700">
                            Attachment
                            <input type="file" className="mt-1 w-full text-sm" onChange={(e) => setFile(e.target.files?.[0] || null)} />
                        </label>
                    </>
                )}
                <div className="flex gap-2">
                    <button type="submit" disabled={busy} className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-50">
                        {busy ? 'Saving…' : 'Save'}
                    </button>
                    <Link to="/communication/template" className="rounded-md border border-slate-300 px-4 py-2 text-sm text-slate-700">
                        Cancel
                    </Link>
                </div>
            </form>
        </Shell>
    );
}

/* --- SMS / Mail log --- */

export function SmsMailListPage({ Layout }) {
    const [rows, setRows] = useState([]);
    const [meta, setMeta] = useState({});
    const [err, setErr] = useState('');
    useEffect(() => {
        axios
            .get('/communication/smsmail', { headers: xhrJson })
            .then((r) => {
                setRows(paginateRows(r));
                setMeta(r.data?.meta ?? {});
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));
    }, []);

    return (
        <Shell Layout={Layout}>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900">{meta.title || 'SMS / Mail log'}</h1>
                    <p className="text-sm text-slate-500">Tracking rows from sms_tracking.</p>
                </div>
                <div className="flex flex-wrap gap-2">
                    <Link to="/communication/smsmail/campaign" className="rounded-md border border-slate-300 px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">
                        Campaign
                    </Link>
                    <Link to="/communication/smsmail/create" className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700">
                        Create send
                    </Link>
                </div>
            </div>
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-sm">
                <table className="min-w-full divide-y divide-slate-200 text-xs">
                    <thead className="bg-slate-50 text-left font-semibold uppercase text-slate-600">
                        <tr>
                            <th className="px-3 py-2">To</th>
                            <th className="px-3 py-2">Status</th>
                            <th className="px-3 py-2">Message</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {rows.map((row) => (
                            <tr key={row.id} className="hover:bg-slate-50/80">
                                <td className="px-3 py-2 font-mono">{row.to}</td>
                                <td className="px-3 py-2">{row.status_name}</td>
                                <td className="max-w-xs truncate px-3 py-2">{row.sms}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                {!rows.length ? <p className="px-4 py-8 text-center text-sm text-slate-500">No rows yet.</p> : null}
            </div>
        </Shell>
    );
}

export function SmsMailCreatePage({ Layout }) {
    const nav = useNavigate();
    const [meta, setMeta] = useState({});
    const [roles, setRoles] = useState([]);
    const [form, setForm] = useState({
        title: 'Bulk SMS',
        type: 'sms',
        user_type: 'role',
        role_ids: '',
        sms_description: '',
    });
    const [excel, setExcel] = useState(null);
    const [err, setErr] = useState('');
    const [busy, setBusy] = useState(false);

    useEffect(() => {
        axios.get('/communication/smsmail/create', { headers: xhrJson }).then((r) => {
            setMeta(r.data?.meta || {});
            setRoles(r.data?.meta?.roles || []);
        });
    }, []);

    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        setBusy(true);
        try {
            const fd = new FormData();
            fd.append('title', form.title);
            fd.append('type', form.type);
            fd.append('user_type', form.user_type);
            fd.append('role_ids', form.role_ids);
            fd.append('sms_description', form.sms_description);
            if (excel) fd.append('excel_file', excel);
            await axios.post('/communication/smsmail/store', fd, {
                headers: { ...xhrJson, 'Content-Type': 'multipart/form-data' },
            });
            nav('/communication/smsmail');
        } catch (ex) {
            const msg = ex.response?.data?.message || ex.response?.data?.errors || ex.response?.data;
            setErr(typeof msg === 'object' ? JSON.stringify(msg) : msg || 'Send failed.');
        } finally {
            setBusy(false);
        }
    };

    return (
        <Shell Layout={Layout}>
            <h1 className="text-2xl font-bold text-slate-900">{meta.title || 'Send SMS'}</h1>
            <p className="text-sm text-slate-500">
                Upload Excel (optional) for personalized SMS, or use role targeting. For template, use{' '}
                <a href="/communication/smsmail/download-template" className="text-blue-600 hover:underline">
                    download template
                </a>
                .
            </p>
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <form onSubmit={submit} className="grid max-w-2xl gap-4 rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
                <label className="text-sm font-medium text-slate-700">
                    Title
                    <input className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required />
                </label>
                <label className="text-sm font-medium text-slate-700">
                    Role (comma-separated IDs allowed)
                    <input
                        className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                        value={form.role_ids}
                        onChange={(e) => setForm({ ...form, role_ids: e.target.value })}
                        placeholder="e.g. 1"
                    />
                </label>
                <label className="text-sm font-medium text-slate-700">
                    SMS message ({'{name}'}, {'{balance}'})
                    <textarea
                        className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                        rows={4}
                        value={form.sms_description}
                        onChange={(e) => setForm({ ...form, sms_description: e.target.value })}
                        required
                    />
                </label>
                <label className="text-sm font-medium text-slate-700">
                    Excel file (optional)
                    <input type="file" accept=".xlsx,.xls,.csv" className="mt-1 w-full text-sm" onChange={(e) => setExcel(e.target.files?.[0] || null)} />
                </label>
                <p className="text-xs text-slate-500">Available roles: {roles.map((r) => `${r.name} (${r.id})`).join(', ') || '—'}</p>
                <div className="flex gap-2">
                    <button type="submit" disabled={busy} className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-50">
                        {busy ? 'Sending…' : 'Send'}
                    </button>
                    <Link to="/communication/smsmail" className="rounded-md border border-slate-300 px-4 py-2 text-sm text-slate-700">
                        Cancel
                    </Link>
                </div>
            </form>
        </Shell>
    );
}

export function SmsCampaignPage({ Layout }) {
    const [data, setData] = useState(null);
    const [meta, setMeta] = useState({});
    const [err, setErr] = useState('');
    const [msg, setMsg] = useState('');
    const load = () =>
        axios
            .get('/communication/smsmail/campaign', { headers: xhrJson })
            .then((r) => {
                setData(r.data?.data || null);
                setMeta(r.data?.meta || {});
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));

    useEffect(() => {
        load();
    }, []);

    const send = async () => {
        setMsg('');
        try {
            const { data: r } = await axios.post('/communication/smsmail/campaign/send', new FormData(), { headers: xhrJson });
            setMsg(r?.message || 'Request completed.');
            load();
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Send failed.');
        }
    };

    const retry = async () => {
        setMsg('');
        try {
            const { data: r } = await axios.post('/communication/smsmail/campaign/retry', new FormData(), { headers: xhrJson });
            setMsg(r?.message || 'Retry completed.');
            load();
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Retry failed.');
        }
    };

    return (
        <Shell Layout={Layout}>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900">{meta.title || 'SMS campaign'}</h1>
                </div>
                <Link to="/communication/smsmail" className="text-sm text-blue-600 hover:text-blue-800">
                    Back to log
                </Link>
            </div>
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            {msg ? <p className="text-sm text-emerald-700">{msg}</p> : null}
            {data ? (
                <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">

                    <p className="text-sm text-slate-700">

                        Failed SMS pending: <strong>{data.failed_sms_count}</strong>
                    </p>
                    {data.last_campaign ? (
                        <p className="mt-2 text-xs text-slate-500">Last campaign: {String(data.last_campaign.created_at)}</p>
                    ) : null}
                    <div className="mt-4 flex flex-wrap gap-2">
                        <button type="button" onClick={send} className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700">
                            Run campaign send
                        </button>
                        <button type="button" onClick={retry} className="rounded-md border border-slate-300 px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">
                            Retry failed
                        </button>
                    </div>
                </div>
            ) : null}
        </Shell>
    );
}
