import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link, useNavigate, useParams } from 'react-router-dom';

const xhrJson = { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' };

export function IdCardListPage({ Layout }) {
  const [rows, setRows] = useState([]);
  const [meta, setMeta] = useState({});
  const [err, setErr] = useState('');
  const load = async () => {
    try {
      const r = await axios.get('/idcard', { headers: xhrJson });
      setRows(r.data?.data?.data || r.data?.data || []);
      setMeta(r.data?.meta || {});
    } catch (ex) { setErr(ex.response?.data?.message || 'Failed to load.'); }
  };
  useEffect(() => { load(); }, []);

  const remove = async (id) => {
    if (!window.confirm('Delete this template?')) return;
    try { await axios.delete(`/idcard/delete/${id}`, { headers: xhrJson }); load(); }
    catch (ex) { setErr(ex.response?.data?.message || 'Delete failed.'); }
  };

  return <Layout><div className="mx-auto max-w-6xl space-y-4 p-6">
    <div className="flex items-center justify-between">
      <h1 className="text-2xl font-bold text-slate-900">{meta.title || 'ID cards'}</h1>
      <div className="flex gap-2"><Link to="/idcard/generate" className="rounded border px-4 py-2 text-sm">Generate</Link><Link to="/idcard/create" className="rounded bg-blue-600 px-4 py-2 text-sm font-medium text-white">Create</Link></div>
    </div>
    {err ? <p className="text-sm text-red-600">{err}</p> : null}
    <div className="overflow-hidden rounded-xl border bg-white"><table className="min-w-full text-sm"><thead className="bg-slate-50 text-left text-xs uppercase text-slate-600"><tr><th className="px-4 py-3">Title</th><th className="px-4 py-3">Expired</th><th className="px-4 py-3 text-right">Actions</th></tr></thead><tbody>{rows.map((r)=><tr key={r.id} className="border-t"><td className="px-4 py-3">{r.title}</td><td className="px-4 py-3">{r.expired_date || '-'}</td><td className="px-4 py-3 text-right"><Link className="mr-3 text-blue-600" to={`/idcard/${r.id}/edit`}>Edit</Link><button className="text-red-600" onClick={()=>remove(r.id)}>Delete</button></td></tr>)}</tbody></table></div>
  </div></Layout>;
}

export function IdCardFormPage({ Layout, edit = false }) {
  const { id } = useParams();
  const nav = useNavigate();
  const [meta, setMeta] = useState({});
  const [form, setForm] = useState({ title: '', expired_date: '', backside_description: '', admission_no: false, roll_no: false, student_name: true, class_name: true, section_name: true, blood_group: false, dob: false });
  const [files, setFiles] = useState({ frontside_bg_image: null, backside_bg_image: null, signature: null, qr_code: null });
  const [err, setErr] = useState('');

  useEffect(() => {
    const url = edit ? `/idcard/edit/${id}` : '/idcard/create';
    axios.get(url, { headers: xhrJson }).then((r) => {
      setMeta(r.data?.meta || {});
      if (edit) {
        const v = r.data?.data?.id_card || {};
        setForm({ title: v.title || '', expired_date: v.expired_date || '', backside_description: v.backside_description || '', admission_no: !!v.admission_no, roll_no: !!v.roll_no, student_name: !!v.student_name, class_name: !!v.class_name, section_name: !!v.section_name, blood_group: !!v.blood_group, dob: !!v.dob });
      }
    }).catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));
  }, [edit, id]);

  const submit = async (e) => {
    e.preventDefault();
    try {
      const fd = new FormData();
      fd.append('title', form.title);
      fd.append('expired_date', form.expired_date || '');
      fd.append('backside_description', form.backside_description || '');
      ['admission_no','roll_no','student_name','class_name','section_name','blood_group','dob'].forEach((k) => { if (form[k]) fd.append(k, 'on'); });
      Object.keys(files).forEach((k) => { if (files[k]) fd.append(k, files[k]); });
      if (edit) { fd.append('_method', 'PUT'); await axios.post(`/idcard/update/${id}`, fd, { headers: { ...xhrJson, 'Content-Type': 'multipart/form-data' } }); }
      else await axios.post('/idcard/store', fd, { headers: { ...xhrJson, 'Content-Type': 'multipart/form-data' } });
      nav('/idcard');
    } catch (ex) { setErr(ex.response?.data?.message || 'Save failed.'); }
  };

  return <Layout><div className="mx-auto max-w-4xl space-y-4 p-6">
    <h1 className="text-2xl font-bold text-slate-900">{meta.title || (edit ? 'Edit ID card' : 'Create ID card')}</h1>
    {err ? <p className="text-sm text-red-600">{err}</p> : null}
    <form onSubmit={submit} className="grid gap-3 rounded-xl border bg-white p-6">
      <input className="rounded border px-3 py-2" placeholder="Title" value={form.title} onChange={(e)=>setForm({ ...form, title: e.target.value })} required />
      <input type="date" className="rounded border px-3 py-2" value={form.expired_date} onChange={(e)=>setForm({ ...form, expired_date: e.target.value })} />
      <textarea className="rounded border px-3 py-2" placeholder="Backside description" value={form.backside_description} onChange={(e)=>setForm({ ...form, backside_description: e.target.value })} />
      <div className="grid gap-3 md:grid-cols-2">
        <label className="text-sm">Front background<input type="file" className="mt-1 block w-full" onChange={(e)=>setFiles({ ...files, frontside_bg_image: e.target.files?.[0] || null })} /></label>
        <label className="text-sm">Back background<input type="file" className="mt-1 block w-full" onChange={(e)=>setFiles({ ...files, backside_bg_image: e.target.files?.[0] || null })} /></label>
        <label className="text-sm">Signature<input type="file" className="mt-1 block w-full" onChange={(e)=>setFiles({ ...files, signature: e.target.files?.[0] || null })} /></label>
        <label className="text-sm">QR code<input type="file" className="mt-1 block w-full" onChange={(e)=>setFiles({ ...files, qr_code: e.target.files?.[0] || null })} /></label>
      </div>
      <div className="grid gap-2 md:grid-cols-3">
        {['admission_no','roll_no','student_name','class_name','section_name','blood_group','dob'].map((k)=><label key={k} className="flex items-center gap-2 text-sm"><input type="checkbox" checked={!!form[k]} onChange={(e)=>setForm({ ...form, [k]: e.target.checked })} /> {k.replace(/_/g,' ')}</label>)}
      </div>
      <div className="flex gap-2"><button className="rounded bg-blue-600 px-4 py-2 text-white">Save</button><Link to="/idcard" className="rounded border px-4 py-2">Cancel</Link></div>
    </form>
  </div></Layout>;
}

export function IdCardGeneratePage({ Layout }) {
  const [meta, setMeta] = useState({});
  const [err, setErr] = useState('');
  const [result, setResult] = useState(null);
  const [form, setForm] = useState({ id_card: '', class: '', section: '', student: '' });

  useEffect(() => {
    axios.get('/idcard/generate', { headers: xhrJson }).then((r) => setMeta(r.data?.meta || {})).catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));
  }, []);

  const submit = async (e) => {
    e.preventDefault();
    try {
      const r = await axios.post('/idcard/generate', form, { headers: xhrJson });
      setResult(r.data?.data || null);
    } catch (ex) { setErr(ex.response?.data?.message || 'Generate failed.'); }
  };

  return <Layout><div className="mx-auto max-w-6xl space-y-4 p-6">
    <h1 className="text-2xl font-bold text-slate-900">{meta.title || 'Generate ID cards'}</h1>
    {err ? <p className="text-sm text-red-600">{err}</p> : null}
    <form onSubmit={submit} className="grid gap-3 rounded-xl border bg-white p-4 md:grid-cols-4">
      <select className="rounded border px-3 py-2" value={form.id_card} onChange={(e)=>setForm({ ...form, id_card: e.target.value })} required><option value="">ID card template</option>{(meta.id_cards || []).map((x)=><option key={x.id} value={x.id}>{x.title}</option>)}</select>
      <select className="rounded border px-3 py-2" value={form.class} onChange={(e)=>setForm({ ...form, class: e.target.value })} required><option value="">Class</option>{(meta.classes || []).map((c)=>{const v=c.class?.id||c.id; const n=c.class?.name||c.name; return <option key={v} value={v}>{n}</option>;})}</select>
      <input className="rounded border px-3 py-2" placeholder="Section id" value={form.section} onChange={(e)=>setForm({ ...form, section: e.target.value })} required />
      <input className="rounded border px-3 py-2" placeholder="Student id (optional)" value={form.student} onChange={(e)=>setForm({ ...form, student: e.target.value })} />
      <button className="rounded bg-blue-600 px-4 py-2 text-sm font-medium text-white">Search</button>
    </form>
    {result ? <div className="rounded-xl border bg-white p-4"><h2 className="mb-2 text-lg font-semibold">Results</h2><p className="text-sm text-slate-600">Template: {result.idcard?.title}</p><div className="mt-2 divide-y">{(result.students || []).map((s)=><div key={s.id} className="py-2 text-sm">Student #{s.student_id}</div>)}</div></div> : null}
  </div></Layout>;
}
