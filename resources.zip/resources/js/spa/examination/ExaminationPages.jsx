import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link, useNavigate, useParams } from 'react-router-dom';

const xhrJson = { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' };

function Shell({ Layout, children, wide = false }) {
    return (
        <Layout>
            <div className={wide ? 'mx-auto max-w-7xl space-y-6 p-6' : 'mx-auto max-w-3xl space-y-6 p-6'}>{children}</div>
        </Layout>
    );
}

function readPaginate(res) {
    const p = res.data?.data;
    if (p && Array.isArray(p.data)) {
        return { rows: p.data, page: p.current_page, last: p.last_page };
    }
    return { rows: Array.isArray(p) ? p : [], page: 1, last: 1 };
}

/* ——— Hub ——— */

export function ExaminationHomePage({ Layout }) {
    const links = [
        { to: '/examination/marks-grades', label: 'Marks grades' },
        { to: '/examination/settings', label: 'Examination settings' },
        { to: '/examination/exam-assign', label: 'Exam assign' },
        { to: '/examination/marks-register', label: 'Marks register' },
    ];
    return (
        <Shell Layout={Layout} wide>
            <h1 className="text-2xl font-bold text-slate-900">Examination</h1>
            <p className="text-sm text-slate-500">Manage grades, exam assignment, and marks register.</p>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                {links.map((l) => (
                    <Link
                        key={l.to}
                        to={l.to}
                        className="rounded-xl border border-slate-200 bg-white p-4 text-sm font-medium text-blue-700 shadow-sm hover:bg-slate-50"
                    >
                        {l.label}
                    </Link>
                ))}
            </div>
        </Shell>
    );
}

/* ——— Marks grades ——— */

export function MarksGradesListPage({ Layout }) {
    const [rows, setRows] = useState([]);
    const [meta, setMeta] = useState({});
    const [page, setPage] = useState(1);
    const [last, setLast] = useState(1);
    const [err, setErr] = useState('');

    const load = (p = 1) =>
        axios
            .get('/marks-grade', { headers: xhrJson, params: { page: p } })
            .then((r) => {
                const { rows: list, page: cur, last: lst } = readPaginate(r);
                setRows(list);
                setPage(cur);
                setLast(lst);
                setMeta(r.data?.meta ?? {});
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));

    useEffect(() => {
        load(1);
    }, []);

    const remove = async (id) => {
        if (!window.confirm('Delete this marks grade?')) return;
        try {
            await axios.delete(`/marks-grade/delete/${id}`, { headers: xhrJson });
            load(page);
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Delete failed.');
        }
    };

    return (
        <Shell Layout={Layout} wide>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <h1 className="text-2xl font-bold text-slate-900">{meta.title || 'Marks grades'}</h1>
                <div className="flex gap-2">
                    <Link to="/examination" className="rounded-md border border-slate-300 px-4 py-2 text-sm text-slate-700">
                        Back
                    </Link>
                    <Link
                        to="/examination/marks-grades/create"
                        className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
                    >
                        Add
                    </Link>
                </div>
            </div>
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
                <table className="min-w-full divide-y divide-slate-200 text-sm">
                    <thead className="bg-slate-50 text-left text-xs font-semibold uppercase text-slate-600">
                        <tr>
                            <th className="px-4 py-3">Name</th>
                            <th className="px-4 py-3">Point</th>
                            <th className="px-4 py-3">%</th>
                            <th className="px-4 py-3 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {rows.map((row) => (
                            <tr key={row.id} className="hover:bg-slate-50/80">
                                <td className="px-4 py-3 font-medium text-slate-900">{row.name}</td>
                                <td className="px-4 py-3">{row.point}</td>
                                <td className="px-4 py-3">
                                    {row.percent_from} – {row.percent_upto}
                                </td>
                                <td className="px-4 py-3 text-right">
                                    <Link
                                        className="mr-3 font-medium text-blue-600 hover:text-blue-800"
                                        to={`/examination/marks-grades/${row.id}/edit`}
                                    >
                                        Edit
                                    </Link>
                                    <button type="button" className="text-red-600 hover:text-red-800" onClick={() => remove(row.id)}>
                                        Delete
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                {!rows.length ? <p className="px-4 py-8 text-center text-sm text-slate-500">No records.</p> : null}
            </div>
            {last > 1 ? (
                <div className="flex justify-between text-sm text-slate-600">
                    <span>
                        Page {page} / {last}
                    </span>
                    <div className="flex gap-2">
                        <button
                            type="button"
                            disabled={page <= 1}
                            className="rounded border px-3 py-1 disabled:opacity-50"
                            onClick={() => load(page - 1)}
                        >
                            Prev
                        </button>
                        <button
                            type="button"
                            disabled={page >= last}
                            className="rounded border px-3 py-1 disabled:opacity-50"
                            onClick={() => load(page + 1)}
                        >
                            Next
                        </button>
                    </div>
                </div>
            ) : null}
        </Shell>
    );
}

export function MarksGradesFormPage({ Layout, edit = false }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [meta, setMeta] = useState({});
    const [form, setForm] = useState({ name: '', point: '', percent_from: '', percent_upto: '' });
    const [err, setErr] = useState('');
    const [busy, setBusy] = useState(false);

    useEffect(() => {
        if (!edit) {
            axios.get('/marks-grade/create', { headers: xhrJson }).then((r) => setMeta(r.data?.meta || {}));
            return;
        }
        axios
            .get(`/marks-grade/edit/${id}`, { headers: xhrJson })
            .then((r) => {
                setMeta(r.data?.meta || {});
                const mg = r.data?.data?.marks_grade ?? r.data?.data;
                setForm({
                    name: mg?.name ?? '',
                    point: mg?.point ?? '',
                    percent_from: mg?.percent_from ?? '',
                    percent_upto: mg?.percent_upto ?? '',
                });
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));
    }, [edit, id]);

    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        setBusy(true);
        try {
            if (edit) await axios.put(`/marks-grade/update/${id}`, { ...form, id }, { headers: xhrJson });
            else await axios.post('/marks-grade/store', form, { headers: xhrJson });
            nav('/examination/marks-grades');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Save failed.');
        } finally {
            setBusy(false);
        }
    };

    return (
        <Shell Layout={Layout}>
            <div className="flex items-center gap-3">
                <Link to="/examination/marks-grades" className="text-sm text-blue-600 hover:text-blue-800">
                    ← Marks grades
                </Link>
            </div>
            <h1 className="text-2xl font-bold text-slate-900">{meta.title || (edit ? 'Edit marks grade' : 'Create marks grade')}</h1>
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <form onSubmit={submit} className="grid max-w-lg gap-4 rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
                {['name', 'point', 'percent_from', 'percent_upto'].map((k) => (
                    <label key={k} className="text-sm font-medium text-slate-700">
                        {k.replace(/_/g, ' ')}
                        <input
                            className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                            value={form[k]}
                            onChange={(e) => setForm({ ...form, [k]: e.target.value })}
                            required
                        />
                    </label>
                ))}
                <div className="flex gap-2">
                    <button
                        type="submit"
                        disabled={busy}
                        className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white disabled:opacity-50"
                    >
                        {busy ? 'Saving…' : 'Save'}
                    </button>
                    <Link to="/examination/marks-grades" className="rounded-md border border-slate-300 px-4 py-2 text-sm text-slate-700">
                        Cancel
                    </Link>
                </div>
            </form>
        </Shell>
    );
}

/* ——— Examination settings ——— */

export function ExaminationSettingsPage({ Layout }) {
    const [meta, setMeta] = useState({});
    const [value, setValue] = useState('');
    const [err, setErr] = useState('');
    const [busy, setBusy] = useState(false);

    useEffect(() => {
        axios.get('/examination-settings', { headers: xhrJson }).then((r) => {
            const m = r.data?.meta || {};
            setMeta(m);
            setValue(m.average_pass_marks != null ? String(m.average_pass_marks) : '');
        });
    }, []);

    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        setBusy(true);
        try {
            await axios.put(
                '/examination-settings/update',
                { fields: ['average_pass_marks'], values: [value] },
                { headers: xhrJson },
            );
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Update failed.');
        } finally {
            setBusy(false);
        }
    };

    return (
        <Shell Layout={Layout}>
            <Link to="/examination" className="text-sm text-blue-600 hover:text-blue-800">
                ← Examination
            </Link>
            <h1 className="text-2xl font-bold text-slate-900">{meta.title || 'Examination settings'}</h1>
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <form onSubmit={submit} className="grid max-w-lg gap-4 rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
                <label className="text-sm font-medium text-slate-700">
                    Average pass marks
                    <input
                        className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                        value={value}
                        onChange={(e) => setValue(e.target.value)}
                    />
                </label>
                <button
                    type="submit"
                    disabled={busy}
                    className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white disabled:opacity-50"
                >
                    {busy ? 'Saving…' : 'Save'}
                </button>
            </form>
        </Shell>
    );
}

/* ——— Exam assign ——— */

export function ExamAssignListPage({ Layout }) {
    const [rows, setRows] = useState([]);
    const [meta, setMeta] = useState({});
    const [page, setPage] = useState(1);
    const [last, setLast] = useState(1);
    const [err, setErr] = useState('');
    const [filters, setFilters] = useState({ class: '', section: '', exam_type: '', subject: '' });

    const loadInitial = () =>
        axios.get('/exam-assign', { headers: xhrJson, params: { page: 1 } }).then((r) => {
            const { rows: list, page: cur, last: lst } = readPaginate(r);
            setRows(list);
            setPage(cur);
            setLast(lst);
            setMeta(r.data?.meta ?? {});
        });

    useEffect(() => {
        loadInitial().catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));
    }, []);

    const search = async (e, p = 1) => {
        e?.preventDefault();
        setErr('');
        try {
            const r = await axios.post('/exam-assign/search', { ...filters, page: p }, { headers: xhrJson });
            const { rows: list, page: cur, last: lst } = readPaginate(r);
            setRows(list);
            setPage(cur);
            setLast(lst);
            setMeta((m) => ({ ...m, ...(r.data?.meta || {}) }));
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Search failed.');
        }
    };

    const remove = async (id) => {
        if (!window.confirm('Delete this exam assign?')) return;
        try {
            await axios.delete(`/exam-assign/delete/${id}`, { headers: xhrJson });
            await loadInitial();
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Delete failed.');
        }
    };

    const subjectArr = meta.subjectArr || {};
    const sectionArr = meta.sectionArr || {};
    const examArr = meta.examArr || {};

    return (
        <Shell Layout={Layout} wide>
            <div className="flex flex-wrap items-center justify-between gap-3">
                <h1 className="text-2xl font-bold text-slate-900">{meta.title || 'Exam assign'}</h1>
                <div className="flex flex-wrap gap-2">
                    <Link to="/examination" className="rounded-md border border-slate-300 px-4 py-2 text-sm text-slate-700">
                        Back
                    </Link>
                    <Link
                        to="/examination/exam-assign/create"
                        className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
                    >
                        Create
                    </Link>
                </div>
            </div>
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <form
                onSubmit={search}
                className="grid gap-3 rounded-xl border border-slate-200 bg-white p-4 shadow-sm md:grid-cols-5"
            >
                <select
                    className="rounded-md border border-slate-300 px-3 py-2 text-sm"
                    value={filters.class}
                    onChange={(e) => setFilters({ ...filters, class: e.target.value })}
                >
                    <option value="">Class</option>
                    {(meta.classes || []).map((c) => (
                        <option key={c.id} value={c.id}>
                            {c.name}
                        </option>
                    ))}
                </select>
                <input
                    className="rounded-md border border-slate-300 px-3 py-2 text-sm"
                    placeholder="Section id"
                    value={filters.section}
                    onChange={(e) => setFilters({ ...filters, section: e.target.value })}
                />
                <input
                    className="rounded-md border border-slate-300 px-3 py-2 text-sm"
                    placeholder="Exam type id"
                    value={filters.exam_type}
                    onChange={(e) => setFilters({ ...filters, exam_type: e.target.value })}
                />
                <input
                    className="rounded-md border border-slate-300 px-3 py-2 text-sm"
                    placeholder="Subject id"
                    value={filters.subject}
                    onChange={(e) => setFilters({ ...filters, subject: e.target.value })}
                />
                <button type="submit" className="rounded-md bg-slate-800 px-4 py-2 text-sm font-medium text-white hover:bg-slate-900">
                    Search
                </button>
            </form>
            <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
                <table className="min-w-full divide-y divide-slate-200 text-sm">
                    <thead className="bg-slate-50 text-left text-xs font-semibold uppercase text-slate-600">
                        <tr>
                            <th className="px-4 py-3">ID</th>
                            <th className="px-4 py-3">Class / Section</th>
                            <th className="px-4 py-3">Exam / Subject</th>
                            <th className="px-4 py-3">Total</th>
                            <th className="px-4 py-3 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {rows.map((row) => (
                            <tr key={row.id} className="hover:bg-slate-50/80">
                                <td className="px-4 py-3">{row.id}</td>
                                <td className="px-4 py-3">
                                    {row.classes_id} / {sectionArr[row.section_id] || row.section_id}
                                </td>
                                <td className="px-4 py-3">
                                    {examArr[row.exam_type_id] || row.exam_type_id} / {subjectArr[row.subject_id] || row.subject_id}
                                </td>
                                <td className="px-4 py-3">{row.total_mark}</td>
                                <td className="px-4 py-3 text-right">
                                    <Link
                                        className="mr-3 font-medium text-blue-600 hover:text-blue-800"
                                        to={`/examination/exam-assign/${row.id}/edit`}
                                    >
                                        Edit
                                    </Link>
                                    <button type="button" className="text-red-600 hover:text-red-800" onClick={() => remove(row.id)}>
                                        Delete
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                {!rows.length ? <p className="px-4 py-8 text-center text-sm text-slate-500">No rows.</p> : null}
            </div>
            {last > 1 ? (
                <div className="flex justify-between text-sm text-slate-600">
                    <span>
                        Page {page} / {last}
                    </span>
                    <div className="flex gap-2">
                        <button
                            type="button"
                            disabled={page <= 1}
                            className="rounded border px-3 py-1 disabled:opacity-50"
                            onClick={(e) => search(e, page - 1)}
                        >
                            Prev
                        </button>
                        <button
                            type="button"
                            disabled={page >= last}
                            className="rounded border px-3 py-1 disabled:opacity-50"
                            onClick={(e) => search(e, page + 1)}
                        >
                            Next
                        </button>
                    </div>
                </div>
            ) : null}
        </Shell>
    );
}

export function ExamAssignCreatePage({ Layout }) {
    const nav = useNavigate();
    const [meta, setMeta] = useState({});
    const [sections, setSections] = useState([]);
    const [classId, setClassId] = useState('');
    const [sectionIds, setSectionIds] = useState([]);
    const [subjectOptions, setSubjectOptions] = useState([]);
    const [subjectMsg, setSubjectMsg] = useState('');
    const [examTypeIds, setExamTypeIds] = useState([]);
    const [subjectIds, setSubjectIds] = useState([]);
    const [dist, setDist] = useState({});
    const [err, setErr] = useState('');
    const [busy, setBusy] = useState(false);

    useEffect(() => {
        axios.get('/exam-assign/create', { headers: xhrJson }).then((r) => setMeta(r.data?.meta || {}));
    }, []);

    useEffect(() => {
        if (!classId) {
            setSections([]);
            setSectionIds([]);
            return;
        }
        axios.get('/exam-assign/get-sections', { headers: xhrJson, params: { id: classId } }).then((r) => {
            setSections(Array.isArray(r.data) ? r.data : r.data?.data || []);
        });
    }, [classId]);

    useEffect(() => {
        if (!classId || sectionIds.length !== 1) {
            setSubjectOptions([]);
            setSubjectIds([]);
            setDist({});
            return;
        }
        const sid = sectionIds[0];
        axios
            .get('/exam-assign/get-subjects', {
                headers: xhrJson,
                params: {
                    classes_id: classId,
                    section_id: sid,
                    sections: sectionIds,
                    form_type: 'create',
                },
            })
            .then((r) => {
                const d = r.data || {};
                setSubjectMsg(d.message || '');
                const subs = (d.subjects || []).map((x) => ({
                    id: x.subject_id || x.subject?.id,
                    name: x.subject?.name || `Subject ${x.subject_id}`,
                }));
                setSubjectOptions(subs.filter((s) => s.id));
                if (!d.section_status || !d.loop_status) {
                    setSubjectIds([]);
                }
            });
    }, [classId, sectionIds]);

    const toggleSection = (id) => {
        setSectionIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
    };

    const setDistributionRow = (subId, idx, field, val) => {
        setDist((prev) => {
            const cur = prev[subId] || { titles: ['Written'], marks: ['0'] };
            const titles = [...(cur.titles || [])];
            const marks = [...(cur.marks || [])];
            if (field === 'title') titles[idx] = val;
            else marks[idx] = val;
            return { ...prev, [subId]: { titles, marks } };
        });
    };

    const addDistRow = (subId) => {
        setDist((prev) => {
            const cur = prev[subId] || { titles: ['Written'], marks: ['0'] };
            return { ...prev, [subId]: { titles: [...cur.titles, ''], marks: [...cur.marks, '0'] } };
        });
    };

    useEffect(() => {
        setDist((prev) => {
            const next = { ...prev };
            subjectIds.forEach((sid) => {
                if (!next[sid]) next[sid] = { titles: ['Written'], marks: ['10'] };
            });
            return next;
        });
    }, [subjectIds]);

    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        setBusy(true);
        try {
            const marks_distribution = {};
            subjectIds.forEach((sid) => {
                marks_distribution[sid] = dist[sid] || { titles: ['Written'], marks: ['0'] };
            });
            await axios.post(
                '/exam-assign/store',
                {
                    class: classId,
                    sections: sectionIds,
                    exam_types: examTypeIds,
                    subjects: subjectIds,
                    marks_distribution,
                },
                { headers: xhrJson },
            );
            nav('/examination/exam-assign');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Save failed.');
        } finally {
            setBusy(false);
        }
    };

    const classRows = meta.classes || [];

    return (
        <Shell Layout={Layout} wide>
            <Link to="/examination/exam-assign" className="text-sm text-blue-600 hover:text-blue-800">
                ← Exam assign
            </Link>
            <h1 className="text-2xl font-bold text-slate-900">{meta.title || 'Create exam assign'}</h1>
            <p className="text-sm text-amber-800">
                Select exactly one section for this workflow so subjects load correctly. You can assign multiple exam types and subjects; mark distribution is per subject.
            </p>
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            {subjectMsg ? <p className="text-sm text-amber-700">{subjectMsg}</p> : null}
            <form onSubmit={submit} className="space-y-6 rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
                <label className="block text-sm font-medium text-slate-700">
                    Class
                    <select
                        className="mt-1 w-full max-w-md rounded-md border border-slate-300 px-3 py-2"
                        value={classId}
                        onChange={(e) => {
                            setClassId(e.target.value);
                            setSectionIds([]);
                        }}
                        required
                    >
                        <option value="">Select</option>
                        {classRows.map((item) => {
                            const c = item.class || item;
                            const cid = c.id || item.classes_id;
                            return (
                                <option key={cid} value={cid}>
                                    {c.name || item.name}
                                </option>
                            );
                        })}
                    </select>
                </label>
                <div>
                    <p className="text-sm font-medium text-slate-700">Sections (select one)</p>
                    <div className="mt-2 flex flex-wrap gap-3">
                        {sections.map((s) => (
                            <label key={s.id} className="flex items-center gap-2 text-sm">
                                <input type="checkbox" checked={sectionIds.includes(s.id)} onChange={() => toggleSection(s.id)} />
                                {s.name}
                            </label>
                        ))}
                    </div>
                </div>
                <label className="block text-sm font-medium text-slate-700">
                    Exam types (multi)
                    <select
                        multiple
                        className="mt-1 w-full max-w-md rounded-md border border-slate-300 px-3 py-2"
                        value={examTypeIds.map(String)}
                        onChange={(e) =>
                            setExamTypeIds(Array.from(e.target.selectedOptions).map((o) => o.value))
                        }
                        required
                        size={Math.min(8, (meta.exam_types || []).length || 4)}
                    >
                        {(meta.exam_types || []).map((et) => (
                            <option key={et.id} value={et.id}>
                                {et.name}
                            </option>
                        ))}
                    </select>
                </label>
                <label className="block text-sm font-medium text-slate-700">
                    Subjects (multi)
                    <select
                        multiple
                        className="mt-1 w-full max-w-md rounded-md border border-slate-300 px-3 py-2"
                        value={subjectIds.map(String)}
                        onChange={(e) => setSubjectIds(Array.from(e.target.selectedOptions).map((o) => Number(o.value)))}
                        required
                        size={Math.min(8, subjectOptions.length || 4)}
                    >
                        {subjectOptions.map((s) => (
                            <option key={s.id} value={s.id}>
                                {s.name}
                            </option>
                        ))}
                    </select>
                </label>
                {subjectIds.map((subId) => {
                    const rows = dist[subId]?.titles?.length ? dist[subId] : { titles: ['Written'], marks: ['10'] };
                    return (
                        <div key={subId} className="rounded-lg border border-slate-100 p-4">
                            <p className="mb-2 text-sm font-semibold text-slate-800">
                                Marks — {subjectOptions.find((s) => s.id === subId)?.name || subId}
                            </p>
                            {(rows.titles || []).map((t, idx) => (
                                <div key={idx} className="mb-2 flex flex-wrap gap-2">
                                    <input
                                        className="rounded-md border border-slate-300 px-3 py-2 text-sm"
                                        placeholder="Title"
                                        value={t}
                                        onChange={(e) => setDistributionRow(subId, idx, 'title', e.target.value)}
                                    />
                                    <input
                                        className="w-24 rounded-md border border-slate-300 px-3 py-2 text-sm"
                                        placeholder="Mark"
                                        value={rows.marks?.[idx] ?? ''}
                                        onChange={(e) => setDistributionRow(subId, idx, 'mark', e.target.value)}
                                    />
                                </div>
                            ))}
                            <button type="button" className="text-sm text-blue-600 hover:text-blue-800" onClick={() => addDistRow(subId)}>
                                + Add distribution row
                            </button>
                        </div>
                    );
                })}
                <button
                    type="submit"
                    disabled={busy || sectionIds.length !== 1}
                    className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white disabled:opacity-50"
                >
                    {busy ? 'Saving…' : 'Save'}
                </button>
            </form>
        </Shell>
    );
}

export function ExamAssignEditPage({ Layout }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [meta, setMeta] = useState({});
    const [classId, setClassId] = useState('');
    const [sectionId, setSectionId] = useState('');
    const [examTypeId, setExamTypeId] = useState('');
    const [subjectId, setSubjectId] = useState('');
    const [titles, setTitles] = useState(['Written']);
    const [marks, setMarks] = useState(['0']);
    const [err, setErr] = useState('');
    const [busy, setBusy] = useState(false);

    useEffect(() => {
        axios
            .get(`/exam-assign/edit/${id}`, { headers: xhrJson })
            .then((r) => {
                setMeta(r.data?.meta || {});
                const row = r.data?.data?.exam_assign;
                if (!row) {
                    setErr(r.data?.message || 'Cannot edit this assign.');
                    return;
                }
                setClassId(String(row.classes_id));
                setSectionId(String(row.section_id));
                setExamTypeId(String(row.exam_type_id));
                setSubjectId(String(row.subject_id));
                const md = row.mark_distribution || [];
                if (md.length) {
                    setTitles(md.map((m) => m.title));
                    setMarks(md.map((m) => String(m.mark)));
                }
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));
    }, [id]);

    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        setBusy(true);
        try {
            await axios.put(
                `/exam-assign/update/${id}`,
                {
                    class: classId,
                    sections: sectionId,
                    exam_types: examTypeId,
                    subjects: subjectId,
                    marks_distribution: {
                        [subjectId]: { titles, marks },
                    },
                },
                { headers: xhrJson },
            );
            nav('/examination/exam-assign');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Save failed.');
        } finally {
            setBusy(false);
        }
    };

    const classes = meta.classes || [];
    const sections = meta.sections || [];
    const subjects = meta.subjects || [];
    const examTypes = meta.exam_types || [];

    return (
        <Shell Layout={Layout} wide>
            <Link to="/examination/exam-assign" className="text-sm text-blue-600 hover:text-blue-800">
                ← Exam assign
            </Link>
            <h1 className="text-2xl font-bold text-slate-900">{meta.title || 'Edit exam assign'}</h1>
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <form onSubmit={submit} className="grid max-w-2xl gap-4 rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
                <label className="text-sm font-medium text-slate-700">
                    Class
                    <select
                        className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                        value={classId}
                        onChange={(e) => setClassId(e.target.value)}
                        required
                    >
                        <option value="">—</option>
                        {classes.map((c) => (
                            <option key={c.id} value={c.id}>
                                {c.name}
                            </option>
                        ))}
                    </select>
                </label>
                <label className="text-sm font-medium text-slate-700">
                    Section
                    <select
                        className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                        value={sectionId}
                        onChange={(e) => setSectionId(e.target.value)}
                        required
                    >
                        <option value="">—</option>
                        {sections.map((s) => (
                            <option key={s.id} value={s.id}>
                                {s.name}
                            </option>
                        ))}
                    </select>
                </label>
                <label className="text-sm font-medium text-slate-700">
                    Exam type
                    <select
                        className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                        value={examTypeId}
                        onChange={(e) => setExamTypeId(e.target.value)}
                        required
                    >
                        <option value="">—</option>
                        {examTypes.map((et) => (
                            <option key={et.id} value={et.id}>
                                {et.name}
                            </option>
                        ))}
                    </select>
                </label>
                <label className="text-sm font-medium text-slate-700">
                    Subject
                    <select
                        className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                        value={subjectId}
                        onChange={(e) => setSubjectId(e.target.value)}
                        required
                    >
                        <option value="">—</option>
                        {subjects.map((sc) => {
                            const sub = sc.subject || sc;
                            const sid = sc.subject_id || sub.id;
                            return (
                                <option key={sid} value={sid}>
                                    {sub.name}
                                </option>
                            );
                        })}
                    </select>
                </label>
                <div>
                    <p className="text-sm font-medium text-slate-700">Mark distribution</p>
                    {titles.map((t, idx) => (
                        <div key={idx} className="mt-2 flex gap-2">
                            <input
                                className="flex-1 rounded-md border border-slate-300 px-3 py-2 text-sm"
                                value={t}
                                onChange={(e) => {
                                    const nt = [...titles];
                                    nt[idx] = e.target.value;
                                    setTitles(nt);
                                }}
                            />
                            <input
                                className="w-24 rounded-md border border-slate-300 px-3 py-2 text-sm"
                                value={marks[idx] || ''}
                                onChange={(e) => {
                                    const nm = [...marks];
                                    nm[idx] = e.target.value;
                                    setMarks(nm);
                                }}
                            />
                        </div>
                    ))}
                </div>
                <button type="submit" disabled={busy} className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white disabled:opacity-50">
                    {busy ? 'Saving…' : 'Update'}
                </button>
            </form>
        </Shell>
    );
}

/* ——— Marks register ——— */

export function MarksRegisterListPage({ Layout }) {
    const [rows, setRows] = useState([]);
    const [meta, setMeta] = useState({});
    const [page, setPage] = useState(1);
    const [last, setLast] = useState(1);
    const [err, setErr] = useState('');
    const [msg, setMsg] = useState('');
    const [filters, setFilters] = useState({ class: '', section: '', exam_type: '', subject: '' });
    const [sections, setSections] = useState([]);

    const applyPaginator = (r) => {
        const { rows: list, page: cur, last: lst } = readPaginate(r);
        setRows(list);
        setPage(cur);
        setLast(lst);
        setMeta((m) => ({ ...m, ...(r.data?.meta || {}) }));
    };

    useEffect(() => {
        axios
            .get('/marks-register', { headers: xhrJson, params: { page: 1 } })
            .then(applyPaginator)
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));
    }, []);

    useEffect(() => {
        if (!filters.class) {
            setSections([]);
            return;
        }
        axios.get('/exam-assign/get-sections', { headers: xhrJson, params: { id: filters.class } }).then((r) => {
            setSections(Array.isArray(r.data) ? r.data : r.data?.data || []);
        });
    }, [filters.class]);

    const search = async (e, p = 1) => {
        e?.preventDefault();
        setErr('');
        try {
            const r = await axios.post('/marks-register/search', { ...filters, page: p }, { headers: xhrJson });
            applyPaginator(r);
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Search failed.');
        }
    };

    const runTerminal = async () => {
        setMsg('');
        try {
            const r = await axios.get('/marks-register/terminal', { headers: xhrJson });
            setMsg(r.data?.message || 'Done.');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Terminal action failed.');
        }
    };

    const remove = async (id) => {
        if (!window.confirm('Delete this marks register?')) return;
        try {
            await axios.delete(`/marks-register/delete/${id}`, { headers: xhrJson });
            await axios.get('/marks-register', { headers: xhrJson, params: { page } }).then(applyPaginator);
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Delete failed.');
        }
    };

    return (
        <Shell Layout={Layout} wide>
            <div className="flex flex-wrap items-center justify-between gap-3">
                <h1 className="text-2xl font-bold text-slate-900">{meta.title || 'Marks register'}</h1>
                <div className="flex flex-wrap gap-2">
                    <Link to="/examination" className="rounded-md border border-slate-300 px-4 py-2 text-sm text-slate-700">
                        Back
                    </Link>
                    <button type="button" onClick={runTerminal} className="rounded-md border border-amber-500 px-4 py-2 text-sm text-amber-900">
                        Compute terminal results
                    </button>
                    <Link
                        to="/examination/marks-register/create"
                        className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
                    >
                        Create
                    </Link>
                </div>
            </div>
            {msg ? <p className="text-sm text-emerald-700">{msg}</p> : null}
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <form onSubmit={search} className="grid gap-3 rounded-xl border border-slate-200 bg-white p-4 shadow-sm md:grid-cols-6">
                <select
                    className="rounded-md border border-slate-300 px-3 py-2 text-sm"
                    value={filters.class}
                    onChange={(e) => setFilters({ ...filters, class: e.target.value, section: '' })}
                >
                    <option value="">Class</option>
                    {(meta.classes || []).map((c) => (
                        <option key={c.id} value={c.id}>
                            {c.name}
                        </option>
                    ))}
                </select>
                <select
                    className="rounded-md border border-slate-300 px-3 py-2 text-sm"
                    value={filters.section}
                    onChange={(e) => setFilters({ ...filters, section: e.target.value })}
                >
                    <option value="">Section</option>
                    {sections.map((s) => (
                        <option key={s.id} value={s.id}>
                            {s.name}
                        </option>
                    ))}
                </select>
                <input
                    className="rounded-md border border-slate-300 px-3 py-2 text-sm"
                    placeholder="Exam type id"
                    value={filters.exam_type}
                    onChange={(e) => setFilters({ ...filters, exam_type: e.target.value })}
                />
                <input
                    className="rounded-md border border-slate-300 px-3 py-2 text-sm"
                    placeholder="Subject id"
                    value={filters.subject}
                    onChange={(e) => setFilters({ ...filters, subject: e.target.value })}
                />
                <button type="submit" className="rounded-md bg-slate-800 px-4 py-2 text-sm font-medium text-white">
                    Search
                </button>
            </form>
            <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
                <table className="min-w-full divide-y divide-slate-200 text-sm">
                    <thead className="bg-slate-50 text-left text-xs font-semibold uppercase text-slate-600">
                        <tr>
                            <th className="px-4 py-3">ID</th>
                            <th className="px-4 py-3">Class</th>
                            <th className="px-4 py-3">Section</th>
                            <th className="px-4 py-3">Exam</th>
                            <th className="px-4 py-3">Subject</th>
                            <th className="px-4 py-3 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {rows.map((row) => (
                            <tr key={row.id} className="hover:bg-slate-50/80">
                                <td className="px-4 py-3">{row.id}</td>
                                <td className="px-4 py-3">{row.classes_id}</td>
                                <td className="px-4 py-3">{row.section_id}</td>
                                <td className="px-4 py-3">{row.exam_type_id}</td>
                                <td className="px-4 py-3">{row.subject_id}</td>
                                <td className="px-4 py-3 text-right">
                                    <Link
                                        className="mr-2 font-medium text-blue-600 hover:text-blue-800"
                                        to={`/examination/marks-register/${row.id}/view`}
                                    >
                                        View
                                    </Link>
                                    <Link
                                        className="mr-2 font-medium text-blue-600 hover:text-blue-800"
                                        to={`/examination/marks-register/${row.id}/edit`}
                                    >
                                        Edit
                                    </Link>
                                    <button type="button" className="text-red-600 hover:text-red-800" onClick={() => remove(row.id)}>
                                        Delete
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                {!rows.length ? <p className="px-4 py-8 text-center text-sm text-slate-500">No rows.</p> : null}
            </div>
            {last > 1 ? (
                <div className="flex justify-between text-sm text-slate-600">
                    <span>
                        Page {page} / {last}
                    </span>
                    <div className="flex gap-2">
                        <button
                            type="button"
                            disabled={page <= 1}
                            className="rounded border px-3 py-1 disabled:opacity-50"
                            onClick={(e) => search(e, page - 1)}
                        >
                            Prev
                        </button>
                        <button
                            type="button"
                            disabled={page >= last}
                            className="rounded border px-3 py-1 disabled:opacity-50"
                            onClick={(e) => search(e, page + 1)}
                        >
                            Next
                        </button>
                    </div>
                </div>
            ) : null}
        </Shell>
    );
}

export function MarksRegisterCreatePage({ Layout }) {
    const nav = useNavigate();
    const [meta, setMeta] = useState({});
    const [classId, setClassId] = useState('');
    const [examType, setExamType] = useState('');
    const [subject, setSubject] = useState('');
    const [file, setFile] = useState(null);
    const [err, setErr] = useState('');
    const [busy, setBusy] = useState(false);

    useEffect(() => {
        axios.get('/marks-register/create', { headers: xhrJson }).then((r) => setMeta(r.data?.meta || {}));
    }, []);

    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        setBusy(true);
        try {
            const fd = new FormData();
            fd.append('class', classId);
            fd.append('exam_type', examType);
            fd.append('subject', subject);
            if (file) fd.append('document_files', file);
            await axios.post('/marks-register/store', fd, {
                headers: { ...xhrJson, 'Content-Type': 'multipart/form-data' },
            });
            nav('/examination/marks-register');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Save failed.');
        } finally {
            setBusy(false);
        }
    };

    const classes = meta.classes || [];
    const examTypes = meta.exam_types || [];
    const subjects = meta.subjects || [];

    return (
        <Shell Layout={Layout}>
            <Link to="/examination/marks-register" className="text-sm text-blue-600 hover:text-blue-800">
                ← Marks register
            </Link>
            <h1 className="text-2xl font-bold text-slate-900">{meta.title || 'Create marks register'}</h1>
            <p className="text-sm text-slate-500">Upload an Excel/CSV file with columns matching the school import (e.g. reg_number, marks).</p>
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <form onSubmit={submit} className="grid max-w-lg gap-4 rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
                <label className="text-sm font-medium text-slate-700">
                    Class
                    <select
                        className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                        value={classId}
                        onChange={(e) => setClassId(e.target.value)}
                        required
                    >
                        <option value="">—</option>
                        {classes.map((item) => {
                            const c = item.class || item;
                            const cid = c.id || item.classes_id;
                            return (
                                <option key={cid} value={cid}>
                                    {c.name}
                                </option>
                            );
                        })}
                    </select>
                </label>
                <label className="text-sm font-medium text-slate-700">
                    Exam type
                    <select
                        className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                        value={examType}
                        onChange={(e) => setExamType(e.target.value)}
                        required
                    >
                        <option value="">—</option>
                        {examTypes.map((et) => (
                            <option key={et.id} value={et.id}>
                                {et.name}
                            </option>
                        ))}
                    </select>
                </label>
                <label className="text-sm font-medium text-slate-700">
                    Subject
                    <select
                        className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                        value={subject}
                        onChange={(e) => setSubject(e.target.value)}
                        required
                    >
                        <option value="">—</option>
                        {subjects.map((s) => (
                            <option key={s.id} value={s.id}>
                                {s.name}
                            </option>
                        ))}
                    </select>
                </label>
                <label className="text-sm font-medium text-slate-700">
                    Spreadsheet
                    <input
                        type="file"
                        accept=".xlsx,.xls,.csv"
                        className="mt-1 w-full text-sm"
                        onChange={(e) => setFile(e.target.files?.[0] || null)}
                        required
                    />
                </label>
                <button type="submit" disabled={busy} className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white disabled:opacity-50">
                    {busy ? 'Uploading…' : 'Submit'}
                </button>
            </form>
        </Shell>
    );
}

export function MarksRegisterViewPage({ Layout }) {
    const { id } = useParams();
    const [payload, setPayload] = useState(null);
    const [err, setErr] = useState('');

    useEffect(() => {
        axios
            .get('/marks-register/show', { headers: xhrJson, params: { id } })
            .then((r) => setPayload({ inner: r.data?.data || null, meta: r.data?.meta || {} }))
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));
    }, [id]);

    const data = payload?.inner;
    const students = data?.students || [];
    const mr = data?.marks_register;

    return (
        <Shell Layout={Layout} wide>
            <Link to="/examination/marks-register" className="text-sm text-blue-600 hover:text-blue-800">
                ← Marks register
            </Link>
            <h1 className="text-2xl font-bold text-slate-900">{payload?.meta?.title || 'Marks register detail'}</h1>
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            {mr ? (
                <p className="text-sm text-slate-600">
                    Register #{mr.id} — class {mr.classes_id}, section {mr.section_id}, exam {mr.exam_type_id}, subject {mr.subject_id}
                </p>
            ) : null}
            <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
                <table className="min-w-full divide-y divide-slate-200 text-sm">
                    <thead className="bg-slate-50 text-left text-xs font-semibold uppercase text-slate-600">
                        <tr>
                            <th className="px-4 py-3">Student</th>
                            <th className="px-4 py-3">Roll</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {students.map((row) => {
                            const st = row.student || row;
                            const name = st.full_name || [st.first_name, st.last_name].filter(Boolean).join(' ');
                            return (
                                <tr key={row.id || st.id}>
                                    <td className="px-4 py-3">{name || st.id}</td>
                                    <td className="px-4 py-3">{st.roll_no || '-'}</td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
        </Shell>
    );
}

export function MarksRegisterEditPage({ Layout }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [meta, setMeta] = useState({});
    const [classId, setClassId] = useState('');
    const [sectionId, setSectionId] = useState('');
    const [examType, setExamType] = useState('');
    const [subject, setSubject] = useState('');
    const [students, setStudents] = useState([]);
    const [titles, setTitles] = useState(['written']);
    const [marks, setMarks] = useState({});
    const [err, setErr] = useState('');
    const [busy, setBusy] = useState(false);

    useEffect(() => {
        axios
            .get(`/marks-register/edit/${id}`, { headers: xhrJson })
            .then((r) => {
                setMeta(r.data?.meta || {});
                const mr = r.data?.data?.marks_register;
                const examAssign = r.data?.data?.examAssign;
                const studs = r.data?.data?.students || [];
                setClassId(String(mr?.classes_id ?? ''));
                setSectionId(String(mr?.section_id ?? ''));
                setExamType(String(mr?.exam_type_id ?? ''));
                setSubject(String(mr?.subject_id ?? ''));
                setStudents(studs);
                const md = examAssign?.mark_distribution || [];
                const tt = md.length ? md.map((x) => x.title) : ['written'];
                setTitles(tt);
                const childs = mr?.marks_register_childs || [];
                const byStu = {};
                childs.forEach((c) => {
                    if (!byStu[c.student_id]) byStu[c.student_id] = {};
                    byStu[c.student_id][c.title] = String(c.mark ?? '');
                });
                studs.forEach((row) => {
                    const sid = row.student_id || row.student?.id;
                    if (!byStu[sid]) byStu[sid] = {};
                    tt.forEach((t) => {
                        if (byStu[sid][t] === undefined) byStu[sid][t] = '';
                    });
                });
                setMarks(byStu);
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));
    }, [id]);

    const setMarkCell = (studentId, title, val) => {
        setMarks((prev) => ({
            ...prev,
            [studentId]: { ...prev[studentId], [title]: val },
        }));
    };

    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        setBusy(true);
        try {
            const student_ids = students.map((row) => row.student_id || row.student?.id).filter(Boolean);
            const marksPayload = {};
            student_ids.forEach((sid) => {
                marksPayload[sid] = titles.reduce((acc, t) => {
                    acc[t] = marks[sid]?.[t] ?? '';
                    return acc;
                }, {});
            });
            await axios.put(
                `/marks-register/update/${id}`,
                {
                    class: classId,
                    section: sectionId,
                    exam_type: examType,
                    subject,
                    student_ids,
                    marks: marksPayload,
                },
                { headers: xhrJson },
            );
            nav('/examination/marks-register');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Save failed.');
        } finally {
            setBusy(false);
        }
    };

    return (
        <Shell Layout={Layout} wide>
            <Link to="/examination/marks-register" className="text-sm text-blue-600 hover:text-blue-800">
                ← Marks register
            </Link>
            <h1 className="text-2xl font-bold text-slate-900">{meta.title || 'Edit marks register'}</h1>
            {titles.length === 0 ? <p className="text-sm text-amber-700">No exam assign / titles found — check exam assignment for this class and subject.</p> : null}
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <form onSubmit={submit} className="space-y-4">
                <div className="grid gap-3 rounded-xl border border-slate-200 bg-white p-4 shadow-sm md:grid-cols-4">
                    <label className="text-sm">
                        Class
                        <input className="mt-1 w-full rounded-md border px-2 py-1" value={classId} onChange={(e) => setClassId(e.target.value)} />
                    </label>
                    <label className="text-sm">
                        Section
                        <input className="mt-1 w-full rounded-md border px-2 py-1" value={sectionId} onChange={(e) => setSectionId(e.target.value)} />
                    </label>
                    <label className="text-sm">
                        Exam type
                        <input className="mt-1 w-full rounded-md border px-2 py-1" value={examType} onChange={(e) => setExamType(e.target.value)} />
                    </label>
                    <label className="text-sm">
                        Subject
                        <input className="mt-1 w-full rounded-md border px-2 py-1" value={subject} onChange={(e) => setSubject(e.target.value)} />
                    </label>
                </div>
                <div className="overflow-auto rounded-xl border border-slate-200 bg-white shadow-sm">
                    <table className="min-w-full divide-y divide-slate-200 text-sm">
                        <thead className="bg-slate-50 text-left text-xs font-semibold uppercase text-slate-600">
                            <tr>
                                <th className="px-4 py-3">Student</th>
                                {titles.map((t) => (
                                    <th key={t} className="px-4 py-3">
                                        {t}
                                    </th>
                                ))}
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                            {students.map((row) => {
                                const st = row.student || row;
                                const sid = row.student_id || st.id;
                                const name = st.full_name || [st.first_name, st.last_name].filter(Boolean).join(' ');
                                return (
                                    <tr key={sid}>
                                        <td className="px-4 py-3 font-medium text-slate-800">{name}</td>
                                        {titles.map((t) => (
                                            <td key={t} className="px-4 py-3">
                                                <input
                                                    className="w-20 rounded border px-2 py-1"
                                                    value={marks[sid]?.[t] ?? ''}
                                                    onChange={(e) => setMarkCell(sid, t, e.target.value)}
                                                />
                                            </td>
                                        ))}
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
                <button type="submit" disabled={busy} className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white disabled:opacity-50">
                    {busy ? 'Saving…' : 'Save'}
                </button>
            </form>
        </Shell>
    );
}
