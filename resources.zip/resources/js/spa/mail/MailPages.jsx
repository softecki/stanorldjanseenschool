import React from 'react';
import { BackendForgotPasswordPage, BackendResetPasswordPage } from '../auth/BackendAuthPages';

export function MailForgotPasswordPage() {
  return <BackendForgotPasswordPage />;
}

export function MailResetPasswordPage() {
  return <BackendResetPasswordPage />;
}

export function MailEmailVerificationPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-100 p-4">
      <div className="w-full max-w-md rounded-lg border bg-white p-5 shadow-sm">
        <h1 className="mb-2 text-xl font-bold">Email verification</h1>
        <p className="text-sm text-slate-600">Check your inbox and click the verification link to continue.</p>
      </div>
    </div>
  );
}
