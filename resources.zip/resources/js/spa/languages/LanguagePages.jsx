import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link, useNavigate, useParams } from 'react-router-dom';

const xhrJson = { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' };

export function LanguagesListPage({ Layout }) {
  const [rows, setRows] = useState([]);
  const [meta, setMeta] = useState({});
  const [err, setErr] = useState('');

  const load = async () => {
    try {
      const r = await axios.get('/languages', { headers: xhrJson });
      setRows(r.data?.data?.data || r.data?.data || []);
      setMeta(r.data?.meta || {});
    } catch (ex) { setErr(ex.response?.data?.message || 'Failed to load.'); }
  };

  useEffect(() => { load(); }, []);

  const remove = async (id) => {
    if (!window.confirm('Delete this language?')) return;
    try { await axios.delete(`/languages/delete/${id}`, { headers: xhrJson }); load(); }
    catch (ex) { setErr(ex.response?.data?.message || 'Delete failed.'); }
  };

  return <Layout><div className="mx-auto max-w-6xl space-y-4 p-6">
    <div className="flex items-center justify-between">
      <h1 className="text-2xl font-bold text-slate-900">{meta.title || 'Languages'}</h1>
      <Link to="/languages/create" className="rounded bg-blue-600 px-4 py-2 text-sm font-medium text-white">Create</Link>
    </div>
    {err ? <p className="text-sm text-red-600">{err}</p> : null}
    <div className="overflow-hidden rounded-xl border bg-white">
      <table className="min-w-full text-sm"><thead className="bg-slate-50 text-left text-xs uppercase text-slate-600"><tr><th className="px-4 py-3">Name</th><th className="px-4 py-3">Code</th><th className="px-4 py-3">Icon</th><th className="px-4 py-3 text-right">Actions</th></tr></thead>
      <tbody>{rows.map((r)=><tr key={r.id} className="border-t"><td className="px-4 py-3">{r.name}</td><td className="px-4 py-3">{r.code}</td><td className="px-4 py-3"><i className={r.icon_class} /></td><td className="px-4 py-3 text-right"><Link className="mr-3 text-blue-600" to={`/languages/${r.id}/edit`}>Edit</Link><Link className="mr-3 text-emerald-700" to={`/languages/${r.id}/terms`}>Terms</Link>{r.code !== 'en' ? <button className="text-red-600" onClick={()=>remove(r.id)}>Delete</button> : null}</td></tr>)}</tbody></table>
    </div>
  </div></Layout>;
}

export function LanguageFormPage({ Layout, edit = false }) {
  const { id } = useParams();
  const nav = useNavigate();
  const [meta, setMeta] = useState({});
  const [form, setForm] = useState({ name: '', code: '', flagIcon: '', direction: 'LTR' });
  const [err, setErr] = useState('');

  useEffect(() => {
    const url = edit ? `/languages/edit/${id}` : '/languages/create';
    axios.get(url, { headers: xhrJson }).then((r) => {
      setMeta(r.data?.meta || {});
      if (edit) {
        const l = r.data?.data?.language || {};
        setForm({ name: l.name || '', code: l.code || '', flagIcon: l.icon_class || '', direction: l.direction || 'LTR' });
      }
    }).catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));
  }, [edit, id]);

  const submit = async (e) => {
    e.preventDefault();
    try {
      if (edit) await axios.put(`/languages/update/${id}`, form, { headers: xhrJson });
      else await axios.post('/languages/store', form, { headers: xhrJson });
      nav('/languages');
    } catch (ex) { setErr(ex.response?.data?.message || 'Save failed.'); }
  };

  return <Layout><div className="mx-auto max-w-3xl space-y-4 p-6">
    <h1 className="text-2xl font-bold text-slate-900">{meta.title || (edit ? 'Edit language' : 'Create language')}</h1>
    {err ? <p className="text-sm text-red-600">{err}</p> : null}
    <form onSubmit={submit} className="grid gap-3 rounded-xl border bg-white p-6">
      <input className="rounded border px-3 py-2" placeholder="Name" value={form.name} onChange={(e)=>setForm({ ...form, name: e.target.value })} required />
      <input className="rounded border px-3 py-2" placeholder="Code" value={form.code} onChange={(e)=>setForm({ ...form, code: e.target.value })} required />
      <select className="rounded border px-3 py-2" value={form.flagIcon} onChange={(e)=>setForm({ ...form, flagIcon: e.target.value })} required>
        <option value="">Select flag icon</option>
        {(meta.flagIcons || []).map((f)=><option key={f.icon_class} value={f.icon_class}>{f.title}</option>)}
      </select>
      <div className="flex gap-4 text-sm"><label className="flex items-center gap-2"><input type="radio" name="direction" checked={String(form.direction).toUpperCase()==='RTL'} onChange={()=>setForm({ ...form, direction: 'RTL' })} /> RTL</label><label className="flex items-center gap-2"><input type="radio" name="direction" checked={String(form.direction).toUpperCase()!=='RTL'} onChange={()=>setForm({ ...form, direction: 'LTR' })} /> LTR</label></div>
      <div className="flex gap-2"><button className="rounded bg-blue-600 px-4 py-2 text-white">Save</button><Link to="/languages" className="rounded border px-4 py-2">Cancel</Link></div>
    </form>
  </div></Layout>;
}

export function LanguageTermsPage({ Layout }) {
  const { id } = useParams();
  const nav = useNavigate();
  const [language, setLanguage] = useState(null);
  const [moduleName, setModuleName] = useState('');
  const [terms, setTerms] = useState({});
  const [err, setErr] = useState('');
  const modules = [
    'common','dashboard','student_info','language','settings','attendance','accounts','examination','parent','teacher','report','website_setup'
  ];

  useEffect(() => {
    axios.get(`/languages/terms/${id}`, { headers: xhrJson }).then((r) => {
      setLanguage(r.data?.data?.language || null);
    }).catch((ex) => setErr(ex.response?.data?.message || 'Failed to load terms page.'));
  }, [id]);

  const loadModuleTerms = async (mod) => {
    if (!language?.code || !mod) return;
    setModuleName(mod);
    try {
      const r = await axios.get('/languages/change-module', { headers: xhrJson, params: { code: language.code, module: mod } });
      setTerms(r.data?.data?.terms || {});
    } catch (ex) { setErr(ex.response?.data?.message || 'Failed to load module terms.'); }
  };

  const submit = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`/languages/update/terms/${language.code}`, { lang_module: moduleName, ...terms }, { headers: xhrJson });
      nav('/languages');
    } catch (ex) { setErr(ex.response?.data?.message || 'Save failed.'); }
  };

  return <Layout><div className="mx-auto max-w-6xl space-y-4 p-6">
    <h1 className="text-2xl font-bold text-slate-900">Language terms</h1>
    {err ? <p className="text-sm text-red-600">{err}</p> : null}
    <form onSubmit={submit} className="space-y-4 rounded-xl border bg-white p-6">
      <select className="w-full max-w-xs rounded border px-3 py-2" value={moduleName} onChange={(e)=>loadModuleTerms(e.target.value)} required>
        <option value="">Select module</option>
        {modules.map((m)=><option key={m} value={m}>{m}</option>)}
      </select>
      <div className="space-y-2">{Object.keys(terms).map((k)=><div key={k} className="grid gap-2 md:grid-cols-2"><input className="rounded border px-3 py-2 text-slate-500" value={k} disabled /><input className="rounded border px-3 py-2" value={terms[k] ?? ''} onChange={(e)=>setTerms({ ...terms, [k]: e.target.value })} /></div>)}</div>
      <div className="flex gap-2"><button className="rounded bg-blue-600 px-4 py-2 text-white" disabled={!moduleName}>Save terms</button><Link to="/languages" className="rounded border px-4 py-2">Cancel</Link></div>
    </form>
  </div></Layout>;
}
