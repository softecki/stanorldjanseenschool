import React from 'react';

/** Page chrome for accounting lists/forms (Tailwind only). */
export function AccountPageHeader({ title, actions }) {
    return (
        <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <h1 className="text-2xl font-bold text-slate-900">{title}</h1>
            {actions ? <div className="flex flex-wrap gap-2">{actions}</div> : null}
        </div>
    );
}

export function AccountCard({ children, className = '' }) {
    return <div className={`rounded-lg border border-slate-200 bg-white shadow-sm ${className}`}>{children}</div>;
}

export function AccountTable({ children }) {
    return (
        <div className="overflow-x-auto rounded-lg border border-slate-200 bg-white">
            <table className="min-w-full divide-y divide-slate-200 text-sm">{children}</table>
        </div>
    );
}

export function AccountTHead({ children }) {
    return <thead className="bg-slate-50 text-left text-xs font-semibold uppercase tracking-wide text-slate-600">{children}</thead>;
}

export function AccountTR({ children, className = '' }) {
    return <tr className={`border-b border-slate-100 hover:bg-slate-50/80 ${className}`}>{children}</tr>;
}

export function AccountTH({ children, className = '' }) {
    return <th className={`px-4 py-3 ${className}`}>{children}</th>;
}

export function AccountTD({ children, className = '' }) {
    return <td className={`px-4 py-3 text-slate-800 ${className}`}>{children}</td>;
}

export function AccountEmptyState({ message }) {
    return (
        <div className="rounded-lg border border-dashed border-slate-200 bg-slate-50 px-6 py-10 text-center text-sm text-slate-500">
            {message || 'No records yet.'}
        </div>
    );
}
