import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import { AcademicFormPage } from '../academic/AcademicPages';
import {
    AccountCard,
    AccountEmptyState,
    AccountPageHeader,
    AccountTable,
    AccountTD,
    AccountTH,
    AccountTHead,
    AccountTR,
} from './components/AccountUi';

const xhrJson = { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' };

function AccountListPage({ Layout, title, endpoint, createTo, editBase }) {
    const [rows, setRows] = useState([]);
    const [err, setErr] = useState('');
    useEffect(() => {
        axios
            .get(endpoint, { headers: xhrJson })
            .then((r) => setRows(r.data?.data?.data || r.data?.data || []))
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load data.'));
    }, [endpoint]);

    return (
        <Layout>
            <div className="mx-auto max-w-6xl p-6">
                <AccountPageHeader
                    title={title}
                    actions={
                        <Link
                            to={createTo}
                            className="inline-flex rounded-md bg-blue-600 px-3 py-2 text-sm font-medium text-white shadow-sm hover:bg-blue-700"
                        >
                            Create
                        </Link>
                    }
                />
                {err ? <p className="mb-4 text-sm text-red-600">{err}</p> : null}
                <AccountCard>
                    {!rows.length ? (
                        <AccountEmptyState />
                    ) : (
                        <AccountTable>
                            <AccountTHead>
                                <AccountTR>
                                    <AccountTH>Name</AccountTH>
                                    <AccountTH className="text-right">Actions</AccountTH>
                                </AccountTR>
                            </AccountTHead>
                            <tbody className="divide-y divide-slate-100 bg-white">
                                {rows.map((row) => (
                                    <AccountTR key={row.id}>
                                        <AccountTD>{row.name || row.title || `#${row.id}`}</AccountTD>
                                        <AccountTD className="text-right">
                                            <Link
                                                className="font-medium text-blue-600 hover:text-blue-800"
                                                to={`${editBase}/${row.id}/edit`}
                                            >
                                                Edit
                                            </Link>
                                        </AccountTD>
                                    </AccountTR>
                                ))}
                            </tbody>
                        </AccountTable>
                    )}
                </AccountCard>
            </div>
        </Layout>
    );
}

export function DepositsPage({ Layout }) {
    return (
        <AccountListPage Layout={Layout} title="Deposits" endpoint="/deposit" createTo="/accounts/deposits/create" editBase="/accounts/deposits" />
    );
}
export function DepositFormPage({ Layout }) {
    return (
        <AcademicFormPage
            Layout={Layout}
            titleCreate="Create Deposit"
            titleEdit="Edit Deposit"
            loadEndpoint="/deposit"
            storeEndpoint="/deposit/store"
            updateEndpoint="/deposit/update"
            backTo="/accounts/deposits"
        />
    );
}

export function PaymentsPage({ Layout }) {
    return (
        <AccountListPage Layout={Layout} title="Payments" endpoint="/payments" createTo="/accounts/payments/create" editBase="/accounts/payments" />
    );
}
export function PaymentFormPage({ Layout }) {
    return (
        <AcademicFormPage
            Layout={Layout}
            titleCreate="Create Payment"
            titleEdit="Edit Payment"
            loadEndpoint="/payments"
            storeEndpoint="/payments/store"
            updateEndpoint="/payments/update"
            backTo="/accounts/payments"
        />
    );
}

export function TransactionsPage({ Layout }) {
    return (
        <AccountListPage
            Layout={Layout}
            title="Transactions"
            endpoint="/transactions"
            createTo="/accounts/transactions/create"
            editBase="/accounts/transactions"
        />
    );
}
export function TransactionFormPage({ Layout }) {
    return (
        <AcademicFormPage
            Layout={Layout}
            titleCreate="Create Transaction"
            titleEdit="Edit Transaction"
            loadEndpoint="/transactions"
            storeEndpoint="/transactions/store"
            updateEndpoint="/transactions/update"
            backTo="/accounts/transactions"
        />
    );
}

export function SuppliersPage({ Layout }) {
    return (
        <AccountListPage Layout={Layout} title="Suppliers" endpoint="/suppliers" createTo="/accounts/suppliers/create" editBase="/accounts/suppliers" />
    );
}
export function SupplierFormPage({ Layout }) {
    return (
        <AcademicFormPage
            Layout={Layout}
            titleCreate="Create Supplier"
            titleEdit="Edit Supplier"
            loadEndpoint="/suppliers"
            storeEndpoint="/suppliers/store"
            updateEndpoint="/suppliers/update"
            backTo="/accounts/suppliers"
        />
    );
}

export function InvoicesPage({ Layout }) {
    return (
        <AccountListPage Layout={Layout} title="Invoices" endpoint="/invoices" createTo="/accounts/invoices/create" editBase="/accounts/invoices" />
    );
}
export function InvoiceFormPage({ Layout }) {
    return (
        <AcademicFormPage
            Layout={Layout}
            titleCreate="Create Invoice"
            titleEdit="Edit Invoice"
            loadEndpoint="/invoices"
            storeEndpoint="/invoices/store"
            updateEndpoint="/invoices/update"
            backTo="/accounts/invoices"
        />
    );
}
