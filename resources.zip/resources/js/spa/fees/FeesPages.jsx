import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link, useNavigate, useParams } from 'react-router-dom';

const xhrJson = { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' };

export function FeesCollectionsPage({ Layout }) {
    const [rows, setRows] = useState([]);
    const [meta, setMeta] = useState({});
    const [err, setErr] = useState('');

    useEffect(() => {
        axios
            .get('/fees-collect', { headers: xhrJson })
            .then((r) => {
                setRows(r.data?.data?.data || r.data?.data || []);
                setMeta(r.data?.meta || {});
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load fees collections.'));
    }, []);

    return (
        <Layout>
            <div className="mx-auto max-w-7xl p-6">
                <div className="mb-4 flex items-center justify-between">
                    <h1 className="text-2xl font-bold text-slate-900">{meta.title || 'Fees Collections'}</h1>
                    <div className="flex flex-wrap gap-2">
                        <Link to="/fees/assignments" className="rounded-md border border-slate-300 px-3 py-2 text-sm text-slate-700 shadow-sm hover:bg-slate-50">
                            Assignments
                        </Link>
                        <Link to="/fees/types" className="rounded-md border border-slate-300 px-3 py-2 text-sm text-slate-700 shadow-sm hover:bg-slate-50">
                            Types
                        </Link>
                        <Link to="/fees/groups" className="rounded-md border border-slate-300 px-3 py-2 text-sm text-slate-700 shadow-sm hover:bg-slate-50">
                            Groups
                        </Link>
                        <Link to="/fees/masters" className="rounded-md border border-slate-300 px-3 py-2 text-sm text-slate-700 shadow-sm hover:bg-slate-50">
                            Masters
                        </Link>
                    </div>
                </div>
                {err ? <p className="text-sm text-red-600">{err}</p> : null}
                <div className="overflow-auto rounded-xl border border-slate-200 bg-white shadow-sm">
                    <table className="min-w-full divide-y divide-slate-200 text-sm">
                        <thead className="bg-slate-50 text-left text-xs font-semibold uppercase text-slate-600">
                            <tr>
                                <th className="px-4 py-3">ID</th>
                                <th className="px-4 py-3">Student</th>
                                <th className="px-4 py-3">Amount</th>
                                <th className="px-4 py-3" />
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                            {rows.map((r) => (
                                <tr key={r.id} className="hover:bg-slate-50/80">
                                    <td className="px-4 py-3">{r.id}</td>
                                    <td className="px-4 py-3">{r.student_name || r.student?.full_name || '-'}</td>
                                    <td className="px-4 py-3">{r.paid_amount || r.amount || '-'}</td>
                                    <td className="px-4 py-3 text-right">
                                        <Link className="font-medium text-blue-600 hover:text-blue-800" to={`/fees/collections/${r.id}/edit`}>
                                            Edit
                                        </Link>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </Layout>
    );
}

export function FeesCollectionEditPage({ Layout }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [data, setData] = useState(null);
    const [err, setErr] = useState('');
    useEffect(() => {
        axios
            .get(`/fees-collect/edit/${id}`, { headers: xhrJson })
            .then((r) => setData(r.data?.data || {}))
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));
    }, [id]);
    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        try {
            await axios.put(`/fees-collect/update/${id}`, data, { headers: xhrJson });
            nav('/fees/collections');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Update failed.');
        }
    };
    return (
        <Layout>
            <div className="mx-auto max-w-3xl p-6">
                <h1 className="text-2xl font-bold text-slate-900">Edit collection</h1>
                {err ? <p className="mt-2 text-sm text-red-600">{err}</p> : null}
                <form onSubmit={submit} className="mt-4 grid gap-3 rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
                    <label className="text-sm font-medium text-slate-700">
                        Paid amount
                        <input
                            className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                            value={data?.paid_amount || ''}
                            onChange={(e) => setData({ ...data, paid_amount: e.target.value })}
                        />
                    </label>
                    <button type="submit" className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700">
                        Save
                    </button>
                </form>
            </div>
        </Layout>
    );
}

export function FeesAssignmentsPage({ Layout }) {
    const [rows, setRows] = useState([]);
    const [meta, setMeta] = useState({});
    useEffect(() => {
        axios.get('/fees-assign', { headers: xhrJson }).then((r) => {
            setRows(r.data?.data?.data || r.data?.data || []);
            setMeta(r.data?.meta || {});
        });
    }, []);
    return (
        <Layout>
            <div className="mx-auto max-w-7xl p-6">
                <div className="mb-4 flex items-center justify-between">
                    <h1 className="text-2xl font-bold text-slate-900">{meta.title || 'Fees Assignments'}</h1>
                    <Link
                        to="/fees/assignments/create"
                        className="inline-flex rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
                    >
                        Create
                    </Link>
                </div>
                <div className="overflow-auto rounded-xl border border-slate-200 bg-white shadow-sm">
                    <table className="min-w-full divide-y divide-slate-200 text-sm">
                        <thead className="bg-slate-50 text-left text-xs font-semibold uppercase text-slate-600">
                            <tr>
                                <th className="px-4 py-3">ID</th>
                                <th className="px-4 py-3">Title</th>
                                <th className="px-4 py-3" />
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                            {rows.map((r) => (
                                <tr key={r.id} className="hover:bg-slate-50/80">
                                    <td className="px-4 py-3">{r.id}</td>
                                    <td className="px-4 py-3">{r.name || r.title || '-'}</td>
                                    <td className="px-4 py-3 text-right">
                                        <Link className="font-medium text-blue-600 hover:text-blue-800" to={`/fees/assignments/${r.id}/edit`}>
                                            Edit
                                        </Link>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </Layout>
    );
}

export function FeesAssignmentFormPage({ Layout, edit = false }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [meta, setMeta] = useState({});
    const [form, setForm] = useState({});
    const [err, setErr] = useState('');
    useEffect(() => {
        const url = edit ? `/fees-assign/edit/${id}` : '/fees-assign/create';
        axios
            .get(url, { headers: xhrJson })
            .then((r) => {
                setMeta(r.data?.meta || {});
                if (edit) setForm(r.data?.data || {});
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));
    }, [edit, id]);
    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        try {
            if (edit) await axios.put(`/fees-assign/update/${id}`, form, { headers: xhrJson });
            else await axios.post('/fees-assign/store', form, { headers: xhrJson });
            nav('/fees/assignments');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Save failed.');
        }
    };
    return (
        <Layout>
            <div className="mx-auto max-w-3xl p-6">
                <h1 className="text-2xl font-bold text-slate-900">{edit ? 'Edit assignment' : 'Create assignment'}</h1>
                {err ? <p className="mt-2 text-sm text-red-600">{err}</p> : null}
                <form onSubmit={submit} className="mt-4 grid gap-3 rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
                    <label className="text-sm font-medium text-slate-700">
                        Class
                        <select
                            className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                            value={form.classes_id || ''}
                            onChange={(e) => setForm({ ...form, classes_id: e.target.value })}
                        >
                            <option value="">Select class</option>
                            {(meta.classes || []).map((c) => (
                                <option key={c.id || c.classes_id} value={c.id || c.classes_id}>
                                    {c.name || c.title}
                                </option>
                            ))}
                        </select>
                    </label>
                    <label className="text-sm font-medium text-slate-700">
                        Fees group
                        <select
                            className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                            value={form.fees_group_id || ''}
                            onChange={(e) => setForm({ ...form, fees_group_id: e.target.value })}
                        >
                            <option value="">Select fees group</option>
                            {(meta.fees_groups || []).map((g) => (
                                <option key={g.id} value={g.id}>
                                    {g.name}
                                </option>
                            ))}
                        </select>
                    </label>
                    <button type="submit" className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700">
                        {edit ? 'Update' : 'Create'}
                    </button>
                </form>
            </div>
        </Layout>
    );
}

export function FeesTypesPage({ Layout }) {
    const [rows, setRows] = useState([]);
    const [meta, setMeta] = useState({});
    useEffect(() => {
        axios.get('/fees-type', { headers: xhrJson }).then((r) => {
            setRows(r.data?.data?.data || r.data?.data || []);
            setMeta(r.data?.meta || {});
        });
    }, []);
    return (
        <Layout>
            <div className="mx-auto max-w-6xl p-6">
                <div className="mb-4 flex items-center justify-between">
                    <h1 className="text-2xl font-bold text-slate-900">{meta.title || 'Fees Types'}</h1>
                    <Link
                        to="/fees/types/create"
                        className="inline-flex rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
                    >
                        Create
                    </Link>
                </div>
                <div className="divide-y divide-slate-100 rounded-xl border border-slate-200 bg-white shadow-sm">
                    {rows.map((t) => (
                        <div className="px-4 py-3 text-sm hover:bg-slate-50/80" key={t.id}>
                            <Link className="font-medium text-blue-600 hover:text-blue-800" to={`/fees/types/${t.id}/edit`}>
                                {t.name || t.title || `Type #${t.id}`}
                            </Link>
                        </div>
                    ))}
                </div>
            </div>
        </Layout>
    );
}

export function FeesTypeFormPage({ Layout, edit = false }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [meta, setMeta] = useState({});
    const [form, setForm] = useState({});
    const [err, setErr] = useState('');
    useEffect(() => {
        const url = edit ? `/fees-type/edit/${id}` : '/fees-type/create';
        axios
            .get(url, { headers: xhrJson })
            .then((r) => {
                setMeta(r.data?.meta || {});
                if (edit) setForm(r.data?.data || {});
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));
    }, [edit, id]);
    const submit = async (e) => {
        e.preventDefault();
        try {
            if (edit) await axios.put(`/fees-type/update/${id}`, form, { headers: xhrJson });
            else await axios.post('/fees-type/store', form, { headers: xhrJson });
            nav('/fees/types');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Save failed.');
        }
    };
    return (
        <Layout>
            <div className="mx-auto max-w-3xl p-6">
                <h1 className="text-2xl font-bold text-slate-900">{edit ? 'Edit fees type' : 'Create fees type'}</h1>
                {err ? <p className="mt-2 text-sm text-red-600">{err}</p> : null}
                <form onSubmit={submit} className="mt-4 grid gap-3 rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
                    <label className="text-sm font-medium text-slate-700">
                        Name
                        <input
                            className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                            placeholder="Type name"
                            value={form.name || ''}
                            onChange={(e) => setForm({ ...form, name: e.target.value })}
                        />
                    </label>
                    <label className="text-sm font-medium text-slate-700">
                        Class
                        <select
                            className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                            value={form.class_id || ''}
                            onChange={(e) => setForm({ ...form, class_id: e.target.value })}
                        >
                            <option value="">Select class</option>
                            {(meta.classes || []).map((c) => (
                                <option key={c.id} value={c.id}>
                                    {c.name}
                                </option>
                            ))}
                        </select>
                    </label>
                    <button type="submit" className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700">
                        {edit ? 'Update' : 'Create'}
                    </button>
                </form>
            </div>
        </Layout>
    );
}

export function FeesGroupsPage({ Layout }) {
    const [rows, setRows] = useState([]);
    const [meta, setMeta] = useState({});
    useEffect(() => {
        axios.get('/fees-group', { headers: xhrJson }).then((r) => {
            setRows(r.data?.data?.data || r.data?.data || []);
            setMeta(r.data?.meta || {});
        });
    }, []);
    return (
        <Layout>
            <div className="mx-auto max-w-6xl p-6">
                <div className="mb-4 flex items-center justify-between">
                    <h1 className="text-2xl font-bold text-slate-900">{meta.title || 'Fees Groups'}</h1>
                    <Link
                        to="/fees/groups/create"
                        className="inline-flex rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
                    >
                        Create
                    </Link>
                </div>
                <div className="divide-y divide-slate-100 rounded-xl border border-slate-200 bg-white shadow-sm">
                    {rows.map((g) => (
                        <div className="px-4 py-3 text-sm hover:bg-slate-50/80" key={g.id}>
                            <Link className="font-medium text-blue-600 hover:text-blue-800" to={`/fees/groups/${g.id}/edit`}>
                                {g.name || g.title || `Group #${g.id}`}
                            </Link>
                        </div>
                    ))}
                </div>
            </div>
        </Layout>
    );
}

export function FeesGroupFormPage({ Layout, edit = false }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [form, setForm] = useState({});
    const [err, setErr] = useState('');
    useEffect(() => {
        const url = edit ? `/fees-group/edit/${id}` : '/fees-group/create';
        axios
            .get(url, { headers: xhrJson })
            .then((r) => {
                if (edit) setForm(r.data?.data || {});
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));
    }, [edit, id]);
    const submit = async (e) => {
        e.preventDefault();
        try {
            if (edit) await axios.put(`/fees-group/update/${id}`, form, { headers: xhrJson });
            else await axios.post('/fees-group/store', form, { headers: xhrJson });
            nav('/fees/groups');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Save failed.');
        }
    };
    return (
        <Layout>
            <div className="mx-auto max-w-3xl p-6">
                <h1 className="text-2xl font-bold text-slate-900">{edit ? 'Edit fees group' : 'Create fees group'}</h1>
                {err ? <p className="mt-2 text-sm text-red-600">{err}</p> : null}
                <form onSubmit={submit} className="mt-4 grid gap-3 rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
                    <label className="text-sm font-medium text-slate-700">
                        Name
                        <input
                            className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                            placeholder="Group name"
                            value={form.name || ''}
                            onChange={(e) => setForm({ ...form, name: e.target.value })}
                        />
                    </label>
                    <button type="submit" className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700">
                        {edit ? 'Update' : 'Create'}
                    </button>
                </form>
            </div>
        </Layout>
    );
}

export function FeesMastersPage({ Layout }) {
    const [rows, setRows] = useState([]);
    const [meta, setMeta] = useState({});
    useEffect(() => {
        axios.get('/fees-master', { headers: xhrJson }).then((r) => {
            setRows(r.data?.data?.data || r.data?.data || []);
            setMeta(r.data?.meta || {});
        });
    }, []);
    return (
        <Layout>
            <div className="mx-auto max-w-6xl p-6">
                <div className="mb-4 flex items-center justify-between">
                    <h1 className="text-2xl font-bold text-slate-900">{meta.title || 'Fees Masters'}</h1>
                    <Link
                        to="/fees/masters/create"
                        className="inline-flex rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
                    >
                        Create
                    </Link>
                </div>
                <div className="divide-y divide-slate-100 rounded-xl border border-slate-200 bg-white shadow-sm">
                    {rows.map((m) => (
                        <div className="px-4 py-3 text-sm hover:bg-slate-50/80" key={m.id}>
                            <Link className="font-medium text-blue-600 hover:text-blue-800" to={`/fees/masters/${m.id}/edit`}>
                                {m.name || m.title || `Master #${m.id}`}
                            </Link>
                        </div>
                    ))}
                </div>
            </div>
        </Layout>
    );
}

export function FeesMasterFormPage({ Layout, edit = false }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [meta, setMeta] = useState({});
    const [form, setForm] = useState({});
    const [err, setErr] = useState('');
    useEffect(() => {
        const url = edit ? `/fees-master/edit/${id}` : '/fees-master/create';
        axios
            .get(url, { headers: xhrJson })
            .then((r) => {
                if (edit) {
                    setForm(r.data?.data || {});
                    setMeta(r.data?.meta || {});
                } else {
                    setMeta(r.data?.meta || {});
                }
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));
    }, [edit, id]);
    const submit = async (e) => {
        e.preventDefault();
        try {
            if (edit) await axios.put(`/fees-master/update/${id}`, form, { headers: xhrJson });
            else await axios.post('/fees-master/store', form, { headers: xhrJson });
            nav('/fees/masters');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Save failed.');
        }
    };
    return (
        <Layout>
            <div className="mx-auto max-w-3xl p-6">
                <h1 className="text-2xl font-bold text-slate-900">{edit ? 'Edit fees master' : 'Create fees master'}</h1>
                {err ? <p className="mt-2 text-sm text-red-600">{err}</p> : null}
                <form onSubmit={submit} className="mt-4 grid gap-3 rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
                    <label className="text-sm font-medium text-slate-700">
                        Name
                        <input
                            className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                            placeholder="Name"
                            value={form.name || ''}
                            onChange={(e) => setForm({ ...form, name: e.target.value })}
                        />
                    </label>
                    <label className="text-sm font-medium text-slate-700">
                        Fees group
                        <select
                            className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                            value={form.fees_group_id || ''}
                            onChange={(e) => setForm({ ...form, fees_group_id: e.target.value })}
                        >
                            <option value="">Select fees group</option>
                            {(meta.fees_groups || []).map((g) => (
                                <option key={g.id} value={g.id}>
                                    {g.name || g.title}
                                </option>
                            ))}
                        </select>
                    </label>
                    <label className="text-sm font-medium text-slate-700">
                        Fees type
                        <select
                            className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                            value={form.fees_type_id || ''}
                            onChange={(e) => setForm({ ...form, fees_type_id: e.target.value })}
                        >
                            <option value="">Select fees type</option>
                            {(meta.fees_types || []).map((t) => (
                                <option key={t.id} value={t.id}>
                                    {t.name || t.title}
                                </option>
                            ))}
                        </select>
                    </label>
                    <button type="submit" className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700">
                        {edit ? 'Update' : 'Create'}
                    </button>
                </form>
            </div>
        </Layout>
    );
}
