import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link, useNavigate, useParams } from 'react-router-dom';

const xhrJson = { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' };

export function HomeworkListPage({ Layout }) {
  const [rows, setRows] = useState([]);
  const [meta, setMeta] = useState({});
  const [filters, setFilters] = useState({ class: '', section: '', subject: '' });
  const [students, setStudents] = useState([]);
  const [homeworkId, setHomeworkId] = useState(null);
  const [marks, setMarks] = useState({});
  const [err, setErr] = useState('');

  const load = async () => {
    try {
      const r = await axios.get('/homework', { headers: xhrJson });
      setRows(r.data?.data?.data || r.data?.data || []);
      setMeta(r.data?.meta || {});
    } catch (ex) { setErr(ex.response?.data?.message || 'Failed to load.'); }
  };
  useEffect(() => { load(); }, []);

  const search = async (e) => {
    e.preventDefault();
    try {
      const r = await axios.post('/homework/search', filters, { headers: xhrJson });
      setRows(r.data?.data?.data || r.data?.data || []);
      setMeta((m) => ({ ...m, ...(r.data?.meta || {}) }));
    } catch (ex) { setErr(ex.response?.data?.message || 'Search failed.'); }
  };

  const remove = async (id) => {
    if (!window.confirm('Delete this homework?')) return;
    try { await axios.delete(`/homework/delete/${id}`, { headers: xhrJson }); load(); }
    catch (ex) { setErr(ex.response?.data?.message || 'Delete failed.'); }
  };

  const openEvaluation = async (id) => {
    setHomeworkId(id);
    try {
      const r = await axios.post('/homework/students', { homework_id: id }, { headers: xhrJson });
      const list = r.data?.students || [];
      setStudents(list);
      const pre = {};
      list.forEach((s) => {
        const hw = s.homework_student || s.homeworkStudent;
        pre[s.student_id] = hw?.marks ?? '';
      });
      setMarks(pre);
    } catch (ex) { setErr(ex.response?.data?.message || 'Failed to load students.'); }
  };

  const submitEvaluation = async () => {
    const ids = students.map((s) => s.student_id);
    const vals = ids.map((id) => marks[id] ?? '');
    try {
      await axios.post('/homework/evaluation/submit', { homework_id: homeworkId, students: ids, marks: vals }, { headers: xhrJson });
      setHomeworkId(null);
      setStudents([]);
    } catch (ex) { setErr(ex.response?.data?.message || 'Evaluation failed.'); }
  };

  return <Layout><div className="mx-auto max-w-7xl space-y-4 p-6">
    <div className="flex items-center justify-between"><h1 className="text-2xl font-bold text-slate-900">{meta.title || 'Homework'}</h1><Link to="/homework/create" className="rounded bg-blue-600 px-4 py-2 text-sm font-medium text-white">Create</Link></div>
    <form onSubmit={search} className="grid gap-2 rounded-xl border bg-white p-4 md:grid-cols-4">
      <select className="rounded border px-3 py-2" value={filters.class} onChange={(e)=>setFilters({ ...filters, class: e.target.value })}><option value="">Class</option>{(meta.classes || []).map((c)=><option key={c.id} value={c.id}>{c.name}</option>)}</select>
      <input className="rounded border px-3 py-2" placeholder="Section id" value={filters.section} onChange={(e)=>setFilters({ ...filters, section: e.target.value })} />
      <input className="rounded border px-3 py-2" placeholder="Subject id" value={filters.subject} onChange={(e)=>setFilters({ ...filters, subject: e.target.value })} />
      <button className="rounded bg-slate-800 px-4 py-2 text-sm font-medium text-white">Search</button>
    </form>
    {err ? <p className="text-sm text-red-600">{err}</p> : null}
    <div className="overflow-hidden rounded-xl border bg-white"><table className="min-w-full text-sm"><thead className="bg-slate-50 text-left text-xs uppercase text-slate-600"><tr><th className="px-4 py-3">Class/Section</th><th className="px-4 py-3">Subject</th><th className="px-4 py-3">Date</th><th className="px-4 py-3 text-right">Actions</th></tr></thead><tbody>{rows.map((r)=><tr key={r.id} className="border-t"><td className="px-4 py-3">{r.classes_id}/{r.section_id}</td><td className="px-4 py-3">{r.subject_id}</td><td className="px-4 py-3">{r.date}</td><td className="px-4 py-3 text-right"><button className="mr-3 text-emerald-700" onClick={()=>openEvaluation(r.id)}>Evaluate</button><Link className="mr-3 text-blue-600" to={`/homework/${r.id}/edit`}>Edit</Link><button className="text-red-600" onClick={()=>remove(r.id)}>Delete</button></td></tr>)}</tbody></table></div>

    {homeworkId ? <div className="rounded-xl border bg-white p-4"><h2 className="mb-3 text-lg font-semibold">Evaluation</h2><div className="space-y-2">{students.map((s)=>{const st=s.student||{}; const name=st.full_name||`${st.first_name||''} ${st.last_name||''}`.trim()||`Student ${s.student_id}`; return <div key={s.student_id} className="flex items-center justify-between border-b py-2"><span>{name}</span><input className="w-24 rounded border px-2 py-1" value={marks[s.student_id] ?? ''} onChange={(e)=>setMarks({ ...marks, [s.student_id]: e.target.value })} /></div>;})}</div><div className="mt-3 flex gap-2"><button onClick={submitEvaluation} className="rounded bg-blue-600 px-4 py-2 text-white">Submit</button><button onClick={()=>setHomeworkId(null)} className="rounded border px-4 py-2">Close</button></div></div> : null}
  </div></Layout>;
}

export function HomeworkFormPage({ Layout, edit = false }) {
  const { id } = useParams();
  const nav = useNavigate();
  const [meta, setMeta] = useState({});
  const [form, setForm] = useState({ class: '', section: '', subject: '', date: '', submission_date: '', marks: '', status: 1, description: '' });
  const [file, setFile] = useState(null);
  const [err, setErr] = useState('');

  useEffect(() => {
    const url = edit ? `/homework/edit/${id}` : '/homework/create';
    axios.get(url, { headers: xhrJson }).then((r) => {
      setMeta(r.data?.meta || {});
      if (edit) {
        const h = r.data?.data?.homework || {};
        setForm({ class: h.classes_id || '', section: h.section_id || '', subject: h.subject_id || '', date: h.date || '', submission_date: h.submission_date || '', marks: h.marks || '', status: Number(h.status ?? 1), description: h.description || '' });
      }
    }).catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));
  }, [edit, id]);

  const submit = async (e) => {
    e.preventDefault();
    try {
      const fd = new FormData();
      Object.entries(form).forEach(([k, v]) => fd.append(k, v ?? ''));
      if (file) fd.append('document', file);
      if (edit) { fd.append('_method', 'PUT'); await axios.post(`/homework/update/${id}`, fd, { headers: { ...xhrJson, 'Content-Type': 'multipart/form-data' } }); }
      else { await axios.post('/homework/store', fd, { headers: { ...xhrJson, 'Content-Type': 'multipart/form-data' } }); }
      nav('/homework');
    } catch (ex) { setErr(ex.response?.data?.message || 'Save failed.'); }
  };

  return <Layout><div className="mx-auto max-w-3xl space-y-4 p-6">
    <h1 className="text-2xl font-bold text-slate-900">{meta.title || (edit ? 'Edit homework' : 'Create homework')}</h1>
    {err ? <p className="text-sm text-red-600">{err}</p> : null}
    <form onSubmit={submit} className="grid gap-3 rounded-xl border bg-white p-6">
      <select className="rounded border px-3 py-2" value={form.class} onChange={(e)=>setForm({ ...form, class: e.target.value })} required><option value="">Select class</option>{(meta.classes || []).map((c)=>{const v=c.class?.id || c.id; const n=c.class?.name || c.name; return <option key={v} value={v}>{n}</option>;})}</select>
      <input className="rounded border px-3 py-2" placeholder="Section id" value={form.section} onChange={(e)=>setForm({ ...form, section: e.target.value })} required />
      <input className="rounded border px-3 py-2" placeholder="Subject id" value={form.subject} onChange={(e)=>setForm({ ...form, subject: e.target.value })} required />
      <div className="grid gap-3 md:grid-cols-2"><input type="date" className="rounded border px-3 py-2" value={form.date} onChange={(e)=>setForm({ ...form, date: e.target.value })} required /><input type="date" className="rounded border px-3 py-2" value={form.submission_date} onChange={(e)=>setForm({ ...form, submission_date: e.target.value })} /></div>
      <input className="rounded border px-3 py-2" placeholder="Marks" value={form.marks} onChange={(e)=>setForm({ ...form, marks: e.target.value })} required />
      <input type="file" className="rounded border px-3 py-2" onChange={(e)=>setFile(e.target.files?.[0] || null)} />
      <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={!!Number(form.status)} onChange={(e)=>setForm({ ...form, status: e.target.checked ? 1 : 0 })} /> Active</label>
      <textarea className="rounded border px-3 py-2" placeholder="Description" value={form.description} onChange={(e)=>setForm({ ...form, description: e.target.value })} />
      <div className="flex gap-2"><button className="rounded bg-blue-600 px-4 py-2 text-white">Save</button><Link to="/homework" className="rounded border px-4 py-2">Cancel</Link></div>
    </form>
  </div></Layout>;
}
