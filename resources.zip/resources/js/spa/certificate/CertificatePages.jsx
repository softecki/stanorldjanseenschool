import React, { useEffect, useMemo, useState } from 'react';
import axios from 'axios';
import { Link, useNavigate, useParams } from 'react-router-dom';

const xhrJson = { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' };

function Shell({ Layout, children }) {
    return (
        <Layout>
            <div className="mx-auto max-w-5xl space-y-6 p-6">{children}</div>
        </Layout>
    );
}

function paginateRows(r) {
    const p = r.data?.data;
    if (Array.isArray(p?.data)) return p.data;
    if (Array.isArray(p)) return p;
    return [];
}

function splitTitle(title) {
    if (!title) return { first: '', rest: '' };
    const words = String(title).trim().split(/\s+/);
    return { first: words[0] || '', rest: words.slice(1).join(' ') };
}

function buildDescriptionHtml(cert, row, sessionName, settings) {
    let d = cert.description || '';
    const name = `${row.student?.first_name || ''} ${row.student?.last_name || ''}`.trim();
    d = d.replace(/\[student_name\]/g, name);
    d = d.replace(/\[class_name\]/g, row.class?.name || '');
    d = d.replace(/\[section_name\]/g, row.section?.name || '');
    d = d.replace(/\[school_name\]/g, settings?.application_name || '');
    d = d.replace(/\[session\]/g, sessionName || '');
    d = d.replace(/\[school_address\]/g, settings?.address || '');
    return d;
}

export function CertificateListPage({ Layout }) {
    const [rows, setRows] = useState([]);
    const [meta, setMeta] = useState({});
    const [err, setErr] = useState('');
    const load = () =>
        axios
            .get('/certificate', { headers: xhrJson })
            .then((r) => {
                setRows(paginateRows(r));
                setMeta(r.data?.meta ?? {});
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load certificates.'));

    useEffect(() => {
        load();
    }, []);

    const remove = async (id) => {
        if (!window.confirm('Delete this certificate template?')) return;
        try {
            await axios.delete(`/certificate/delete/${id}`, { headers: xhrJson });
            load();
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Delete failed.');
        }
    };

    return (
        <Shell Layout={Layout}>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900">{meta.title || 'Certificates'}</h1>
                    <p className="text-sm text-slate-500">Design templates and generate for students.</p>
                </div>
                <div className="flex flex-wrap gap-2">
                    <Link
                        to="/certificate/generate"
                        className="inline-flex rounded-md border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                    >
                        Generate
                    </Link>
                    <Link
                        to="/certificate/create"
                        className="inline-flex rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
                    >
                        Create template
                    </Link>
                </div>
            </div>
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
                <table className="min-w-full divide-y divide-slate-200 text-sm">
                    <thead className="bg-slate-50 text-left text-xs font-semibold uppercase text-slate-600">
                        <tr>
                            <th className="px-4 py-3">Title</th>
                            <th className="px-4 py-3 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {rows.map((row) => (
                            <tr key={row.id} className="hover:bg-slate-50/80">
                                <td className="px-4 py-3 font-medium text-slate-900">{row.title}</td>
                                <td className="px-4 py-3 text-right">
                                    <Link className="mr-3 font-medium text-blue-600 hover:text-blue-800" to={`/certificate/${row.id}/edit`}>
                                        Edit
                                    </Link>
                                    <button type="button" className="text-sm text-red-600 hover:text-red-800" onClick={() => remove(row.id)}>
                                        Delete
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                {!rows.length ? <p className="px-4 py-8 text-center text-sm text-slate-500">No certificate templates yet.</p> : null}
            </div>
        </Shell>
    );
}

export function CertificateFormPage({ Layout, edit = false }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [meta, setMeta] = useState({});
    const [form, setForm] = useState({
        title: '',
        top_text: '',
        description: '',
        bottom_left_text: '',
        bottom_right_text: '',
        logo: true,
        name: true,
    });
    const [files, setFiles] = useState({});
    const [err, setErr] = useState('');
    const [busy, setBusy] = useState(false);

    useEffect(() => {
        if (!edit) {
            axios.get('/certificate/create', { headers: xhrJson }).then((r) => setMeta(r.data?.meta || {}));
            return;
        }
        axios
            .get(`/certificate/edit/${id}`, { headers: xhrJson })
            .then((r) => {
                setMeta(r.data?.meta || {});
                const c = r.data?.data?.certificate ?? r.data?.data;
                setForm({
                    title: c?.title ?? '',
                    top_text: c?.top_text ?? '',
                    description: c?.description ?? '',
                    bottom_left_text: c?.bottom_left_text ?? '',
                    bottom_right_text: c?.bottom_right_text ?? '',
                    logo: !!c?.logo,
                    name: !!c?.name,
                });
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));
    }, [edit, id]);

    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        setBusy(true);
        try {
            const fd = new FormData();
            fd.append('title', form.title);
            fd.append('top_text', form.top_text);
            fd.append('description', form.description);
            fd.append('bottom_left_text', form.bottom_left_text);
            fd.append('bottom_right_text', form.bottom_right_text);
            fd.append('logo', form.logo ? 'on' : '');
            fd.append('name', form.name ? 'on' : '');
            if (files.bg_image) fd.append('bg_image', files.bg_image);
            if (files.bottom_left_signature) fd.append('bottom_left_signature', files.bottom_left_signature);
            if (files.bottom_right_signature) fd.append('bottom_right_signature', files.bottom_right_signature);

            if (edit) {
                fd.append('_method', 'PUT');
                await axios.post(`/certificate/update/${id}`, fd, {
                    headers: { ...xhrJson, 'Content-Type': 'multipart/form-data' },
                });
            } else {
                await axios.post('/certificate/store', fd, {
                    headers: { ...xhrJson, 'Content-Type': 'multipart/form-data' },
                });
            }
            nav('/certificate');
        } catch (ex) {
            const msg = ex.response?.data?.message || ex.response?.data?.errors;
            setErr(typeof msg === 'object' ? JSON.stringify(msg) : msg || 'Save failed.');
        } finally {
            setBusy(false);
        }
    };

    return (
        <Shell Layout={Layout}>
            <h1 className="text-2xl font-bold text-slate-900">{meta.title || (edit ? 'Edit certificate' : 'Create certificate')}</h1>
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <form onSubmit={submit} className="grid max-w-2xl gap-4 rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
                <label className="text-sm font-medium text-slate-700">
                    Title
                    <input
                        className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                        value={form.title}
                        onChange={(e) => setForm({ ...form, title: e.target.value })}
                        required
                    />
                </label>
                <label className="text-sm font-medium text-slate-700">
                    Top text
                    <input
                        className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                        value={form.top_text}
                        onChange={(e) => setForm({ ...form, top_text: e.target.value })}
                        required
                    />
                </label>
                <label className="text-sm font-medium text-slate-700">
                    Description (supports [student_name], [class_name], …)
                    <textarea
                        className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                        rows={4}
                        value={form.description}
                        onChange={(e) => setForm({ ...form, description: e.target.value })}
                        required
                    />
                </label>
                <label className="text-sm font-medium text-slate-700">
                    Background image
                    <input
                        type="file"
                        accept="image/*"
                        className="mt-1 w-full text-sm"
                        onChange={(e) => setFiles({ ...files, bg_image: e.target.files?.[0] || null })}
                    />
                </label>
                <label className="text-sm font-medium text-slate-700">
                    Bottom left text
                    <input
                        className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                        value={form.bottom_left_text}
                        onChange={(e) => setForm({ ...form, bottom_left_text: e.target.value })}
                        required
                    />
                </label>
                <label className="text-sm font-medium text-slate-700">
                    Bottom left signature
                    <input
                        type="file"
                        accept="image/*"
                        className="mt-1 w-full text-sm"
                        onChange={(e) => setFiles({ ...files, bottom_left_signature: e.target.files?.[0] || null })}
                    />
                </label>
                <label className="text-sm font-medium text-slate-700">
                    Bottom right text
                    <input
                        className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                        value={form.bottom_right_text}
                        onChange={(e) => setForm({ ...form, bottom_right_text: e.target.value })}
                        required
                    />
                </label>
                <label className="text-sm font-medium text-slate-700">
                    Bottom right signature
                    <input
                        type="file"
                        accept="image/*"
                        className="mt-1 w-full text-sm"
                        onChange={(e) => setFiles({ ...files, bottom_right_signature: e.target.files?.[0] || null })}
                    />
                </label>
                <label className="flex items-center gap-2 text-sm text-slate-700">
                    <input type="checkbox" checked={form.logo} onChange={(e) => setForm({ ...form, logo: e.target.checked })} />
                    Show school logo
                </label>
                <label className="flex items-center gap-2 text-sm text-slate-700">
                    <input type="checkbox" checked={form.name} onChange={(e) => setForm({ ...form, name: e.target.checked })} />
                    Show student name
                </label>
                <div className="flex gap-2">
                    <button
                        type="submit"
                        disabled={busy}
                        className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-50"
                    >
                        {busy ? 'Saving…' : 'Save'}
                    </button>
                    <Link to="/certificate" className="rounded-md border border-slate-300 px-4 py-2 text-sm text-slate-700">
                        Cancel
                    </Link>
                </div>
            </form>
        </Shell>
    );
}

export function CertificateGeneratePage({ Layout }) {
    const [meta, setMeta] = useState({});
    const [err, setErr] = useState('');
    const [busy, setBusy] = useState(false);
    const [classes, setClasses] = useState([]);
    const [certificates, setCertificates] = useState([]);
    const [sections, setSections] = useState([]);
    const [sessionStudents, setSessionStudents] = useState([]);
    const [form, setForm] = useState({ class: '', section: '', student: '', certificate: '' });
    const [result, setResult] = useState(null);

    useEffect(() => {
        axios
            .get('/certificate/generate', { headers: xhrJson })
            .then((r) => {
                setMeta(r.data?.meta || {});
                setClasses(r.data?.data?.classes || []);
                setCertificates(r.data?.data?.certificates || []);
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));
    }, []);

    useEffect(() => {
        if (!form.class) {
            setSections([]);
            return;
        }
        axios
            .get(`/class-setup/get-sections?id=${encodeURIComponent(form.class)}`, { headers: xhrJson })
            .then((r) => setSections(r.data || []))
            .catch(() => setSections([]));
    }, [form.class]);

    useEffect(() => {
        if (!form.class || !form.section) {
            setSessionStudents([]);
            return;
        }
        axios
            .get(`/certificate/session-students?class=${encodeURIComponent(form.class)}&section=${encodeURIComponent(form.section)}`, {
                headers: xhrJson,
            })
            .then((r) => setSessionStudents(r.data?.data || []))
            .catch(() => setSessionStudents([]));
    }, [form.class, form.section]);

    const search = async (e) => {
        e.preventDefault();
        setErr('');
        setBusy(true);
        setResult(null);
        try {
            const fd = new FormData();
            fd.append('class', form.class);
            fd.append('section', form.section);
            fd.append('certificate', form.certificate);
            if (form.student) fd.append('student', form.student);
            const { data } = await axios.post('/certificate/generate', fd, {
                headers: { ...xhrJson, 'Content-Type': 'multipart/form-data' },
            });
            setResult(data?.data || null);
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Search failed.');
        } finally {
            setBusy(false);
        }
    };

    const cert = result?.certificate;
    const students = result?.students || [];
    const sessionName = result?.session || '';
    const settings = result?.settings || {};

    const previewBlocks = useMemo(() => {
        if (!cert || !students.length) return [];
        return students.map((row) => {
            const { first, rest } = splitTitle(cert.title);
            const html = buildDescriptionHtml(cert, row, sessionName, settings);
            return { row, first, rest, html };
        });
    }, [cert, students, sessionName, settings]);

    return (
        <Shell Layout={Layout}>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900">{meta.title || 'Generate certificate'}</h1>
                    <p className="text-sm text-slate-500">Filter class, section, and certificate.</p>
                </div>
                <Link to="/certificate" className="text-sm font-medium text-blue-600 hover:text-blue-800">
                    Back to list
                </Link>
            </div>
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <form onSubmit={search} className="grid gap-4 rounded-xl border border-slate-200 bg-white p-6 shadow-sm md:grid-cols-2">
                <label className="text-sm font-medium text-slate-700">
                    Class
                    <select
                        className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                        value={form.class}
                        onChange={(e) => setForm({ ...form, class: e.target.value, section: '', student: '' })}
                        required
                    >
                        <option value="">Select class</option>
                        {classes.map((cs) => (
                            <option key={cs.id} value={cs.class?.id}>
                                {cs.class?.name}
                            </option>
                        ))}
                    </select>
                </label>
                <label className="text-sm font-medium text-slate-700">
                    Section
                    <select
                        className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                        value={form.section}
                        onChange={(e) => setForm({ ...form, section: e.target.value, student: '' })}
                        required
                    >
                        <option value="">Select section</option>
                        {sections.map((s) => (
                            <option key={s.id} value={s.id}>
                                {s.name}
                            </option>
                        ))}
                    </select>
                </label>
                <label className="text-sm font-medium text-slate-700">
                    Student (optional)
                    <select
                        className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                        value={form.student}
                        onChange={(e) => setForm({ ...form, student: e.target.value })}
                    >
                        <option value="">All students in section</option>
                        {sessionStudents.map((s) => (
                            <option key={s.id} value={s.student_id}>
                                {s.student?.first_name} {s.student?.last_name}
                            </option>
                        ))}
                    </select>
                </label>
                <label className="text-sm font-medium text-slate-700">
                    Certificate template
                    <select
                        className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                        value={form.certificate}
                        onChange={(e) => setForm({ ...form, certificate: e.target.value })}
                        required
                    >
                        <option value="">Select</option>
                        {certificates.map((c) => (
                            <option key={c.id} value={c.id}>
                                {c.title}
                            </option>
                        ))}
                    </select>
                </label>
                <div className="md:col-span-2">
                    <button
                        type="submit"
                        disabled={busy}
                        className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-50"
                    >
                        {busy ? 'Loading…' : 'Search'}
                    </button>
                </div>
            </form>

            {previewBlocks.length ? (
                <div className="space-y-6">
                    <div className="flex justify-end">
                        <button
                            type="button"
                            className="rounded-md bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800"
                            onClick={() => window.print()}
                        >
                            Print
                        </button>
                    </div>
                    {previewBlocks.map(({ row, first, rest, html }) => (
                        <div
                            key={row.id}
                            className="certificate-print relative mx-auto flex min-h-[420px] w-full max-w-[900px] justify-center rounded-xl bg-slate-100 p-6"
                        >
                            <div className="relative w-full max-w-[565px] overflow-hidden rounded-lg bg-white shadow-lg">
                                <img src={cert.bg_image_url} alt="" className="absolute inset-0 h-full w-full object-cover" />
                                {cert.logo && cert.school_logo_url ? (
                                    <img src={cert.school_logo_url} alt="" className="absolute right-8 top-8 h-14 w-auto" />
                                ) : null}
                                <div className="relative z-10 px-8 pb-24 pt-12 text-center">
                                    <h3 className="text-3xl font-medium text-[#392C7D]">{first}</h3>
                                    {rest ? <p className="text-[11px] text-[#392C7D]">{rest}</p> : null}
                                    <p className="mt-1 text-[8px] text-[#392C7D]">{cert.top_text}</p>
                                    {cert.name ? (
                                        <h2 className="mt-4 text-3xl font-medium text-[#15344D]">
                                            {row.student?.first_name} {row.student?.last_name}
                                        </h2>
                                    ) : null}
                                    <div
                                        className="certificate_description mt-3 text-[10px] leading-relaxed text-slate-500"
                                        dangerouslySetInnerHTML={{ __html: html }}
                                    />
                                </div>
                                <div className="absolute bottom-10 left-0 right-0 z-10 flex justify-center gap-16">
                                    <div className="text-center">
                                        {cert.bottom_left_signature_url ? (
                                            <img src={cert.bottom_left_signature_url} alt="" className="mx-auto h-8 object-contain" />
                                        ) : null}
                                        <div className="mx-auto mt-1 w-24 border-b border-[#392C7D]" />
                                        <span className="mt-1 block text-[6px] uppercase text-[#15344D]">{cert.bottom_left_text}</span>
                                    </div>
                                    <div className="text-center">
                                        {cert.bottom_right_signature_url ? (
                                            <img src={cert.bottom_right_signature_url} alt="" className="mx-auto h-8 object-contain" />
                                        ) : null}
                                        <div className="mx-auto mt-1 w-24 border-b border-[#392C7D]" />
                                        <span className="mt-1 block text-[6px] uppercase text-[#15344D]">{cert.bottom_right_text}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            ) : null}
        </Shell>
    );
}
