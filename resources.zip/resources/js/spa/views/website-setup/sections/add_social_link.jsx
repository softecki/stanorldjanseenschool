import React from 'react';

/**
 * Tailwind placeholder (from Blade): resources/views/website-setup/sections/add_social_link.blade.php
 */
export default function AddSocialLink(props) {
  return (
    <div className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm">
      <h1 className="text-lg font-semibold text-slate-900">add_social_link</h1>
      <p className="mt-2 text-sm text-slate-500">React + Tailwind scaffold. Wire props and API as needed.</p>
    </div>
  );
}
