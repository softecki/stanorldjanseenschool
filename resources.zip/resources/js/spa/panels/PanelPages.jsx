import React, { useEffect, useMemo, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const xhrJson = { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' };

function Shell({ Layout, title, subtitle, children }) {
    return (
        <Layout>
            <div className="mx-auto max-w-6xl space-y-6 p-6">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900">{title}</h1>
                    {subtitle ? <p className="text-sm text-slate-600">{subtitle}</p> : null}
                </div>
                {children}
            </div>
        </Layout>
    );
}

function pickArray(data, preferredKey) {
    if (!data) return [];
    if (preferredKey && Array.isArray(data[preferredKey])) return data[preferredKey];
    const paginator = Object.values(data).find((v) => v && Array.isArray(v?.data));
    if (paginator?.data) return paginator.data;
    const firstArray = Object.values(data).find((v) => Array.isArray(v));
    return firstArray || [];
}

export function PanelListPage({ Layout, title, endpoint, preferredKey, detailBase }) {
    const [payload, setPayload] = useState(null);
    const [err, setErr] = useState('');

    useEffect(() => {
        axios
            .get(endpoint, { headers: xhrJson })
            .then((r) => setPayload(r.data?.data || {}))
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load data.'));
    }, [endpoint]);

    const rows = useMemo(() => pickArray(payload, preferredKey), [payload, preferredKey]);

    return (
        <Shell Layout={Layout} title={title}>
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <div className="rounded border bg-white">
                <div className="grid grid-cols-12 border-b bg-slate-50 px-4 py-2 text-xs font-semibold uppercase text-slate-600">
                    <div className="col-span-1">#</div>
                    <div className="col-span-8">Title</div>
                    <div className="col-span-3 text-right">Action</div>
                </div>
                {rows.map((row, i) => {
                    const label = row?.title || row?.name || row?.subject || row?.book_name || row?.exam_name || `Item ${i + 1}`;
                    return (
                        <div key={row?.id || i} className="grid grid-cols-12 items-center border-b px-4 py-3 text-sm">
                            <div className="col-span-1 text-slate-500">{i + 1}</div>
                            <div className="col-span-8 text-slate-800">{label}</div>
                            <div className="col-span-3 text-right">
                                {detailBase && row?.id ? (
                                    <Link className="text-blue-700 hover:text-blue-900" to={`${detailBase}/${row.id}`}>
                                        View
                                    </Link>
                                ) : (
                                    <span className="text-slate-400">-</span>
                                )}
                            </div>
                        </div>
                    );
                })}
                {!rows.length ? <p className="p-6 text-center text-sm text-slate-500">No records found.</p> : null}
            </div>
        </Shell>
    );
}

export function OnlineExamDetailPage({ Layout, endpoint }) {
    const [payload, setPayload] = useState(null);
    const [err, setErr] = useState('');

    useEffect(() => {
        axios
            .get(endpoint, { headers: xhrJson })
            .then((r) => setPayload(r.data?.data || {}))
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load exam.'));
    }, [endpoint]);

    const entries = Object.entries(payload || {});

    return (
        <Shell Layout={Layout} title="Online Exam Detail">
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <div className="rounded border bg-white p-4">
                {entries.length ? (
                    <div className="grid gap-2 text-sm">
                        {entries.map(([k, v]) => (
                            <div key={k} className="grid grid-cols-12 border-b py-2">
                                <div className="col-span-4 font-medium text-slate-700">{k}</div>
                                <div className="col-span-8 text-slate-800">{typeof v === 'object' ? JSON.stringify(v) : String(v)}</div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <p className="text-sm text-slate-500">No detail available.</p>
                )}
            </div>
        </Shell>
    );
}
