import React, { useEffect, useState } from 'react';
import axios from 'axios';

const xhrJson = { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' };

function Shell({ Layout, title, children }) {
    return (
        <Layout>
            <div className="mx-auto max-w-4xl space-y-6 p-6">
                <h1 className="text-2xl font-bold text-slate-900">{title}</h1>
                {children}
            </div>
        </Layout>
    );
}

export function PanelProfileViewPage({ Layout, title, endpoint }) {
    const [data, setData] = useState(null);
    const [err, setErr] = useState('');

    useEffect(() => {
        axios.get(endpoint, { headers: xhrJson })
            .then((r) => setData(r.data?.data || {}))
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load profile.'));
    }, [endpoint]);

    return (
        <Shell Layout={Layout} title={title}>
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <div className="rounded border bg-white p-4 text-sm">
                <div className="grid grid-cols-12 border-b py-2">
                    <span className="col-span-4 font-medium text-slate-700">Title</span>
                    <span className="col-span-8 text-slate-800">{data?.title || '-'}</span>
                </div>
            </div>
        </Shell>
    );
}

export function PanelProfileEditPage({ Layout, title, loadEndpoint, saveEndpoint }) {
    const [form, setForm] = useState({ first_name: '', last_name: '', phone: '', email: '' });
    const [msg, setMsg] = useState('');
    const [err, setErr] = useState('');

    useEffect(() => {
        axios.get(loadEndpoint, { headers: xhrJson })
            .then((r) => {
                const user = r.data?.data?.user || {};
                setForm({
                    first_name: user.first_name || '',
                    last_name: user.last_name || '',
                    phone: user.phone || '',
                    email: user.email || '',
                });
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load form.'));
    }, [loadEndpoint]);

    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        setMsg('');
        try {
            const { data } = await axios.put(saveEndpoint, form, { headers: xhrJson });
            setMsg(data?.message || 'Saved successfully.');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Save failed.');
        }
    };

    return (
        <Shell Layout={Layout} title={title}>
            {msg ? <p className="text-sm text-emerald-700">{msg}</p> : null}
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <form onSubmit={submit} className="grid gap-3 rounded border bg-white p-4">
                <input className="rounded border px-3 py-2" placeholder="First name" value={form.first_name} onChange={(e) => setForm({ ...form, first_name: e.target.value })} />
                <input className="rounded border px-3 py-2" placeholder="Last name" value={form.last_name} onChange={(e) => setForm({ ...form, last_name: e.target.value })} />
                <input className="rounded border px-3 py-2" placeholder="Phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
                <input className="rounded border px-3 py-2" placeholder="Email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
                <button className="w-fit rounded bg-blue-600 px-4 py-2 text-sm text-white">Save</button>
            </form>
        </Shell>
    );
}

export function PanelPasswordPage({ Layout, title, saveEndpoint }) {
    const [form, setForm] = useState({ current_password: '', password: '', password_confirmation: '' });
    const [msg, setMsg] = useState('');
    const [err, setErr] = useState('');

    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        setMsg('');
        try {
            const { data } = await axios.put(saveEndpoint, form, { headers: xhrJson });
            setMsg(data?.message || 'Password updated.');
            setForm({ current_password: '', password: '', password_confirmation: '' });
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Password update failed.');
        }
    };

    return (
        <Shell Layout={Layout} title={title}>
            {msg ? <p className="text-sm text-emerald-700">{msg}</p> : null}
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <form onSubmit={submit} className="grid gap-3 rounded border bg-white p-4">
                <input type="password" className="rounded border px-3 py-2" placeholder="Current password" value={form.current_password} onChange={(e) => setForm({ ...form, current_password: e.target.value })} />
                <input type="password" className="rounded border px-3 py-2" placeholder="New password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
                <input type="password" className="rounded border px-3 py-2" placeholder="Confirm password" value={form.password_confirmation} onChange={(e) => setForm({ ...form, password_confirmation: e.target.value })} />
                <button className="w-fit rounded bg-blue-600 px-4 py-2 text-sm text-white">Update password</button>
            </form>
        </Shell>
    );
}
