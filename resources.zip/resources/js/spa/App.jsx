import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link, Navigate, Route, Routes, useLocation, useNavigate, useParams } from 'react-router-dom';
import { AcademicFormPage, AcademicHomePage, AcademicListPage } from './academic/AcademicPages';
import { BackendDashboardPage, BackendDashboardPdfPage, BackendDashboardTablePage, BackendMasterPage, BackendMenuAutocompletePage } from './backend/BackendPages';
import { AttendanceIndexPage, AttendanceNotificationPage, AttendanceReportPage } from './attendance/AttendancePages';
import { DepositFormPage, DepositsPage, InvoiceFormPage, InvoicesPage, PaymentFormPage, PaymentsPage, SupplierFormPage, SuppliersPage, TransactionFormPage, TransactionsPage } from './accounts/AccountExtraPages';
import { BackendForgotPasswordPage, BackendLoginPage, BackendRegisterPage, BackendResetPasswordPage } from './auth/BackendAuthPages';
import { BankAccountsFormPage, BankAccountsListPage } from './banks/BankAccountsPages';
import { BloodGroupsFormPage, BloodGroupsListPage } from './settings/BloodGroupPages';
import {
    CertificateFormPage,
    CertificateGeneratePage,
    CertificateListPage,
} from './certificate/CertificatePages';
import {
    CertificateUiCreatePage,
    CertificateUiGeneratePage,
    CertificateUiHomePage,
    CertificateUiListPage,
} from './certificate/CertificateUiPages';
import {
    NoticeBoardFormPage,
    NoticeBoardListPage,
    NoticeBoardTranslatePage,
    SmsCampaignPage,
    SmsMailCreatePage,
    SmsMailListPage,
    SmsTemplateFormPage,
    SmsTemplateListPage,
} from './communication/CommunicationPages';
import {
    ExamAssignCreatePage,
    ExamAssignEditPage,
    ExamAssignListPage,
    ExaminationHomePage,
    ExaminationSettingsPage,
    MarksGradesFormPage,
    MarksGradesListPage,
    MarksRegisterCreatePage,
    MarksRegisterEditPage,
    MarksRegisterListPage,
    MarksRegisterViewPage,
} from './examination/ExaminationPages';
import {
    FeesAssignmentFormPage,
    FeesAssignmentsPage,
    FeesCollectionEditPage,
    FeesCollectionsPage,
    FeesGroupFormPage,
    FeesGroupsPage,
    FeesMasterFormPage,
    FeesMastersPage,
    FeesTypeFormPage,
    FeesTypesPage,
} from './fees/FeesPages';
import { DashboardPage } from './dashboard/DashboardPage';
import { GendersFormPage, GendersListPage, GendersTranslatePage } from './settings/GenderPages';
import { GmeetFormPage, GmeetListPage } from './gmeet/GmeetPages';
import { GoodsHomePage } from './goods/GoodsPages';
import { HomeworkFormPage, HomeworkListPage } from './homework/HomeworkPages';
import { IdCardFormPage, IdCardGeneratePage, IdCardListPage } from './idcard/IdCardPages';
import { LibraryHomePage } from './library/LibraryPages';
import { LanguagesListPage, LanguageFormPage, LanguageTermsPage } from './languages/LanguagePages';
import { BackendViewHubPage, CommonViewHubPage, ErrorsHubPage, FrontendHubPage, GenericMigratedPage, PanelHubPage } from './legacy/LegacyViewMigrations';
import { EndpointDataPage } from './legacy/ConnectedLegacyPages';
import { PanelListPage } from './panels/PanelPages';
import { OnlineExamResultPage, OnlineExamViewPage } from './panels/PanelOnlineExamPages';
import { PanelPasswordPage, PanelProfileEditPage, PanelProfileViewPage } from './panels/PanelProfilePages';
import { MailEmailVerificationPage, MailForgotPasswordPage, MailResetPasswordPage } from './mail/MailPages';
import { OrdersCreatePage, OrdersListPage } from './orders/OrderPages';
import { ReligionsFormPage, ReligionsListPage, ReligionsTranslatePage } from './settings/ReligionPages';
import { SessionsFormPage, SessionsListPage, SessionsTranslatePage } from './settings/SessionPages';
import { AdminLayout } from './layout/AdminLayout';
import { StudentsPage } from './students/StudentsPage';
import {
    DisabledStudentsPage,
    ParentFormPage,
    ParentsPage,
    PromoteStudentsPage,
    StudentCategoriesPage,
    StudentCreatePage,
    StudentEditPage,
    StudentShowPage,
} from './students/StudentModulePages';

const xhrJson = { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' };

function AuthCard({ title, children }) {
    return (
        <div className="flex min-h-screen items-center justify-center bg-slate-100 p-4">
            <div className="w-full max-w-md rounded-lg border bg-white p-5 shadow-sm">
                <h1 className="mb-4 text-xl font-bold">{title}</h1>
                {children}
            </div>
        </div>
    );
}

function LoginPage() {
    const nav = useNavigate();
    const location = useLocation();
    const [form, setForm] = useState({ email: '', password: '' });
    const [err, setErr] = useState('');
    const [busy, setBusy] = useState(false);
    const query = new URLSearchParams(location.search);
    const notice = query.get('notice');
    const noticeType = query.get('noticeType');

    const submit = async (e) => {
        e.preventDefault();
        setBusy(true);
        setErr('');
        try {
            const { data } = await axios.post('/login', form, { headers: xhrJson });
            const redirect = data?.redirect || '/dashboard';
            if (redirect.startsWith('/')) {
                nav(redirect.replace(/^\/+/, '') === 'dashboard' ? '/dashboard' : redirect);
            } else {
                nav('/dashboard');
            }
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Login failed.');
        } finally {
            setBusy(false);
        }
    };

    return (
        <AuthCard title="Login">
            {notice ? <p className={`mb-2 text-sm ${noticeType === 'error' ? 'text-red-600' : 'text-emerald-700'}`}>{notice}</p> : null}
            {err ? <p className="mb-2 text-sm text-red-600">{err}</p> : null}
            <form className="space-y-3" onSubmit={submit}>
                <input className="w-full rounded border px-3 py-2" placeholder="Email or phone" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required />
                <input type="password" className="w-full rounded border px-3 py-2" placeholder="Password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} required />
                <button disabled={busy} className="w-full rounded bg-blue-600 px-3 py-2 text-white">{busy ? 'Signing in...' : 'Sign in'}</button>
            </form>
            <div className="mt-3 flex justify-between text-sm">
                <Link to="/register">Register</Link>
                <Link to="/forgot-password">Forgot password</Link>
            </div>
        </AuthCard>
    );
}

function RegisterPage() {
    const nav = useNavigate();
    const [form, setForm] = useState({ name: '', email: '', password: '', password_confirmation: '' });
    const [msg, setMsg] = useState('');
    const [err, setErr] = useState('');
    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        try {
            const { data } = await axios.post('/register', form, { headers: xhrJson });
            setMsg(data?.message || 'Registered successfully.');
            setTimeout(() => nav('/login'), 1200);
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Registration failed.');
        }
    };
    return (
        <AuthCard title="Register">
            {msg ? <p className="mb-2 text-sm text-emerald-700">{msg}</p> : null}
            {err ? <p className="mb-2 text-sm text-red-600">{err}</p> : null}
            <form className="space-y-3" onSubmit={submit}>
                <input className="w-full rounded border px-3 py-2" placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
                <input className="w-full rounded border px-3 py-2" placeholder="Email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required />
                <input type="password" className="w-full rounded border px-3 py-2" placeholder="Password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} required />
                <input type="password" className="w-full rounded border px-3 py-2" placeholder="Confirm password" value={form.password_confirmation} onChange={(e) => setForm({ ...form, password_confirmation: e.target.value })} required />
                <button className="w-full rounded bg-blue-600 px-3 py-2 text-white">Create account</button>
            </form>
        </AuthCard>
    );
}

function ForgotPasswordPage() {
    const [email, setEmail] = useState('');
    const [msg, setMsg] = useState('');
    const [err, setErr] = useState('');
    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        try {
            const { data } = await axios.post('/forgot-password', { email }, { headers: xhrJson });
            setMsg(data?.message || 'Reset link sent.');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Request failed.');
        }
    };
    return (
        <AuthCard title="Forgot password">
            {msg ? <p className="mb-2 text-sm text-emerald-700">{msg}</p> : null}
            {err ? <p className="mb-2 text-sm text-red-600">{err}</p> : null}
            <form className="space-y-3" onSubmit={submit}>
                <input className="w-full rounded border px-3 py-2" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
                <button className="w-full rounded bg-blue-600 px-3 py-2 text-white">Send reset link</button>
            </form>
        </AuthCard>
    );
}

function ResetPasswordPage() {
    const { email = '', token = '' } = useParams();
    const nav = useNavigate();
    const [form, setForm] = useState({ email, token, password: '', password_confirmation: '' });
    const [msg, setMsg] = useState('');
    const [err, setErr] = useState('');
    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        try {
            const { data } = await axios.post('/reset-password', form, { headers: xhrJson });
            setMsg(data?.message || 'Password reset successful.');
            setTimeout(() => nav('/login'), 1200);
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Reset failed.');
        }
    };
    return (
        <AuthCard title="Reset password">
            {msg ? <p className="mb-2 text-sm text-emerald-700">{msg}</p> : null}
            {err ? <p className="mb-2 text-sm text-red-600">{err}</p> : null}
            <form className="space-y-3" onSubmit={submit}>
                <input className="w-full rounded border px-3 py-2" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required />
                <input type="hidden" value={form.token} onChange={() => {}} />
                <input type="password" className="w-full rounded border px-3 py-2" placeholder="New password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} required />
                <input type="password" className="w-full rounded border px-3 py-2" placeholder="Confirm password" value={form.password_confirmation} onChange={(e) => setForm({ ...form, password_confirmation: e.target.value })} required />
                <button className="w-full rounded bg-blue-600 px-3 py-2 text-white">Reset password</button>
            </form>
        </AuthCard>
    );
}

function StudentPanelLayout({ children }) {
    return (
        <div className="min-h-screen bg-slate-50">
            <header className="border-b bg-white">
                <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-3">
                    <strong>Student</strong>
                    <button type="button" className="text-sm text-blue-700" onClick={() => axios.post('/logout').then(() => { window.location.href = '/login'; })}>Logout</button>
                </div>
            </header>
            {children}
        </div>
    );
}

function StudentPanelDashboardPage() {
    const [data, setData] = useState(null);
    const [err, setErr] = useState('');
    useEffect(() => {
        axios.get('/student-panel-dashboard', { headers: xhrJson })
            .then((res) => setData(res.data?.data ?? null))
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load dashboard.'));
    }, []);
    return (
        <StudentPanelLayout>
            <div className="mx-auto max-w-7xl p-6">
                <h1 className="text-2xl font-bold">Student dashboard</h1>
                {err ? <p className="mt-2 text-sm text-red-600">{err}</p> : null}
                <pre className="mt-4 overflow-auto rounded bg-white p-4 text-xs">{JSON.stringify(data, null, 2)}</pre>
            </div>
        </StudentPanelLayout>
    );
}

function ParentPanelLayout({ children }) {
    return (
        <div className="min-h-screen bg-slate-50">
            <header className="border-b bg-white">
                <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-3">
                    <strong>Parent</strong>
                    <button type="button" className="text-sm text-blue-700" onClick={() => axios.post('/logout').then(() => { window.location.href = '/login'; })}>Logout</button>
                </div>
            </header>
            {children}
        </div>
    );
}

function ParentPanelDashboardPage() {
    const [data, setData] = useState(null);
    const [err, setErr] = useState('');
    useEffect(() => {
        axios.get('/parent-panel-dashboard', { headers: xhrJson })
            .then((res) => setData(res.data?.data ?? null))
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load dashboard.'));
    }, []);
    return (
        <ParentPanelLayout>
            <div className="mx-auto max-w-7xl p-6">
                <h1 className="text-2xl font-bold">Parent dashboard</h1>
                {err ? <p className="mt-2 text-sm text-red-600">{err}</p> : null}
                <pre className="mt-4 overflow-auto rounded bg-white p-4 text-xs">{JSON.stringify(data, null, 2)}</pre>
            </div>
        </ParentPanelLayout>
    );
}

function UsersPage() {
    const [rows, setRows] = useState([]);
    const [err, setErr] = useState('');
    const load = () => axios.get('/users', { headers: xhrJson }).then((r) => setRows(r.data?.data || [])).catch((ex) => setErr(ex.response?.data?.message || 'Failed to load users.'));
    useEffect(() => { load(); }, []);
    return (
        <AdminLayout>
            <div className="mx-auto max-w-7xl p-6">
                <div className="mb-4 flex items-center justify-between">
                    <h1 className="text-2xl font-bold">Users</h1>
                    <Link to="/users/create" className="rounded bg-blue-600 px-3 py-2 text-sm text-white">Create</Link>
                </div>
                {err ? <p className="text-sm text-red-600">{err}</p> : null}
                <div className="overflow-auto rounded border bg-white">
                    <table className="min-w-full text-sm">
                        <thead><tr className="border-b"><th className="p-2 text-left">Name</th><th className="p-2 text-left">Email</th><th className="p-2 text-left">Role</th><th className="p-2" /></tr></thead>
                        <tbody>
                        {rows.map((u) => (
                            <tr className="border-b" key={u.id}>
                                <td className="p-2">{u.name || `${u.first_name || ''} ${u.last_name || ''}`}</td>
                                <td className="p-2">{u.email}</td>
                                <td className="p-2">{u.role?.name || '-'}</td>
                                <td className="p-2 text-right"><Link to={`/users/${u.id}/edit`} className="text-blue-700">Edit</Link></td>
                            </tr>
                        ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </AdminLayout>
    );
}

function UserFormPage({ edit = false }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [meta, setMeta] = useState({});
    const [form, setForm] = useState({});
    const [err, setErr] = useState('');

    useEffect(() => {
        const url = edit ? `/users/edit/${id}` : '/users/create';
        axios.get(url, { headers: xhrJson })
            .then((res) => {
                if (edit) {
                    setMeta(res.data?.meta || {});
                    setForm(res.data?.data || {});
                } else {
                    setMeta(res.data?.meta || {});
                    setForm({});
                }
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load form.'));
    }, [edit, id]);

    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        try {
            if (edit) await axios.put(`/users/update/${id}`, form, { headers: xhrJson });
            else await axios.post('/users/store', form, { headers: xhrJson });
            nav('/users');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Save failed.');
        }
    };

    return (
        <AdminLayout>
            <div className="mx-auto max-w-3xl p-6">
                <h1 className="text-2xl font-bold">{edit ? 'Edit user' : 'Create user'}</h1>
                {err ? <p className="mt-2 text-sm text-red-600">{err}</p> : null}
                <form className="mt-4 grid grid-cols-1 gap-3 rounded border bg-white p-4" onSubmit={submit}>
                    <input className="rounded border px-3 py-2" placeholder="First name" value={form.first_name || ''} onChange={(e) => setForm({ ...form, first_name: e.target.value })} />
                    <input className="rounded border px-3 py-2" placeholder="Last name" value={form.last_name || ''} onChange={(e) => setForm({ ...form, last_name: e.target.value })} />
                    <input className="rounded border px-3 py-2" placeholder="Email" value={form.email || ''} onChange={(e) => setForm({ ...form, email: e.target.value })} />
                    {!edit ? <input type="password" className="rounded border px-3 py-2" placeholder="Password" value={form.password || ''} onChange={(e) => setForm({ ...form, password: e.target.value })} /> : null}
                    <input className="rounded border px-3 py-2" placeholder="Phone" value={form.phone || form.phone_number || ''} onChange={(e) => setForm({ ...form, phone: e.target.value, phone_number: e.target.value })} />
                    <select className="rounded border px-3 py-2" value={form.role_id || ''} onChange={(e) => setForm({ ...form, role_id: e.target.value })}>
                        <option value="">Select role</option>
                        {(meta.roles || []).map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
                    </select>
                    <button className="rounded bg-blue-600 px-3 py-2 text-white">{edit ? 'Update' : 'Create'}</button>
                </form>
            </div>
        </AdminLayout>
    );
}

function RolesPage() {
    const [rows, setRows] = useState([]);
    const [err, setErr] = useState('');
    const [showCreate, setShowCreate] = useState(false);
    const [meta, setMeta] = useState({});
    const [form, setForm] = useState({ name: '', permissions: [] });

    const load = () => axios.get('/roles', { headers: xhrJson })
        .then((r) => setRows(r.data?.data || []))
        .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load roles.'));

    useEffect(() => { load(); }, []);

    const openCreate = async () => {
        setShowCreate(true);
        const { data } = await axios.get('/roles/create', { headers: xhrJson });
        setMeta(data?.meta || {});
    };

    const togglePerm = (id) => {
        setForm((f) => {
            const set = new Set(f.permissions || []);
            if (set.has(id)) set.delete(id); else set.add(id);
            return { ...f, permissions: Array.from(set) };
        });
    };

    const createRole = async (e) => {
        e.preventDefault();
        await axios.post('/roles/store', form, { headers: xhrJson });
        setShowCreate(false);
        setForm({ name: '', permissions: [] });
        load();
    };

    return (
        <AdminLayout>
            <div className="mx-auto max-w-7xl p-6">
                <div className="mb-4 flex items-center justify-between">
                    <h1 className="text-2xl font-bold">Roles</h1>
                    <button className="rounded bg-blue-600 px-3 py-2 text-sm text-white" onClick={openCreate}>Create role</button>
                </div>
                {err ? <p className="text-sm text-red-600">{err}</p> : null}
                <div className="overflow-auto rounded border bg-white">
                    <table className="min-w-full text-sm">
                        <thead><tr className="border-b"><th className="p-2 text-left">Name</th><th className="p-2 text-right">Actions</th></tr></thead>
                        <tbody>{rows.map((r) => (
                            <tr className="border-b" key={r.id}>
                                <td className="p-2">{r.name}</td>
                                <td className="p-2 text-right">
                                    <button className="text-red-700" onClick={async () => { if (window.confirm('Delete role?')) { await axios.delete(`/roles/delete/${r.id}`, { headers: xhrJson }); load(); } }}>Delete</button>
                                </td>
                            </tr>
                        ))}</tbody>
                    </table>
                </div>

                {showCreate ? (
                    <form onSubmit={createRole} className="mt-4 rounded border bg-white p-4">
                        <h2 className="mb-2 font-semibold">Create role</h2>
                        <input className="mb-3 w-full rounded border px-3 py-2" placeholder="Role name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                        <div className="mb-3 flex flex-wrap gap-3">
                            {(meta.permissions || []).map((p) => (
                                <label key={p.id} className="text-sm">
                                    <input type="checkbox" className="mr-1" checked={(form.permissions || []).includes(p.id)} onChange={() => togglePerm(p.id)} />
                                    {p.name}
                                </label>
                            ))}
                        </div>
                        <button className="rounded bg-blue-600 px-3 py-2 text-sm text-white">Save</button>
                    </form>
                ) : null}
            </div>
        </AdminLayout>
    );
}

function ProfilePage() {
    const [data, setData] = useState(null);
    useEffect(() => {
        axios.get('/my/profile', { headers: xhrJson }).then((r) => setData(r.data?.data || null));
    }, []);
    return (
        <AdminLayout>
            <div className="mx-auto max-w-4xl p-6">
                <h1 className="text-2xl font-bold">My Profile</h1>
                <pre className="mt-4 overflow-auto rounded bg-white p-4 text-xs">{JSON.stringify(data, null, 2)}</pre>
                <div className="mt-3 flex gap-3">
                    <Link to="/my/profile/edit" className="text-blue-700">Edit profile</Link>
                    <Link to="/my/password/update" className="text-blue-700">Update password</Link>
                </div>
            </div>
        </AdminLayout>
    );
}

function ProfileEditPage() {
    const nav = useNavigate();
    const [form, setForm] = useState({});
    const [err, setErr] = useState('');
    useEffect(() => { axios.get('/my/profile/edit', { headers: xhrJson }).then((r) => setForm(r.data?.data || {})); }, []);
    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        try {
            await axios.put('/my/profile/update', form, { headers: xhrJson });
            nav('/my/profile');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Update failed.');
        }
    };
    return (
        <AdminLayout>
            <div className="mx-auto max-w-3xl p-6">
                <h1 className="text-2xl font-bold">Edit Profile</h1>
                {err ? <p className="mt-2 text-sm text-red-600">{err}</p> : null}
                <form className="mt-4 grid gap-3 rounded border bg-white p-4" onSubmit={submit}>
                    <input className="rounded border px-3 py-2" placeholder="First name" value={form.first_name || ''} onChange={(e) => setForm({ ...form, first_name: e.target.value })} />
                    <input className="rounded border px-3 py-2" placeholder="Last name" value={form.last_name || ''} onChange={(e) => setForm({ ...form, last_name: e.target.value })} />
                    <input className="rounded border px-3 py-2" placeholder="Email" value={form.email || ''} onChange={(e) => setForm({ ...form, email: e.target.value })} />
                    <button className="rounded bg-blue-600 px-3 py-2 text-white">Save</button>
                </form>
            </div>
        </AdminLayout>
    );
}

function PasswordUpdatePage() {
    const nav = useNavigate();
    const [form, setForm] = useState({ current_password: '', password: '', password_confirmation: '' });
    const [err, setErr] = useState('');
    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        try {
            await axios.put('/my/password/update/store', form, { headers: xhrJson });
            nav('/my/profile');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Update failed.');
        }
    };
    return (
        <AdminLayout>
            <div className="mx-auto max-w-xl p-6">
                <h1 className="text-2xl font-bold">Update Password</h1>
                {err ? <p className="mt-2 text-sm text-red-600">{err}</p> : null}
                <form className="mt-4 grid gap-3 rounded border bg-white p-4" onSubmit={submit}>
                    <input type="password" className="rounded border px-3 py-2" placeholder="Current password" value={form.current_password} onChange={(e) => setForm({ ...form, current_password: e.target.value })} />
                    <input type="password" className="rounded border px-3 py-2" placeholder="New password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
                    <input type="password" className="rounded border px-3 py-2" placeholder="Confirm password" value={form.password_confirmation} onChange={(e) => setForm({ ...form, password_confirmation: e.target.value })} />
                    <button className="rounded bg-blue-600 px-3 py-2 text-white">Save</button>
                </form>
            </div>
        </AdminLayout>
    );
}

function SettingsGeneralPage() {
    const [meta, setMeta] = useState(null);
    useEffect(() => { axios.get('/general-settings', { headers: xhrJson }).then((r) => setMeta(r.data?.meta || null)); }, []);
    return (
        <AdminLayout>
            <div className="mx-auto max-w-7xl p-6">
                <h1 className="text-2xl font-bold">General Settings</h1>
                <pre className="mt-4 overflow-auto rounded bg-white p-4 text-xs">{JSON.stringify(meta, null, 2)}</pre>
            </div>
        </AdminLayout>
    );
}

function DeletedHistoryPage() {
    const [rows, setRows] = useState([]);
    useEffect(() => {
        axios.get('/student-deleted-history', { headers: xhrJson }).then((r) => {
            const d = r.data?.data || {};
            setRows(d.data || []);
        });
    }, []);
    return (
        <AdminLayout>
            <div className="mx-auto max-w-6xl p-6">
                <h1 className="text-2xl font-bold">Deleted Student History</h1>
                <div className="mt-3 rounded border bg-white p-3 text-sm">
                    {rows.map((r) => <div key={r.id} className="border-b py-2"><Link className="text-blue-700" to={`/students/deleted-history/${r.id}`}>{r.student_name || r.id}</Link></div>)}
                </div>
            </div>
        </AdminLayout>
    );
}

function DeletedHistoryShowPage() {
    const { id } = useParams();
    const [data, setData] = useState(null);
    useEffect(() => { axios.get(`/student-deleted-history/show/${id}`, { headers: xhrJson }).then((r) => setData(r.data?.data || null)); }, [id]);
    return (
        <AdminLayout>
            <div className="mx-auto max-w-6xl p-6">
                <h1 className="text-2xl font-bold">Deleted Student Record</h1>
                <pre className="mt-4 overflow-auto rounded bg-white p-4 text-xs">{JSON.stringify(data, null, 2)}</pre>
            </div>
        </AdminLayout>
    );
}

function ReportsHomePage() {
    return (
        <AdminLayout>
            <div className="mx-auto max-w-6xl p-6">
                <h1 className="text-2xl font-bold">Reports</h1>
                <div className="mt-4 grid grid-cols-1 gap-2 text-sm md:grid-cols-2">
                    <Link className="rounded border bg-white p-3" to="/reports/marksheet">Marksheet</Link>
                    <Link className="rounded border bg-white p-3" to="/reports/merit-list">Merit List</Link>
                    <Link className="rounded border bg-white p-3" to="/reports/progress-card">Progress Card</Link>
                    <Link className="rounded border bg-white p-3" to="/reports/due-fees">Due Fees</Link>
                    <Link className="rounded border bg-white p-3" to="/reports/class-routine">Class Routine</Link>
                    <Link className="rounded border bg-white p-3" to="/reports/exam-routine">Exam Routine</Link>
                    <Link className="rounded border bg-white p-3" to="/reports/duplicate-students">Duplicate Students</Link>
                    <Link className="rounded border bg-white p-3" to="/reports/account">Account Report</Link>
                    <Link className="rounded border bg-white p-3" to="/reports/accounting/income">Income Report</Link>
                    <Link className="rounded border bg-white p-3" to="/reports/accounting/expense">Expense Report</Link>
                    <Link className="rounded border bg-white p-3" to="/reports/accounting/profit-loss">Profit/Loss Report</Link>
                    <Link className="rounded border bg-white p-3" to="/reports/accounting/dashboard">Accounting Dashboard</Link>
                    <Link className="rounded border bg-white p-3" to="/reports/accounting/cashbook">Cashbook</Link>
                    <Link className="rounded border bg-white p-3" to="/reports/accounting/audit-log">Audit Log</Link>
                    <Link className="rounded border bg-white p-3" to="/reports/fees-collection">Fees Collection</Link>
                    <Link className="rounded border bg-white p-3" to="/reports/fees-summary">Fees Summary</Link>
                    <Link className="rounded border bg-white p-3" to="/reports/students">Students List</Link>
                    <Link className="rounded border bg-white p-3" to="/reports/fees-by-year">Fees By Year</Link>
                    <Link className="rounded border bg-white p-3" to="/reports/boarding-students">Boarding Students</Link>
                    <Link className="rounded border bg-white p-3" to="/reports/boarding-students/missing-2026">Missing Boarding 2026</Link>
                    <Link className="rounded border bg-white p-3" to="/reports/accounting/bank-reconciliation">Bank Reconciliation</Link>
                    <Link className="rounded border bg-white p-3" to="/reports/accounting/bank-reconciliation/process">Bank Reconciliation Process</Link>
                </div>
            </div>
        </AdminLayout>
    );
}

function ReportEntryPage({ title, endpoint }) {
    const [payload, setPayload] = useState(null);
    const [err, setErr] = useState('');
    useEffect(() => {
        axios.get(endpoint, { headers: xhrJson })
            .then((r) => setPayload(r.data || null))
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load report.'));
    }, [endpoint]);
    return (
        <AdminLayout>
            <div className="mx-auto max-w-6xl p-6">
                <h1 className="text-2xl font-bold">{title}</h1>
                {err ? <p className="mt-2 text-sm text-red-600">{err}</p> : null}
                <pre className="mt-4 overflow-auto rounded bg-white p-4 text-xs">{JSON.stringify(payload, null, 2)}</pre>
            </div>
        </AdminLayout>
    );
}

function AccountsHomePage() {
    return (
        <AdminLayout>
            <div className="mx-auto max-w-6xl p-6">
                <h1 className="text-2xl font-bold">Accounts</h1>
                <div className="mt-4 grid grid-cols-1 gap-2 text-sm md:grid-cols-2">
                    <Link className="rounded border bg-white p-3" to="/accounts/chart-of-accounts">Chart of Accounts</Link>
                    <Link className="rounded border bg-white p-3" to="/accounts/payment-methods">Payment Methods</Link>
                    <Link className="rounded border bg-white p-3" to="/accounts/account-heads">Account Heads</Link>
                    <Link className="rounded border bg-white p-3" to="/accounts/income">Income</Link>
                    <Link className="rounded border bg-white p-3" to="/accounts/expense">Expense</Link>
                    <Link className="rounded border bg-white p-3" to="/accounts/cash">Cash</Link>
                    <Link className="rounded border bg-white p-3" to="/accounts/product">Product</Link>
                    <Link className="rounded border bg-white p-3" to="/accounts/item">Item</Link>
                    <Link className="rounded border bg-white p-3" to="/accounts/balance">Balance</Link>
                </div>
            </div>
        </AdminLayout>
    );
}

function ChartOfAccountsPage() {
    const [rows, setRows] = useState([]);
    const [err, setErr] = useState('');
    useEffect(() => {
        axios.get('/chart-of-accounts', { headers: xhrJson })
            .then((r) => setRows(r.data?.data?.data || r.data?.data || []))
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load accounts.'));
    }, []);
    return (
        <AdminLayout>
            <div className="mx-auto max-w-6xl p-6">
                <div className="mb-4 flex items-center justify-between">
                    <h1 className="text-2xl font-bold">Chart of Accounts</h1>
                    <Link to="/accounts/chart-of-accounts/create" className="rounded bg-blue-600 px-3 py-2 text-sm text-white">Create</Link>
                </div>
                {err ? <p className="text-sm text-red-600">{err}</p> : null}
                <div className="rounded border bg-white p-3 text-sm">
                    {rows.map((a) => <div className="border-b py-2" key={a.id}><Link className="text-blue-700" to={`/accounts/chart-of-accounts/${a.id}/edit`}>{a.name || a.title || `Account #${a.id}`}</Link></div>)}
                </div>
            </div>
        </AdminLayout>
    );
}

function ChartOfAccountsFormPage({ edit = false }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [form, setForm] = useState({ name: '', type: 'income', code: '' });
    const [err, setErr] = useState('');
    useEffect(() => {
        const url = edit ? `/chart-of-accounts/edit/${id}` : '/chart-of-accounts/create';
        axios.get(url, { headers: xhrJson }).then((r) => {
            if (edit) setForm(r.data?.data || {});
        }).catch((ex) => setErr(ex.response?.data?.message || 'Failed to load form.'));
    }, [edit, id]);
    const submit = async (e) => {
        e.preventDefault();
        try {
            if (edit) await axios.put(`/chart-of-accounts/update/${id}`, form, { headers: xhrJson });
            else await axios.post('/chart-of-accounts/store', form, { headers: xhrJson });
            nav('/accounts/chart-of-accounts');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Save failed.');
        }
    };
    return (
        <AdminLayout>
            <div className="mx-auto max-w-3xl p-6">
                <h1 className="text-2xl font-bold">{edit ? 'Edit account' : 'Create account'}</h1>
                {err ? <p className="mt-2 text-sm text-red-600">{err}</p> : null}
                <form onSubmit={submit} className="mt-4 grid gap-3 rounded border bg-white p-4">
                    <input className="rounded border px-3 py-2" placeholder="Name" value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                    <select className="rounded border px-3 py-2" value={form.type || ''} onChange={(e) => setForm({ ...form, type: e.target.value })}>
                        <option value="income">Income</option><option value="expense">Expense</option><option value="asset">Asset</option><option value="liability">Liability</option>
                    </select>
                    <input className="rounded border px-3 py-2" placeholder="Code" value={form.code || ''} onChange={(e) => setForm({ ...form, code: e.target.value })} />
                    <button className="rounded bg-blue-600 px-3 py-2 text-white">{edit ? 'Update' : 'Create'}</button>
                </form>
            </div>
        </AdminLayout>
    );
}

function PaymentMethodsPage() {
    const [rows, setRows] = useState([]);
    useEffect(() => {
        axios.get('/payment-methods', { headers: xhrJson }).then((r) => setRows(r.data?.data?.data || r.data?.data || []));
    }, []);
    return (
        <AdminLayout>
            <div className="mx-auto max-w-6xl p-6">
                <div className="mb-4 flex items-center justify-between">
                    <h1 className="text-2xl font-bold">Payment Methods</h1>
                    <Link to="/accounts/payment-methods/create" className="rounded bg-blue-600 px-3 py-2 text-sm text-white">Create</Link>
                </div>
                <div className="rounded border bg-white p-3 text-sm">
                    {rows.map((m) => <div className="border-b py-2" key={m.id}><Link className="text-blue-700" to={`/accounts/payment-methods/${m.id}/edit`}>{m.name || `Method #${m.id}`}</Link></div>)}
                </div>
            </div>
        </AdminLayout>
    );
}

function PaymentMethodFormPage({ edit = false }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [form, setForm] = useState({ name: '' });
    const [err, setErr] = useState('');
    useEffect(() => {
        const url = edit ? `/payment-methods/edit/${id}` : '/payment-methods/create';
        axios.get(url, { headers: xhrJson }).then((r) => { if (edit) setForm(r.data?.data || {}); }).catch((ex) => setErr(ex.response?.data?.message || 'Failed to load form.'));
    }, [edit, id]);
    const submit = async (e) => {
        e.preventDefault();
        try {
            if (edit) await axios.put(`/payment-methods/update/${id}`, form, { headers: xhrJson });
            else await axios.post('/payment-methods/store', form, { headers: xhrJson });
            nav('/accounts/payment-methods');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Save failed.');
        }
    };
    return <AdminLayout><div className="mx-auto max-w-3xl p-6"><h1 className="text-2xl font-bold">{edit ? 'Edit payment method' : 'Create payment method'}</h1>{err ? <p className="mt-2 text-sm text-red-600">{err}</p> : null}<form onSubmit={submit} className="mt-4 grid gap-3 rounded border bg-white p-4"><input className="rounded border px-3 py-2" placeholder="Name" value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} /><button className="rounded bg-blue-600 px-3 py-2 text-white">{edit ? 'Update' : 'Create'}</button></form></div></AdminLayout>;
}

function AccountHeadsPage() {
    const [rows, setRows] = useState([]);
    useEffect(() => { axios.get('/account-head', { headers: xhrJson }).then((r) => setRows(r.data?.data?.data || r.data?.data || [])); }, []);
    return (
        <AdminLayout>
            <div className="mx-auto max-w-6xl p-6">
                <div className="mb-4 flex items-center justify-between">
                    <h1 className="text-2xl font-bold">Account Heads</h1>
                    <Link to="/accounts/account-heads/create" className="rounded bg-blue-600 px-3 py-2 text-sm text-white">Create</Link>
                </div>
                <div className="rounded border bg-white p-3 text-sm">
                    {rows.map((h) => <div className="border-b py-2" key={h.id}><Link className="text-blue-700" to={`/accounts/account-heads/${h.id}/edit`}>{h.name || h.title || `Head #${h.id}`}</Link></div>)}
                </div>
            </div>
        </AdminLayout>
    );
}

function AccountHeadFormPage({ edit = false }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [form, setForm] = useState({ name: '' });
    const [err, setErr] = useState('');
    useEffect(() => {
        const url = edit ? `/account-head/edit/${id}` : '/account-head/create';
        axios.get(url, { headers: xhrJson }).then((r) => { if (edit) setForm(r.data?.data || {}); }).catch((ex) => setErr(ex.response?.data?.message || 'Failed to load form.'));
    }, [edit, id]);
    const submit = async (e) => {
        e.preventDefault();
        try {
            if (edit) await axios.put(`/account-head/update/${id}`, form, { headers: xhrJson });
            else await axios.post('/account-head/store', form, { headers: xhrJson });
            nav('/accounts/account-heads');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Save failed.');
        }
    };
    return <AdminLayout><div className="mx-auto max-w-3xl p-6"><h1 className="text-2xl font-bold">{edit ? 'Edit account head' : 'Create account head'}</h1>{err ? <p className="mt-2 text-sm text-red-600">{err}</p> : null}<form onSubmit={submit} className="mt-4 grid gap-3 rounded border bg-white p-4"><input className="rounded border px-3 py-2" placeholder="Name" value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} /><button className="rounded bg-blue-600 px-3 py-2 text-white">{edit ? 'Update' : 'Create'}</button></form></div></AdminLayout>;
}

function IncomePage() {
    const [rows, setRows] = useState([]);
    useEffect(() => { axios.get('/income', { headers: xhrJson }).then((r) => setRows(r.data?.data?.data || r.data?.data || [])); }, []);
    return (
        <AdminLayout>
            <div className="mx-auto max-w-6xl p-6">
                <div className="mb-4 flex items-center justify-between">
                    <h1 className="text-2xl font-bold">Income</h1>
                    <Link to="/accounts/income/create" className="rounded bg-blue-600 px-3 py-2 text-sm text-white">Create</Link>
                </div>
                <div className="rounded border bg-white p-3 text-sm">
                    {rows.map((x) => <div className="border-b py-2" key={x.id}><Link className="text-blue-700" to={`/accounts/income/${x.id}/edit`}>{x.name || `Income #${x.id}`}</Link></div>)}
                </div>
            </div>
        </AdminLayout>
    );
}

function IncomeFormPage({ edit = false }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [form, setForm] = useState({ name: '', amount: '', income_head: '' });
    const [meta, setMeta] = useState({});
    const [err, setErr] = useState('');
    useEffect(() => {
        const url = edit ? `/income/edit/${id}` : '/income/create';
        axios.get(url, { headers: xhrJson }).then((r) => {
            setMeta(r.data?.meta || {});
            if (edit) setForm(r.data?.data || {});
        }).catch((ex) => setErr(ex.response?.data?.message || 'Failed to load form.'));
    }, [edit, id]);
    const submit = async (e) => {
        e.preventDefault();
        try {
            if (edit) await axios.put(`/income/update/${id}`, form, { headers: xhrJson });
            else await axios.post('/income/store', form, { headers: xhrJson });
            nav('/accounts/income');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Save failed.');
        }
    };
    return <AdminLayout><div className="mx-auto max-w-3xl p-6"><h1 className="text-2xl font-bold">{edit ? 'Edit income' : 'Create income'}</h1>{err ? <p className="mt-2 text-sm text-red-600">{err}</p> : null}<form onSubmit={submit} className="mt-4 grid gap-3 rounded border bg-white p-4"><input className="rounded border px-3 py-2" placeholder="Name" value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} /><input className="rounded border px-3 py-2" placeholder="Amount" value={form.amount || ''} onChange={(e) => setForm({ ...form, amount: e.target.value })} /><select className="rounded border px-3 py-2" value={form.income_head || ''} onChange={(e) => setForm({ ...form, income_head: e.target.value })}><option value="">Select head</option>{(meta.heads || []).map((h) => <option key={h.id} value={h.id}>{h.name || h.title}</option>)}</select><button className="rounded bg-blue-600 px-3 py-2 text-white">{edit ? 'Update' : 'Create'}</button></form></div></AdminLayout>;
}

function ExpensePage() {
    const [rows, setRows] = useState([]);
    useEffect(() => { axios.get('/expense', { headers: xhrJson }).then((r) => setRows(r.data?.data?.data || r.data?.data || [])); }, []);
    return (
        <AdminLayout>
            <div className="mx-auto max-w-6xl p-6">
                <div className="mb-4 flex items-center justify-between">
                    <h1 className="text-2xl font-bold">Expense</h1>
                    <Link to="/accounts/expense/create" className="rounded bg-blue-600 px-3 py-2 text-sm text-white">Create</Link>
                </div>
                <div className="rounded border bg-white p-3 text-sm">
                    {rows.map((x) => <div className="border-b py-2" key={x.id}><Link className="text-blue-700" to={`/accounts/expense/${x.id}/edit`}>{x.name || `Expense #${x.id}`}</Link></div>)}
                </div>
            </div>
        </AdminLayout>
    );
}

function ExpenseFormPage({ edit = false }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [form, setForm] = useState({ name: '', amount: '', expense_head: '' });
    const [meta, setMeta] = useState({});
    const [err, setErr] = useState('');
    useEffect(() => {
        const url = edit ? `/expense/edit/${id}` : '/expense/create';
        axios.get(url, { headers: xhrJson }).then((r) => {
            setMeta(r.data?.meta || {});
            if (edit) setForm(r.data?.data || {});
        }).catch((ex) => setErr(ex.response?.data?.message || 'Failed to load form.'));
    }, [edit, id]);
    const submit = async (e) => {
        e.preventDefault();
        try {
            if (edit) await axios.put(`/expense/update/${id}`, form, { headers: xhrJson });
            else await axios.post('/expense/store', form, { headers: xhrJson });
            nav('/accounts/expense');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Save failed.');
        }
    };
    return <AdminLayout><div className="mx-auto max-w-3xl p-6"><h1 className="text-2xl font-bold">{edit ? 'Edit expense' : 'Create expense'}</h1>{err ? <p className="mt-2 text-sm text-red-600">{err}</p> : null}<form onSubmit={submit} className="mt-4 grid gap-3 rounded border bg-white p-4"><input className="rounded border px-3 py-2" placeholder="Name" value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} /><input className="rounded border px-3 py-2" placeholder="Amount" value={form.amount || ''} onChange={(e) => setForm({ ...form, amount: e.target.value })} /><select className="rounded border px-3 py-2" value={form.expense_head || ''} onChange={(e) => setForm({ ...form, expense_head: e.target.value })}><option value="">Select head</option>{(meta.heads || []).map((h) => <option key={h.id} value={h.id}>{h.name || h.title}</option>)}</select><button className="rounded bg-blue-600 px-3 py-2 text-white">{edit ? 'Update' : 'Create'}</button></form></div></AdminLayout>;
}

function CashPage() {
    const [payload, setPayload] = useState(null);
    useEffect(() => { axios.get('/cash/cash', { headers: xhrJson }).then((r) => setPayload(r.data || null)); }, []);
    return <ReportEntryPage title="Cash" endpoint="/cash/cash" />;
}

function ProductPage() {
    const [payload, setPayload] = useState(null);
    useEffect(() => { axios.get('/product/cash', { headers: xhrJson }).then((r) => setPayload(r.data || null)); }, []);
    return <ReportEntryPage title="Product" endpoint="/product/cash" />;
}

function ProductCreatePage() {
    const nav = useNavigate();
    const [meta, setMeta] = useState({});
    const [form, setForm] = useState({ name: '', quantity: '', price: '' });
    const [err, setErr] = useState('');
    useEffect(() => {
        axios.get('/product/create', { headers: xhrJson }).then((r) => setMeta(r.data?.meta || {})).catch((ex) => setErr(ex.response?.data?.message || 'Failed to load form.'));
    }, []);
    const submit = async (e) => {
        e.preventDefault();
        try {
            await axios.post('/product/store', form, { headers: xhrJson });
            nav('/accounts/product');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Save failed.');
        }
    };
    return <AdminLayout><div className="mx-auto max-w-3xl p-6"><h1 className="text-2xl font-bold">{meta.title || 'Create Product'}</h1>{err ? <p className="mt-2 text-sm text-red-600">{err}</p> : null}<form onSubmit={submit} className="mt-4 grid gap-3 rounded border bg-white p-4"><input className="rounded border px-3 py-2" placeholder="Name" value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} /><input className="rounded border px-3 py-2" placeholder="Quantity" value={form.quantity || ''} onChange={(e) => setForm({ ...form, quantity: e.target.value })} /><input className="rounded border px-3 py-2" placeholder="Price" value={form.price || ''} onChange={(e) => setForm({ ...form, price: e.target.value })} /><button className="rounded bg-blue-600 px-3 py-2 text-white">Save</button></form></div></AdminLayout>;
}

function ProductSellPage() {
    const nav = useNavigate();
    const [meta, setMeta] = useState({});
    const [form, setForm] = useState({ name: '', quantity: '', date: '', receipt: '' });
    const [err, setErr] = useState('');
    useEffect(() => {
        axios.get('/product/sell', { headers: xhrJson }).then((r) => setMeta(r.data?.meta || {})).catch((ex) => setErr(ex.response?.data?.message || 'Failed to load form.'));
    }, []);
    const submit = async (e) => {
        e.preventDefault();
        try {
            await axios.post('/product/sellout', form, { headers: xhrJson });
            nav('/accounts/product');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Save failed.');
        }
    };
    return <AdminLayout><div className="mx-auto max-w-3xl p-6"><h1 className="text-2xl font-bold">{meta.title || 'Sell Product'}</h1>{err ? <p className="mt-2 text-sm text-red-600">{err}</p> : null}<form onSubmit={submit} className="mt-4 grid gap-3 rounded border bg-white p-4"><select className="rounded border px-3 py-2" value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })}><option value="">Select item</option>{(meta.items || []).map((i) => <option key={i.id} value={i.id}>{i.name || i.title}</option>)}</select><input className="rounded border px-3 py-2" placeholder="Quantity" value={form.quantity || ''} onChange={(e) => setForm({ ...form, quantity: e.target.value })} /><input className="rounded border px-3 py-2" placeholder="Date" value={form.date || ''} onChange={(e) => setForm({ ...form, date: e.target.value })} /><input className="rounded border px-3 py-2" placeholder="Receipt" value={form.receipt || ''} onChange={(e) => setForm({ ...form, receipt: e.target.value })} /><button className="rounded bg-blue-600 px-3 py-2 text-white">Save</button></form></div></AdminLayout>;
}

function ItemPage() {
    return <ReportEntryPage title="Item" endpoint="/item/cash" />;
}

function ItemCreatePage() {
    const nav = useNavigate();
    const [meta, setMeta] = useState({});
    const [form, setForm] = useState({ name: '', description: '' });
    const [err, setErr] = useState('');
    useEffect(() => {
        axios.get('/item/create', { headers: xhrJson }).then((r) => setMeta(r.data?.meta || {})).catch((ex) => setErr(ex.response?.data?.message || 'Failed to load form.'));
    }, []);
    const submit = async (e) => {
        e.preventDefault();
        try {
            await axios.post('/item/store', form, { headers: xhrJson });
            nav('/accounts/item');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Save failed.');
        }
    };
    return <AdminLayout><div className="mx-auto max-w-3xl p-6"><h1 className="text-2xl font-bold">{meta.title || 'Create Item'}</h1>{err ? <p className="mt-2 text-sm text-red-600">{err}</p> : null}<form onSubmit={submit} className="mt-4 grid gap-3 rounded border bg-white p-4"><input className="rounded border px-3 py-2" placeholder="Name" value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} /><textarea className="rounded border px-3 py-2" placeholder="Description" value={form.description || ''} onChange={(e) => setForm({ ...form, description: e.target.value })} /><button className="rounded bg-blue-600 px-3 py-2 text-white">Save</button></form></div></AdminLayout>;
}

function BalancePage() {
    return <ReportEntryPage title="Balance" endpoint="/balance/cash" />;
}

export default function App() {
    return (
        <Routes>
            <Route path="/" element={<Navigate to="/login" replace />} />
            <Route path="/login" element={<BackendLoginPage />} />
            <Route path="/register" element={<BackendRegisterPage />} />
            <Route path="/forgot-password" element={<BackendForgotPasswordPage />} />
            <Route path="/reset-password/:email/:token" element={<BackendResetPasswordPage />} />
            <Route path="/mail/forgot-password" element={<MailForgotPasswordPage />} />
            <Route path="/mail/reset-password/:email/:token" element={<MailResetPasswordPage />} />
            <Route path="/mail/email-verification" element={<MailEmailVerificationPage />} />
            <Route path="/student-panel" element={<StudentPanelDashboardPage />} />
            <Route path="/parent-panel" element={<ParentPanelDashboardPage />} />
            <Route path="/dashboard" element={<DashboardPage Layout={AdminLayout} />} />
            <Route path="/users" element={<UsersPage />} />
            <Route path="/users/create" element={<UserFormPage />} />
            <Route path="/users/:id/edit" element={<UserFormPage edit />} />
            <Route path="/roles" element={<RolesPage />} />
            <Route path="/students" element={<StudentsPage />} />
            <Route path="/students/create" element={<StudentCreatePage />} />
            <Route path="/students/:id" element={<StudentShowPage />} />
            <Route path="/students/:id/edit" element={<StudentEditPage />} />
            <Route path="/students/categories" element={<StudentCategoriesPage />} />
            <Route path="/students/deleted-history" element={<DeletedHistoryPage />} />
            <Route path="/students/deleted-history/:id" element={<DeletedHistoryShowPage />} />
            <Route path="/fees/collections" element={<FeesCollectionsPage Layout={AdminLayout} />} />
            <Route path="/fees/collections/:id/edit" element={<FeesCollectionEditPage Layout={AdminLayout} />} />
            <Route path="/fees/assignments" element={<FeesAssignmentsPage Layout={AdminLayout} />} />
            <Route path="/fees/assignments/create" element={<FeesAssignmentFormPage Layout={AdminLayout} />} />
            <Route path="/fees/assignments/:id/edit" element={<FeesAssignmentFormPage Layout={AdminLayout} edit />} />
            <Route path="/fees/types" element={<FeesTypesPage Layout={AdminLayout} />} />
            <Route path="/fees/types/create" element={<FeesTypeFormPage Layout={AdminLayout} />} />
            <Route path="/fees/types/:id/edit" element={<FeesTypeFormPage Layout={AdminLayout} edit />} />
            <Route path="/fees/groups" element={<FeesGroupsPage Layout={AdminLayout} />} />
            <Route path="/fees/groups/create" element={<FeesGroupFormPage Layout={AdminLayout} />} />
            <Route path="/fees/groups/:id/edit" element={<FeesGroupFormPage Layout={AdminLayout} edit />} />
            <Route path="/fees/masters" element={<FeesMastersPage Layout={AdminLayout} />} />
            <Route path="/fees/masters/create" element={<FeesMasterFormPage Layout={AdminLayout} />} />
            <Route path="/fees/masters/:id/edit" element={<FeesMasterFormPage Layout={AdminLayout} edit />} />
            <Route path="/examination" element={<ExaminationHomePage Layout={AdminLayout} />} />
            <Route path="/examination/marks-grades" element={<MarksGradesListPage Layout={AdminLayout} />} />
            <Route path="/examination/marks-grades/create" element={<MarksGradesFormPage Layout={AdminLayout} />} />
            <Route path="/examination/marks-grades/:id/edit" element={<MarksGradesFormPage Layout={AdminLayout} edit />} />
            <Route path="/examination/settings" element={<ExaminationSettingsPage Layout={AdminLayout} />} />
            <Route path="/examination/exam-assign" element={<ExamAssignListPage Layout={AdminLayout} />} />
            <Route path="/examination/exam-assign/create" element={<ExamAssignCreatePage Layout={AdminLayout} />} />
            <Route path="/examination/exam-assign/:id/edit" element={<ExamAssignEditPage Layout={AdminLayout} />} />
            <Route path="/examination/marks-register" element={<MarksRegisterListPage Layout={AdminLayout} />} />
            <Route path="/examination/marks-register/create" element={<MarksRegisterCreatePage Layout={AdminLayout} />} />
            <Route path="/examination/marks-register/:id/view" element={<MarksRegisterViewPage Layout={AdminLayout} />} />
            <Route path="/examination/marks-register/:id/edit" element={<MarksRegisterEditPage Layout={AdminLayout} />} />
            <Route path="/settings/genders" element={<GendersListPage Layout={AdminLayout} />} />
            <Route path="/settings/genders/create" element={<GendersFormPage Layout={AdminLayout} />} />
            <Route path="/settings/genders/:id/edit" element={<GendersFormPage Layout={AdminLayout} edit />} />
            <Route path="/settings/genders/:id/translate" element={<GendersTranslatePage Layout={AdminLayout} />} />
            <Route path="/settings/religions" element={<ReligionsListPage Layout={AdminLayout} />} />
            <Route path="/settings/religions/create" element={<ReligionsFormPage Layout={AdminLayout} />} />
            <Route path="/settings/religions/:id/edit" element={<ReligionsFormPage Layout={AdminLayout} edit />} />
            <Route path="/settings/religions/:id/translate" element={<ReligionsTranslatePage Layout={AdminLayout} />} />
            <Route path="/settings/sessions" element={<SessionsListPage Layout={AdminLayout} />} />
            <Route path="/settings/sessions/create" element={<SessionsFormPage Layout={AdminLayout} />} />
            <Route path="/settings/sessions/:id/edit" element={<SessionsFormPage Layout={AdminLayout} edit />} />
            <Route path="/settings/sessions/:id/translate" element={<SessionsTranslatePage Layout={AdminLayout} />} />
            <Route path="/orders" element={<OrdersListPage Layout={AdminLayout} />} />
            <Route path="/orders/create" element={<OrdersCreatePage Layout={AdminLayout} />} />
            <Route path="/liveclass/gmeet" element={<GmeetListPage Layout={AdminLayout} />} />
            <Route path="/liveclass/gmeet/create" element={<GmeetFormPage Layout={AdminLayout} />} />
            <Route path="/liveclass/gmeet/:id/edit" element={<GmeetFormPage Layout={AdminLayout} edit />} />
            <Route path="/homework" element={<HomeworkListPage Layout={AdminLayout} />} />
            <Route path="/homework/create" element={<HomeworkFormPage Layout={AdminLayout} />} />
            <Route path="/homework/:id/edit" element={<HomeworkFormPage Layout={AdminLayout} edit />} />
            <Route path="/goods" element={<GoodsHomePage Layout={AdminLayout} />} />
            <Route path="/idcard" element={<IdCardListPage Layout={AdminLayout} />} />
            <Route path="/idcard/create" element={<IdCardFormPage Layout={AdminLayout} />} />
            <Route path="/idcard/:id/edit" element={<IdCardFormPage Layout={AdminLayout} edit />} />
            <Route path="/idcard/generate" element={<IdCardGeneratePage Layout={AdminLayout} />} />
            <Route path="/languages" element={<LanguagesListPage Layout={AdminLayout} />} />
            <Route path="/languages/create" element={<LanguageFormPage Layout={AdminLayout} />} />
            <Route path="/languages/:id/edit" element={<LanguageFormPage Layout={AdminLayout} edit />} />
            <Route path="/languages/:id/terms" element={<LanguageTermsPage Layout={AdminLayout} />} />
            <Route path="/library" element={<LibraryHomePage Layout={AdminLayout} />} />
            <Route path="/library/create" element={<LibraryHomePage Layout={AdminLayout} />} />
            <Route path="/library/:id/edit" element={<LibraryHomePage Layout={AdminLayout} />} />
            <Route path="/parents" element={<ParentsPage />} />
            <Route path="/parents/create" element={<ParentFormPage />} />
            <Route path="/parents/:id/edit" element={<ParentFormPage edit />} />
            <Route path="/students/promote" element={<PromoteStudentsPage />} />
            <Route path="/students/disabled" element={<DisabledStudentsPage />} />
            <Route path="/academic" element={<AcademicHomePage Layout={AdminLayout} />} />
            <Route path="/academic/classes" element={<AcademicListPage Layout={AdminLayout} title="Classes" endpoint="/classes" createTo="/academic/classes/create" editBase="/academic/classes" />} />
            <Route path="/academic/classes/create" element={<AcademicFormPage Layout={AdminLayout} titleCreate="Create Class" titleEdit="Edit Class" loadEndpoint="/classes" storeEndpoint="/classes/store" updateEndpoint="/classes/update" backTo="/academic/classes" />} />
            <Route path="/academic/classes/:id/edit" element={<AcademicFormPage Layout={AdminLayout} titleCreate="Create Class" titleEdit="Edit Class" loadEndpoint="/classes" storeEndpoint="/classes/store" updateEndpoint="/classes/update" backTo="/academic/classes" />} />
            <Route path="/academic/sections" element={<AcademicListPage Layout={AdminLayout} title="Sections" endpoint="/section" createTo="/academic/sections/create" editBase="/academic/sections" />} />
            <Route path="/academic/sections/create" element={<AcademicFormPage Layout={AdminLayout} titleCreate="Create Section" titleEdit="Edit Section" loadEndpoint="/section" storeEndpoint="/section/store" updateEndpoint="/section/update" backTo="/academic/sections" />} />
            <Route path="/academic/sections/:id/edit" element={<AcademicFormPage Layout={AdminLayout} titleCreate="Create Section" titleEdit="Edit Section" loadEndpoint="/section" storeEndpoint="/section/store" updateEndpoint="/section/update" backTo="/academic/sections" />} />
            <Route path="/academic/subjects" element={<AcademicListPage Layout={AdminLayout} title="Subjects" endpoint="/subject" createTo="/academic/subjects/create" editBase="/academic/subjects" />} />
            <Route path="/academic/subjects/create" element={<AcademicFormPage Layout={AdminLayout} titleCreate="Create Subject" titleEdit="Edit Subject" loadEndpoint="/subject" storeEndpoint="/subject/store" updateEndpoint="/subject/update" backTo="/academic/subjects" />} />
            <Route path="/academic/subjects/:id/edit" element={<AcademicFormPage Layout={AdminLayout} titleCreate="Create Subject" titleEdit="Edit Subject" loadEndpoint="/subject" storeEndpoint="/subject/store" updateEndpoint="/subject/update" backTo="/academic/subjects" />} />
            <Route path="/academic/shifts" element={<AcademicListPage Layout={AdminLayout} title="Shifts" endpoint="/shift" createTo="/academic/shifts/create" editBase="/academic/shifts" />} />
            <Route path="/academic/shifts/create" element={<AcademicFormPage Layout={AdminLayout} titleCreate="Create Shift" titleEdit="Edit Shift" loadEndpoint="/shift" storeEndpoint="/shift/store" updateEndpoint="/shift/update" backTo="/academic/shifts" />} />
            <Route path="/academic/shifts/:id/edit" element={<AcademicFormPage Layout={AdminLayout} titleCreate="Create Shift" titleEdit="Edit Shift" loadEndpoint="/shift" storeEndpoint="/shift/store" updateEndpoint="/shift/update" backTo="/academic/shifts" />} />
            <Route path="/academic/class-rooms" element={<AcademicListPage Layout={AdminLayout} title="Class Rooms" endpoint="/class-room" createTo="/academic/class-rooms/create" editBase="/academic/class-rooms" />} />
            <Route path="/academic/class-rooms/create" element={<AcademicFormPage Layout={AdminLayout} titleCreate="Create Class Room" titleEdit="Edit Class Room" loadEndpoint="/class-room" storeEndpoint="/class-room/store" updateEndpoint="/class-room/update" backTo="/academic/class-rooms" />} />
            <Route path="/academic/class-rooms/:id/edit" element={<AcademicFormPage Layout={AdminLayout} titleCreate="Create Class Room" titleEdit="Edit Class Room" loadEndpoint="/class-room" storeEndpoint="/class-room/store" updateEndpoint="/class-room/update" backTo="/academic/class-rooms" />} />
            <Route path="/academic/class-setups" element={<AcademicListPage Layout={AdminLayout} title="Class Setups" endpoint="/class-setup" createTo="/academic/class-setups/create" editBase="/academic/class-setups" />} />
            <Route path="/academic/class-setups/create" element={<AcademicFormPage Layout={AdminLayout} titleCreate="Create Class Setup" titleEdit="Edit Class Setup" loadEndpoint="/class-setup" storeEndpoint="/class-setup/store" updateEndpoint="/class-setup/update" backTo="/academic/class-setups" />} />
            <Route path="/academic/class-setups/:id/edit" element={<AcademicFormPage Layout={AdminLayout} titleCreate="Create Class Setup" titleEdit="Edit Class Setup" loadEndpoint="/class-setup" storeEndpoint="/class-setup/store" updateEndpoint="/class-setup/update" backTo="/academic/class-setups" />} />
            <Route path="/academic/subject-assigns" element={<AcademicListPage Layout={AdminLayout} title="Subject Assigns" endpoint="/assign-subject" createTo="/academic/subject-assigns/create" editBase="/academic/subject-assigns" />} />
            <Route path="/academic/subject-assigns/create" element={<AcademicFormPage Layout={AdminLayout} titleCreate="Create Subject Assign" titleEdit="Edit Subject Assign" loadEndpoint="/assign-subject" storeEndpoint="/assign-subject/store" updateEndpoint="/assign-subject/update" backTo="/academic/subject-assigns" />} />
            <Route path="/academic/subject-assigns/:id/edit" element={<AcademicFormPage Layout={AdminLayout} titleCreate="Create Subject Assign" titleEdit="Edit Subject Assign" loadEndpoint="/assign-subject" storeEndpoint="/assign-subject/store" updateEndpoint="/assign-subject/update" backTo="/academic/subject-assigns" />} />
            <Route path="/academic/time-schedules" element={<AcademicListPage Layout={AdminLayout} title="Time Schedules" endpoint="/time/schedule" createTo="/academic/time-schedules/create" editBase="/academic/time-schedules" />} />
            <Route path="/academic/time-schedules/create" element={<AcademicFormPage Layout={AdminLayout} titleCreate="Create Time Schedule" titleEdit="Edit Time Schedule" loadEndpoint="/time/schedule" storeEndpoint="/time/schedule/store" updateEndpoint="/time/schedule/update" backTo="/academic/time-schedules" />} />
            <Route path="/academic/time-schedules/:id/edit" element={<AcademicFormPage Layout={AdminLayout} titleCreate="Create Time Schedule" titleEdit="Edit Time Schedule" loadEndpoint="/time/schedule" storeEndpoint="/time/schedule/store" updateEndpoint="/time/schedule/update" backTo="/academic/time-schedules" />} />
            <Route path="/academic/class-routines" element={<AcademicListPage Layout={AdminLayout} title="Class Routines" endpoint="/class-routine" createTo="/academic/class-routines/create" editBase="/academic/class-routines" />} />
            <Route path="/academic/class-routines/create" element={<AcademicFormPage Layout={AdminLayout} titleCreate="Create Class Routine" titleEdit="Edit Class Routine" loadEndpoint="/class-routine" storeEndpoint="/class-routine/store" updateEndpoint="/class-routine/update" backTo="/academic/class-routines" />} />
            <Route path="/academic/class-routines/:id/edit" element={<AcademicFormPage Layout={AdminLayout} titleCreate="Create Class Routine" titleEdit="Edit Class Routine" loadEndpoint="/class-routine" storeEndpoint="/class-routine/store" updateEndpoint="/class-routine/update" backTo="/academic/class-routines" />} />
            <Route path="/academic/exam-routines" element={<AcademicListPage Layout={AdminLayout} title="Exam Routines" endpoint="/exam-routine" createTo="/academic/exam-routines/create" editBase="/academic/exam-routines" />} />
            <Route path="/academic/exam-routines/create" element={<AcademicFormPage Layout={AdminLayout} titleCreate="Create Exam Routine" titleEdit="Edit Exam Routine" loadEndpoint="/exam-routine" storeEndpoint="/exam-routine/store" updateEndpoint="/exam-routine/update" backTo="/academic/exam-routines" />} />
            <Route path="/academic/exam-routines/:id/edit" element={<AcademicFormPage Layout={AdminLayout} titleCreate="Create Exam Routine" titleEdit="Edit Exam Routine" loadEndpoint="/exam-routine" storeEndpoint="/exam-routine/store" updateEndpoint="/exam-routine/update" backTo="/academic/exam-routines" />} />
            <Route path="/accounts" element={<AccountsHomePage />} />
            <Route path="/accounts/chart-of-accounts" element={<ChartOfAccountsPage />} />
            <Route path="/accounts/chart-of-accounts/create" element={<ChartOfAccountsFormPage />} />
            <Route path="/accounts/chart-of-accounts/:id/edit" element={<ChartOfAccountsFormPage edit />} />
            <Route path="/accounts/payment-methods" element={<PaymentMethodsPage />} />
            <Route path="/accounts/payment-methods/create" element={<PaymentMethodFormPage />} />
            <Route path="/accounts/payment-methods/:id/edit" element={<PaymentMethodFormPage edit />} />
            <Route path="/accounts/account-heads" element={<AccountHeadsPage />} />
            <Route path="/accounts/account-heads/create" element={<AccountHeadFormPage />} />
            <Route path="/accounts/account-heads/:id/edit" element={<AccountHeadFormPage edit />} />
            <Route path="/accounts/income" element={<IncomePage />} />
            <Route path="/accounts/income/create" element={<IncomeFormPage />} />
            <Route path="/accounts/income/:id/edit" element={<IncomeFormPage edit />} />
            <Route path="/accounts/expense" element={<ExpensePage />} />
            <Route path="/accounts/expense/create" element={<ExpenseFormPage />} />
            <Route path="/accounts/expense/:id/edit" element={<ExpenseFormPage edit />} />
            <Route path="/accounts/deposits" element={<DepositsPage Layout={AdminLayout} />} />
            <Route path="/accounts/deposits/create" element={<DepositFormPage Layout={AdminLayout} />} />
            <Route path="/accounts/deposits/:id/edit" element={<DepositFormPage Layout={AdminLayout} />} />
            <Route path="/accounts/payments" element={<PaymentsPage Layout={AdminLayout} />} />
            <Route path="/accounts/payments/create" element={<PaymentFormPage Layout={AdminLayout} />} />
            <Route path="/accounts/payments/:id/edit" element={<PaymentFormPage Layout={AdminLayout} />} />
            <Route path="/accounts/transactions" element={<TransactionsPage Layout={AdminLayout} />} />
            <Route path="/accounts/transactions/create" element={<TransactionFormPage Layout={AdminLayout} />} />
            <Route path="/accounts/transactions/:id/edit" element={<TransactionFormPage Layout={AdminLayout} />} />
            <Route path="/accounts/suppliers" element={<SuppliersPage Layout={AdminLayout} />} />
            <Route path="/accounts/suppliers/create" element={<SupplierFormPage Layout={AdminLayout} />} />
            <Route path="/accounts/suppliers/:id/edit" element={<SupplierFormPage Layout={AdminLayout} />} />
            <Route path="/accounts/invoices" element={<InvoicesPage Layout={AdminLayout} />} />
            <Route path="/accounts/invoices/create" element={<InvoiceFormPage Layout={AdminLayout} />} />
            <Route path="/accounts/invoices/:id/edit" element={<InvoiceFormPage Layout={AdminLayout} />} />
            <Route path="/accounts/cash" element={<CashPage />} />
            <Route path="/accounts/product" element={<ProductPage />} />
            <Route path="/accounts/product/create" element={<ProductCreatePage />} />
            <Route path="/accounts/product/sell" element={<ProductSellPage />} />
            <Route path="/accounts/item" element={<ItemPage />} />
            <Route path="/accounts/item/create" element={<ItemCreatePage />} />
            <Route path="/accounts/balance" element={<BalancePage />} />
            <Route path="/attendance" element={<AttendanceIndexPage Layout={AdminLayout} />} />
            <Route path="/attendance/report" element={<AttendanceReportPage Layout={AdminLayout} />} />
            <Route path="/attendance/notification" element={<AttendanceNotificationPage Layout={AdminLayout} />} />
            <Route path="/reports" element={<ReportsHomePage />} />
            <Route path="/reports/marksheet" element={<ReportEntryPage title="Marksheet Report" endpoint="/report-marksheet" />} />
            <Route path="/reports/merit-list" element={<ReportEntryPage title="Merit List Report" endpoint="/report-merit-list" />} />
            <Route path="/reports/progress-card" element={<ReportEntryPage title="Progress Card Report" endpoint="/report-progress-card" />} />
            <Route path="/reports/due-fees" element={<ReportEntryPage title="Due Fees Report" endpoint="/report-due-fees" />} />
            <Route path="/reports/class-routine" element={<ReportEntryPage title="Class Routine Report" endpoint="/report-class-routine" />} />
            <Route path="/reports/exam-routine" element={<ReportEntryPage title="Exam Routine Report" endpoint="/report-exam-routine" />} />
            <Route path="/reports/duplicate-students" element={<ReportEntryPage title="Duplicate Students Report" endpoint="/report-duplicate-students" />} />
            <Route path="/reports/account" element={<ReportEntryPage title="Account Report" endpoint="/report-account" />} />
            <Route path="/reports/accounting/income" element={<ReportEntryPage title="Accounting Income Report" endpoint="/accounting/reports/income" />} />
            <Route path="/reports/accounting/expense" element={<ReportEntryPage title="Accounting Expense Report" endpoint="/accounting/reports/expense" />} />
            <Route path="/reports/accounting/profit-loss" element={<ReportEntryPage title="Accounting Profit/Loss Report" endpoint="/accounting/reports/profit-loss" />} />
            <Route path="/reports/accounting/dashboard" element={<ReportEntryPage title="Accounting Dashboard" endpoint="/accounting/dashboard" />} />
            <Route path="/reports/accounting/cashbook" element={<ReportEntryPage title="Accounting Cashbook" endpoint="/accounting/cashbook" />} />
            <Route path="/reports/accounting/audit-log" element={<ReportEntryPage title="Accounting Audit Log" endpoint="/accounting/audit-log" />} />
            <Route path="/reports/fees-collection" element={<ReportEntryPage title="Fees Collection Report" endpoint="/report-fees-collection" />} />
            <Route path="/reports/fees-summary" element={<ReportEntryPage title="Fees Summary Report" endpoint="/report-fees-summary" />} />
            <Route path="/reports/students" element={<ReportEntryPage title="Students Report" endpoint="/report-students" />} />
            <Route path="/reports/fees-by-year" element={<ReportEntryPage title="Fees By Year Report" endpoint="/report-fees-by-year" />} />
            <Route path="/reports/fees-by-year/:studentId" element={<ReportEntryPage title="Fees By Year Detail" endpoint="/report-fees-by-year" />} />
            <Route path="/reports/boarding-students" element={<ReportEntryPage title="Boarding Students Report" endpoint="/report-boarding-students" />} />
            <Route path="/reports/boarding-students/missing-2026" element={<ReportEntryPage title="Missing Boarding Students 2026" endpoint="/report-boarding-students/find-missing-2026" />} />
            <Route path="/reports/accounting/bank-reconciliation" element={<ReportEntryPage title="Bank Reconciliation" endpoint="/accounting/bank-reconciliation" />} />
            <Route path="/reports/accounting/bank-reconciliation/process" element={<ReportEntryPage title="Bank Reconciliation Process" endpoint="/accounting/bank-reconciliation/process" />} />
            <Route path="/my/profile" element={<ProfilePage />} />
            <Route path="/my/profile/edit" element={<ProfileEditPage />} />
            <Route path="/my/password/update" element={<PasswordUpdatePage />} />
            <Route path="/settings/general" element={<SettingsGeneralPage />} />
            <Route path="/settings/notification" element={<EndpointDataPage Layout={AdminLayout} title="Notification Setting" endpoint="/notification-settings" />} />
            <Route path="/settings/storage" element={<EndpointDataPage Layout={AdminLayout} title="Storage Settings" endpoint="/storage-setting" />} />
            <Route path="/settings/task-schedulers" element={<EndpointDataPage Layout={AdminLayout} title="Task Schedules" endpoint="/task-schedulers" />} />
            <Route path="/settings/software-update" element={<EndpointDataPage Layout={AdminLayout} title="Software Update" endpoint="/software-update" />} />
            <Route path="/settings/recaptcha" element={<EndpointDataPage Layout={AdminLayout} title="Recaptcha Settings" endpoint="/recaptcha-setting" />} />
            <Route path="/settings/sms" element={<EndpointDataPage Layout={AdminLayout} title="SMS Settings" endpoint="/sms-setting" />} />
            <Route path="/settings/payment-gateway" element={<EndpointDataPage Layout={AdminLayout} title="Payment Gateway Settings" endpoint="/payment-gateway-setting" />} />
            <Route path="/settings/email" element={<EndpointDataPage Layout={AdminLayout} title="Email Settings" endpoint="/email-setting" />} />
            <Route path="/staff/department" element={<EndpointDataPage Layout={AdminLayout} title="Department" endpoint="/department" />} />
            <Route path="/staff/batch-processing" element={<EndpointDataPage Layout={AdminLayout} title="Batch Processing" endpoint="/salary" />} />
            <Route path="/staff/designation" element={<EndpointDataPage Layout={AdminLayout} title="Designation" endpoint="/designation" />} />
            <Route path="/fees/transactions" element={<EndpointDataPage Layout={AdminLayout} title="Fees Transactions" endpoint="/fees-collect/collect-list" />} />
            <Route path="/fees/online-transactions" element={<EndpointDataPage Layout={AdminLayout} title="Online Transactions" endpoint="/fees-collect/collect-transactions" />} />
            <Route path="/fees/amendments" element={<EndpointDataPage Layout={AdminLayout} title="Amendments" endpoint="/fees-collect/collect-amendment" />} />
            <Route path="/banks-accounts" element={<BankAccountsListPage Layout={AdminLayout} />} />
            <Route path="/banks-accounts/create" element={<BankAccountsFormPage Layout={AdminLayout} />} />
            <Route path="/banks-accounts/:id/edit" element={<BankAccountsFormPage Layout={AdminLayout} edit />} />
            <Route path="/blood-groups" element={<BloodGroupsListPage Layout={AdminLayout} />} />
            <Route path="/blood-groups/create" element={<BloodGroupsFormPage Layout={AdminLayout} />} />
            <Route path="/blood-groups/:id/edit" element={<BloodGroupsFormPage Layout={AdminLayout} edit />} />
            <Route path="/certificate" element={<CertificateListPage Layout={AdminLayout} />} />
            <Route path="/certificate/create" element={<CertificateFormPage Layout={AdminLayout} />} />
            <Route path="/certificate/:id/edit" element={<CertificateFormPage Layout={AdminLayout} edit />} />
            <Route path="/certificate/generate" element={<CertificateGeneratePage Layout={AdminLayout} />} />
            <Route path="/certificate-ui" element={<CertificateUiHomePage Layout={AdminLayout} />} />
            <Route path="/certificate-ui/list" element={<CertificateUiListPage Layout={AdminLayout} />} />
            <Route path="/certificate-ui/create" element={<CertificateUiCreatePage Layout={AdminLayout} />} />
            <Route path="/certificate-ui/generate" element={<CertificateUiGeneratePage Layout={AdminLayout} />} />
            <Route path="/communication/notice-board" element={<NoticeBoardListPage Layout={AdminLayout} />} />
            <Route path="/communication/notice-board/create" element={<NoticeBoardFormPage Layout={AdminLayout} />} />
            <Route path="/communication/notice-board/:id/edit" element={<NoticeBoardFormPage Layout={AdminLayout} edit />} />
            <Route path="/communication/notice-board/:id/translate" element={<NoticeBoardTranslatePage Layout={AdminLayout} />} />
            <Route path="/communication/template" element={<SmsTemplateListPage Layout={AdminLayout} />} />
            <Route path="/communication/template/create" element={<SmsTemplateFormPage Layout={AdminLayout} />} />
            <Route path="/communication/template/:id/edit" element={<SmsTemplateFormPage Layout={AdminLayout} edit />} />
            <Route path="/communication/smsmail" element={<SmsMailListPage Layout={AdminLayout} />} />
            <Route path="/communication/smsmail/create" element={<SmsMailCreatePage Layout={AdminLayout} />} />
            <Route path="/communication/smsmail/campaign" element={<SmsCampaignPage Layout={AdminLayout} />} />
            <Route path="/backend" element={<BackendViewHubPage Layout={AdminLayout} />} />
            <Route path="/backend/dashboard" element={<BackendDashboardPage Layout={AdminLayout} />} />
            <Route path="/backend/dashboard-pdf" element={<BackendDashboardPdfPage Layout={AdminLayout} />} />
            <Route path="/backend/dashboardtable" element={<BackendDashboardTablePage Layout={AdminLayout} />} />
            <Route path="/backend/master" element={<BackendMasterPage Layout={AdminLayout} />} />
            <Route path="/backend/menu-autocomplete" element={<BackendMenuAutocompletePage Layout={AdminLayout} />} />
            <Route path="/common" element={<CommonViewHubPage Layout={AdminLayout} />} />
            <Route path="/common/pagination" element={<GenericMigratedPage Layout={AdminLayout} title="Common Pagination" description="Hand-built SPA page replacing common/pagination.blade.php." />} />
            <Route path="/components" element={<CommonViewHubPage Layout={AdminLayout} />} />
            <Route path="/components/sidebar-header" element={<GenericMigratedPage Layout={AdminLayout} title="Component Sidebar Header" description="Hand-built SPA page replacing components/sidebar-header.blade.php." />} />
            <Route path="/components/certificate-generate" element={<GenericMigratedPage Layout={AdminLayout} title="Component Certificate Generate" description="Hand-built SPA page replacing components/certificate-generate.blade.php." />} />
            <Route path="/emails" element={<CommonViewHubPage Layout={AdminLayout} />} />
            <Route path="/emails/daily-report" element={<GenericMigratedPage Layout={AdminLayout} title="Email Daily Report" description="Hand-built SPA preview replacing emails/daily_report.blade.php." />} />
            <Route path="/errors" element={<ErrorsHubPage Layout={AdminLayout} />} />
            <Route path="/errors/400" element={<GenericMigratedPage Layout={AdminLayout} title="400 Error" description="Hand-built SPA error page." />} />
            <Route path="/errors/403" element={<GenericMigratedPage Layout={AdminLayout} title="403 Error" description="Hand-built SPA error page." />} />
            <Route path="/errors/404" element={<GenericMigratedPage Layout={AdminLayout} title="404 Error" description="Hand-built SPA error page." />} />
            <Route path="/errors/405" element={<GenericMigratedPage Layout={AdminLayout} title="405 Error" description="Hand-built SPA error page." />} />
            <Route path="/errors/500" element={<GenericMigratedPage Layout={AdminLayout} title="500 Error" description="Hand-built SPA error page." />} />
            <Route path="/frontend" element={<FrontendHubPage Layout={AdminLayout} />} />
            <Route path="/frontend/about" element={<EndpointDataPage Layout={AdminLayout} title="Frontend About" endpoint="/about" />} />
            <Route path="/frontend/news" element={<EndpointDataPage Layout={AdminLayout} title="Frontend News" endpoint="/news" />} />
            <Route path="/frontend/events" element={<EndpointDataPage Layout={AdminLayout} title="Frontend Events" endpoint="/events" />} />
            <Route path="/frontend/notices" element={<EndpointDataPage Layout={AdminLayout} title="Frontend Notices" endpoint="/notices" />} />
            <Route path="/frontend/contact" element={<EndpointDataPage Layout={AdminLayout} title="Frontend Contact" endpoint="/contact" />} />
            <Route path="/frontend/result" element={<EndpointDataPage Layout={AdminLayout} title="Frontend Result" endpoint="/result" />} />
            <Route path="/frontend/page" element={<EndpointDataPage Layout={AdminLayout} title="Frontend Dynamic Page" endpoint="/page/about-us" />} />
            <Route path="/frontend-landing" element={<FrontendHubPage Layout={AdminLayout} />} />
            <Route path="/frontend-landing/school" element={<GenericMigratedPage Layout={AdminLayout} title="Frontend Landing School" description="Hand-built SPA page replacing frontend-landing/school_landing.blade.php." />} />
            <Route path="/layouts/app" element={<GenericMigratedPage Layout={AdminLayout} title="Layouts App" description="Hand-built SPA page replacing layouts/app.blade.php." />} />
            <Route path="/parent-panel/pages" element={<PanelHubPage Layout={AdminLayout} />} />
            <Route path="/parent-panel/dashboard" element={<EndpointDataPage Layout={AdminLayout} title="Parent Panel Dashboard" endpoint="/parent-panel-dashboard" />} />
            <Route path="/parent-panel/profile" element={<PanelProfileViewPage Layout={AdminLayout} title="Parent Profile" endpoint="/parent-panel/profile" />} />
            <Route path="/parent-panel/profile/edit" element={<PanelProfileEditPage Layout={AdminLayout} title="Edit Parent Profile" loadEndpoint="/parent-panel/profile/edit" saveEndpoint="/parent-panel/profile/update" />} />
            <Route path="/parent-panel/password/update" element={<PanelPasswordPage Layout={AdminLayout} title="Update Parent Password" saveEndpoint="/parent-panel/password/update/store" />} />
            <Route path="/parent-panel/notices" element={<PanelListPage Layout={AdminLayout} title="Parent Notices" endpoint="/parent-panel-notices" preferredKey="notice-boards" />} />
            <Route path="/parent-panel/attendance" element={<EndpointDataPage Layout={AdminLayout} title="Parent Panel Attendance" endpoint="/parent-panel-attendance" />} />
            <Route path="/parent-panel/class-routine" element={<EndpointDataPage Layout={AdminLayout} title="Parent Panel Class Routine" endpoint="/parent-panel-class-routine" />} />
            <Route path="/parent-panel/exam-routine" element={<EndpointDataPage Layout={AdminLayout} title="Parent Panel Exam Routine" endpoint="/parent-panel-exam-routine" />} />
            <Route path="/parent-panel/subject-list" element={<EndpointDataPage Layout={AdminLayout} title="Parent Panel Subject List" endpoint="/parent-panel-subject-list" />} />
            <Route path="/parent-panel/homework-list" element={<EndpointDataPage Layout={AdminLayout} title="Parent Panel Homework List" endpoint="/parent-panel-homeworks" />} />
            <Route path="/parent-panel/fees" element={<EndpointDataPage Layout={AdminLayout} title="Parent Panel Fees" endpoint="/parent-panel-fees" />} />
            <Route path="/parent-panel/marksheet" element={<EndpointDataPage Layout={AdminLayout} title="Parent Panel Marksheet" endpoint="/parent-panel-marksheet" />} />
            <Route path="/parent-panel/books" element={<PanelListPage Layout={AdminLayout} title="Parent Books" endpoint="/parent/panel/books" preferredKey="book" />} />
            <Route path="/parent-panel/issue-books" element={<PanelListPage Layout={AdminLayout} title="Parent Issue Books" endpoint="/parent/panel/issue-books" preferredKey="issue_book" />} />
            <Route path="/student-panel/pages" element={<PanelHubPage Layout={AdminLayout} />} />
            <Route path="/student-panel/dashboard" element={<EndpointDataPage Layout={AdminLayout} title="Student Panel Dashboard" endpoint="/student-panel-dashboard" />} />
            <Route path="/student-panel/profile" element={<PanelProfileViewPage Layout={AdminLayout} title="Student Profile" endpoint="/student-panel/profile" />} />
            <Route path="/student-panel/profile/edit" element={<PanelProfileEditPage Layout={AdminLayout} title="Edit Student Profile" loadEndpoint="/student-panel/profile/edit" saveEndpoint="/student-panel/profile/update" />} />
            <Route path="/student-panel/password/update" element={<PanelPasswordPage Layout={AdminLayout} title="Update Student Password" saveEndpoint="/student-panel/password/update/store" />} />
            <Route path="/student-panel/notices" element={<PanelListPage Layout={AdminLayout} title="Student Notices" endpoint="/student-panel-notices" preferredKey="notice-boards" />} />
            <Route path="/student-panel/gmeet" element={<PanelListPage Layout={AdminLayout} title="Student Gmeet" endpoint="/student-panel-gmeet" preferredKey="gmeets" />} />
            <Route path="/student-panel/attendance" element={<EndpointDataPage Layout={AdminLayout} title="Student Panel Attendance" endpoint="/student-panel-attendance" />} />
            <Route path="/student-panel/class-routine" element={<EndpointDataPage Layout={AdminLayout} title="Student Panel Class Routine" endpoint="/student-panel-class-routine" />} />
            <Route path="/student-panel/exam-routine" element={<EndpointDataPage Layout={AdminLayout} title="Student Panel Exam Routine" endpoint="/student-panel-exam-routine" />} />
            <Route path="/student-panel/subject-list" element={<EndpointDataPage Layout={AdminLayout} title="Student Panel Subject List" endpoint="/student-panel-subject-list" />} />
            <Route path="/student-panel/homeworks" element={<EndpointDataPage Layout={AdminLayout} title="Student Panel Homeworks" endpoint="/stundet/panel/homeworks" />} />
            <Route path="/student-panel/fees" element={<EndpointDataPage Layout={AdminLayout} title="Student Panel Fees" endpoint="/student-panel-fees" />} />
            <Route path="/student-panel/marksheet" element={<EndpointDataPage Layout={AdminLayout} title="Student Panel Marksheet" endpoint="/student-panel-marksheet" />} />
            <Route path="/student-panel/books" element={<PanelListPage Layout={AdminLayout} title="Student Books" endpoint="/stundet/panel/books" preferredKey="book" />} />
            <Route path="/student-panel/issue-books" element={<PanelListPage Layout={AdminLayout} title="Student Issue Books" endpoint="/stundet/panel/issue-books" preferredKey="issue_book" />} />
            <Route path="/student-panel/online-exam" element={<PanelListPage Layout={AdminLayout} title="Student Online Exams" endpoint="/student-panel-online-examination" detailBase="/student-panel/online-exam" />} />
            <Route path="/student-panel/online-exam/:id/view" element={<OnlineExamViewPage Layout={AdminLayout} />} />
            <Route path="/student-panel/online-exam/:id/result" element={<OnlineExamResultPage Layout={AdminLayout} />} />
            <Route path="/home" element={<GenericMigratedPage Layout={AdminLayout} title="Home" description="Hand-built SPA page replacing home.blade.php." />} />
            <Route path="/index" element={<GenericMigratedPage Layout={AdminLayout} title="Index" description="Hand-built SPA page replacing index.blade.php." />} />
            <Route path="/welcome" element={<GenericMigratedPage Layout={AdminLayout} title="Welcome" description="Hand-built SPA page replacing welcome.blade.php." />} />
            <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
    );
}

