import React, { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';
import { AdminLayout } from '../layout/AdminLayout';

const xhrJson = { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' };

export function StudentCreatePage() {
    const nav = useNavigate();
    const [meta, setMeta] = useState({});
    const [form, setForm] = useState({ first_name: '', last_name: '', category: '', class: '' });
    const [err, setErr] = useState('');

    useEffect(() => {
        axios.get('/student/create', { headers: xhrJson })
            .then((r) => {
                const m = r.data?.meta || {};
                setMeta(m);
                const defaultCategory = m.categories?.[0]?.id || '';
                const defaultClass = m.classes?.[0]?.id || '';
                setForm((f) => ({ ...f, category: defaultCategory, class: defaultClass }));
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load form.'));
    }, []);

    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        try {
            await axios.post('/student/store', form, { headers: xhrJson });
            nav('/students');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Create failed.');
        }
    };

    return (
        <AdminLayout>
            <div className="mx-auto max-w-3xl p-6">
                <h1 className="text-2xl font-bold">{meta.title || 'Create student'}</h1>
                {err ? <p className="mt-2 text-sm text-red-600">{err}</p> : null}
                <form onSubmit={submit} className="mt-4 grid gap-3 rounded border bg-white p-4">
                    <input className="rounded border px-3 py-2" placeholder="First name" value={form.first_name} onChange={(e) => setForm({ ...form, first_name: e.target.value })} required />
                    <input className="rounded border px-3 py-2" placeholder="Last name" value={form.last_name} onChange={(e) => setForm({ ...form, last_name: e.target.value })} required />
                    <select className="rounded border px-3 py-2" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
                        <option value="">Select category</option>
                        {(meta.categories || []).map((c) => <option key={c.id} value={c.id}>{c.title || c.name}</option>)}
                    </select>
                    <select className="rounded border px-3 py-2" value={form.class} onChange={(e) => setForm({ ...form, class: e.target.value })}>
                        <option value="">Select class</option>
                        {(meta.classes || []).map((c) => <option key={c.id} value={c.id}>{c.name || c.title}</option>)}
                    </select>
                    <button className="rounded bg-blue-600 px-3 py-2 text-white">Create</button>
                </form>
            </div>
        </AdminLayout>
    );
}

export function StudentShowPage() {
    const { id } = useParams();
    const [data, setData] = useState(null);
    useEffect(() => { axios.get(`/student/show/${id}`, { headers: xhrJson }).then((r) => setData(r.data?.data || null)); }, [id]);
    return (
        <AdminLayout>
            <div className="mx-auto max-w-5xl p-6">
                <h1 className="text-2xl font-bold">Student Details</h1>
                <pre className="mt-4 overflow-auto rounded bg-white p-4 text-xs">{JSON.stringify(data, null, 2)}</pre>
                <div className="mt-3"><Link to={`/students/${id}/edit`} className="text-blue-700">Edit</Link></div>
            </div>
        </AdminLayout>
    );
}

export function StudentEditPage() {
    const { id } = useParams();
    const nav = useNavigate();
    const [form, setForm] = useState({});
    const [meta, setMeta] = useState({});
    const [err, setErr] = useState('');
    useEffect(() => {
        axios.get(`/student/edit/${id}`, { headers: xhrJson })
            .then((r) => {
                setForm(r.data?.data || {});
                setMeta(r.data?.meta || {});
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));
    }, [id]);
    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        try {
            await axios.put('/student/update', { ...form, id }, { headers: xhrJson });
            nav('/students');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Update failed.');
        }
    };
    return (
        <AdminLayout>
            <div className="mx-auto max-w-3xl p-6">
                <h1 className="text-2xl font-bold">{meta.title || 'Edit student'}</h1>
                {err ? <p className="mt-2 text-sm text-red-600">{err}</p> : null}
                <form onSubmit={submit} className="mt-4 grid gap-3 rounded border bg-white p-4">
                    <input className="rounded border px-3 py-2" value={form.first_name || ''} onChange={(e) => setForm({ ...form, first_name: e.target.value })} />
                    <input className="rounded border px-3 py-2" value={form.last_name || ''} onChange={(e) => setForm({ ...form, last_name: e.target.value })} />
                    <button className="rounded bg-blue-600 px-3 py-2 text-white">Save</button>
                </form>
            </div>
        </AdminLayout>
    );
}

export function StudentCategoriesPage() {
    const [rows, setRows] = useState([]);
    const [form, setForm] = useState({ title: '' });
    const load = () => axios.get('/student/category', { headers: xhrJson }).then((r) => setRows(r.data?.data?.data || r.data?.data || []));
    useEffect(() => { load(); }, []);
    return (
        <AdminLayout>
            <div className="mx-auto max-w-5xl p-6">
                <h1 className="text-2xl font-bold">Student Categories</h1>
                <form className="my-3 flex gap-2" onSubmit={async (e) => { e.preventDefault(); await axios.post('/student/category/store', form, { headers: xhrJson }); setForm({ title: '' }); load(); }}>
                    <input className="rounded border px-3 py-2" placeholder="Category title" value={form.title} onChange={(e) => setForm({ title: e.target.value })} />
                    <button className="rounded bg-blue-600 px-3 py-2 text-white">Add</button>
                </form>
                <ul className="rounded border bg-white p-3 text-sm">{rows.map((c) => <li key={c.id} className="border-b py-1">{c.title || c.name}</li>)}</ul>
            </div>
        </AdminLayout>
    );
}

export function ParentsPage() {
    const [rows, setRows] = useState([]);
    useEffect(() => {
        axios.get('/parent', { headers: xhrJson }).then((r) => setRows(r.data?.data?.data || r.data?.data || []));
    }, []);
    return (
        <AdminLayout>
            <div className="mx-auto max-w-6xl p-6">
                <div className="mb-4 flex items-center justify-between">
                    <h1 className="text-2xl font-bold">Parents</h1>
                    <Link to="/parents/create" className="rounded bg-blue-600 px-3 py-2 text-sm text-white">Create</Link>
                </div>
                <div className="rounded border bg-white p-3 text-sm">
                    {rows.map((p) => (
                        <div className="border-b py-2" key={p.id}>
                            <Link className="text-blue-700" to={`/parents/${p.id}/edit`}>{p.name || `${p.first_name || ''} ${p.last_name || ''}`}</Link>
                        </div>
                    ))}
                </div>
            </div>
        </AdminLayout>
    );
}

export function ParentFormPage({ edit = false }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [form, setForm] = useState({});
    const [err, setErr] = useState('');
    useEffect(() => {
        const url = edit ? `/parent/edit/${id}` : '/parent/create';
        axios.get(url, { headers: xhrJson }).then((r) => {
            if (edit) setForm(r.data?.data || {});
        }).catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));
    }, [edit, id]);
    const submit = async (e) => {
        e.preventDefault();
        try {
            if (edit) await axios.put(`/parent/update/${id}`, form, { headers: xhrJson });
            else await axios.post('/parent/store', form, { headers: xhrJson });
            nav('/parents');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Save failed.');
        }
    };
    return (
        <AdminLayout>
            <div className="mx-auto max-w-3xl p-6">
                <h1 className="text-2xl font-bold">{edit ? 'Edit parent' : 'Create parent'}</h1>
                {err ? <p className="mt-2 text-sm text-red-600">{err}</p> : null}
                <form onSubmit={submit} className="mt-4 grid gap-3 rounded border bg-white p-4">
                    <input className="rounded border px-3 py-2" placeholder="First name" value={form.first_name || ''} onChange={(e) => setForm({ ...form, first_name: e.target.value })} />
                    <input className="rounded border px-3 py-2" placeholder="Last name" value={form.last_name || ''} onChange={(e) => setForm({ ...form, last_name: e.target.value })} />
                    <input className="rounded border px-3 py-2" placeholder="Phone" value={form.phone || ''} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
                    <button className="rounded bg-blue-600 px-3 py-2 text-white">{edit ? 'Update' : 'Create'}</button>
                </form>
            </div>
        </AdminLayout>
    );
}

export function PromoteStudentsPage() {
    const [payload, setPayload] = useState(null);
    useEffect(() => {
        axios.get('/promote-students', { headers: xhrJson }).then((r) => setPayload(r.data || null));
    }, []);
    return (
        <AdminLayout>
            <div className="mx-auto max-w-6xl p-6">
                <h1 className="text-2xl font-bold">Promote Students</h1>
                <pre className="mt-4 overflow-auto rounded bg-white p-4 text-xs">{JSON.stringify(payload, null, 2)}</pre>
            </div>
        </AdminLayout>
    );
}

export function DisabledStudentsPage() {
    const [payload, setPayload] = useState(null);
    useEffect(() => {
        axios.get('/disabled-students', { headers: xhrJson }).then((r) => setPayload(r.data || null));
    }, []);
    return (
        <AdminLayout>
            <div className="mx-auto max-w-6xl p-6">
                <h1 className="text-2xl font-bold">Disabled Students</h1>
                <pre className="mt-4 overflow-auto rounded bg-white p-4 text-xs">{JSON.stringify(payload, null, 2)}</pre>
            </div>
        </AdminLayout>
    );
}
