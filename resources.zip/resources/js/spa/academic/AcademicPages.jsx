import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link, useNavigate, useParams } from 'react-router-dom';

const xhrJson = { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' };

function Panel({ Layout, title, children }) {
    return (
        <Layout>
            <div className="mx-auto max-w-6xl p-6">
                <h1 className="text-2xl font-bold">{title}</h1>
                <div className="mt-4">{children}</div>
            </div>
        </Layout>
    );
}

export function AcademicHomePage({ Layout }) {
    const links = [
        ['/academic/classes', 'Classes'],
        ['/academic/sections', 'Sections'],
        ['/academic/subjects', 'Subjects'],
        ['/academic/shifts', 'Shifts'],
        ['/academic/class-rooms', 'Class Rooms'],
        ['/academic/class-setups', 'Class Setups'],
        ['/academic/subject-assigns', 'Subject Assigns'],
        ['/academic/time-schedules', 'Time Schedules'],
        ['/academic/class-routines', 'Class Routines'],
        ['/academic/exam-routines', 'Exam Routines'],
    ];
    return (
        <Panel Layout={Layout} title="Academic">
            <div className="grid grid-cols-1 gap-2 text-sm md:grid-cols-2">
                {links.map(([to, label]) => <Link key={to} className="rounded border bg-white p-3" to={to}>{label}</Link>)}
            </div>
        </Panel>
    );
}

export function AcademicListPage({ Layout, title, endpoint, createTo, editBase }) {
    const [rows, setRows] = useState([]);
    const [err, setErr] = useState('');
    useEffect(() => {
        axios.get(endpoint, { headers: xhrJson })
            .then((r) => setRows(r.data?.data?.data || r.data?.data || []))
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load data.'));
    }, [endpoint]);
    return (
        <Panel Layout={Layout} title={title}>
            <div className="mb-4">
                <Link to={createTo} className="rounded bg-blue-600 px-3 py-2 text-sm text-white">Create</Link>
            </div>
            {err ? <p className="mb-2 text-sm text-red-600">{err}</p> : null}
            <div className="rounded border bg-white p-3 text-sm">
                {rows.map((row) => (
                    <div key={row.id} className="border-b py-2">
                        <Link className="text-blue-700" to={`${editBase}/${row.id}/edit`}>{row.name || row.title || `#${row.id}`}</Link>
                    </div>
                ))}
            </div>
        </Panel>
    );
}

export function AcademicFormPage({ Layout, titleCreate, titleEdit, loadEndpoint, storeEndpoint, updateEndpoint, backTo }) {
    const { id } = useParams();
    const edit = Boolean(id);
    const nav = useNavigate();
    const [form, setForm] = useState({ name: '', title: '', code: '' });
    const [err, setErr] = useState('');

    useEffect(() => {
        const url = edit ? `${loadEndpoint}/edit/${id}` : `${loadEndpoint}/create`;
        axios.get(url, { headers: xhrJson })
            .then((r) => { if (edit) setForm(r.data?.data || {}); })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load form.'));
    }, [edit, id, loadEndpoint]);

    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        try {
            if (edit) await axios.put(`${updateEndpoint}/${id}`, form, { headers: xhrJson });
            else await axios.post(`${storeEndpoint}`, form, { headers: xhrJson });
            nav(backTo);
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Save failed.');
        }
    };

    return (
        <Panel Layout={Layout} title={edit ? titleEdit : titleCreate}>
            {err ? <p className="mb-2 text-sm text-red-600">{err}</p> : null}
            <form onSubmit={submit} className="grid gap-3 rounded border bg-white p-4">
                <input className="rounded border px-3 py-2" placeholder="Name" value={form.name || form.title || ''} onChange={(e) => setForm({ ...form, name: e.target.value, title: e.target.value })} />
                <input className="rounded border px-3 py-2" placeholder="Code" value={form.code || ''} onChange={(e) => setForm({ ...form, code: e.target.value })} />
                <button className="rounded bg-blue-600 px-3 py-2 text-white">{edit ? 'Update' : 'Create'}</button>
            </form>
        </Panel>
    );
}
