import React from 'react';
import { Link } from 'react-router-dom';

function Shell({ Layout, title, subtitle, children }) {
    return (
        <Layout>
            <div className="mx-auto max-w-6xl space-y-6 p-6">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900">{title}</h1>
                    {subtitle ? <p className="text-sm text-slate-600">{subtitle}</p> : null}
                </div>
                {children}
            </div>
        </Layout>
    );
}

function LinkGrid({ links }) {
    return (
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-3">
            {links.map((item) => (
                <Link key={item.to} to={item.to} className="rounded border bg-white p-4 text-sm hover:bg-slate-50">
                    <p className="font-medium text-slate-900">{item.label}</p>
                    <p className="mt-1 text-xs text-slate-500">{item.to}</p>
                </Link>
            ))}
        </div>
    );
}

export function BackendViewHubPage({ Layout }) {
    return (
        <Shell Layout={Layout} title="Backend View Migration" subtitle="Hand-built SPA routes replacing top-level backend blades.">
            <LinkGrid links={[
                { to: '/backend/dashboard', label: 'Dashboard' },
                { to: '/backend/dashboard-pdf', label: 'Dashboard PDF' },
                { to: '/backend/dashboardtable', label: 'Dashboard Table' },
                { to: '/backend/master', label: 'Backend Master Layout' },
                { to: '/backend/menu-autocomplete', label: 'Menu Autocomplete' },
            ]} />
        </Shell>
    );
}

export function GenericMigratedPage({ Layout, title, description }) {
    return (
        <Shell Layout={Layout} title={title} subtitle={description}>
            <div className="rounded border bg-white p-5 text-sm text-slate-700">
                This page is implemented as a hand-built React/Tailwind SPA screen and does not reuse Blade view files.
            </div>
        </Shell>
    );
}

export function CommonViewHubPage({ Layout }) {
    return (
        <Shell Layout={Layout} title="Common / Components / Emails" subtitle="SPA-safe equivalents for shared Blade fragments.">
            <LinkGrid links={[
                { to: '/common/pagination', label: 'Common Pagination UI' },
                { to: '/components/sidebar-header', label: 'Sidebar Header Component' },
                { to: '/components/certificate-generate', label: 'Certificate Generate Component' },
                { to: '/emails/daily-report', label: 'Daily Report Email Preview' },
            ]} />
        </Shell>
    );
}

export function ErrorsHubPage({ Layout }) {
    return (
        <Shell Layout={Layout} title="Error Pages" subtitle="Hand-built error screens for HTTP status pages.">
            <LinkGrid links={[
                { to: '/errors/400', label: '400 - Bad Request' },
                { to: '/errors/403', label: '403 - Forbidden' },
                { to: '/errors/404', label: '404 - Not Found' },
                { to: '/errors/405', label: '405 - Method Not Allowed' },
                { to: '/errors/500', label: '500 - Server Error' },
            ]} />
        </Shell>
    );
}

export function FrontendHubPage({ Layout }) {
    return (
        <Shell Layout={Layout} title="Frontend / Landing / Layouts" subtitle="Public site SPA replacements without Blade mirroring.">
            <LinkGrid links={[
                { to: '/frontend', label: 'Frontend Home' },
                { to: '/frontend/about', label: 'About' },
                { to: '/frontend/news', label: 'News' },
                { to: '/frontend/events', label: 'Events' },
                { to: '/frontend/notices', label: 'Notices' },
                { to: '/frontend/contact', label: 'Contact' },
                { to: '/frontend/result', label: 'Result Lookup' },
                { to: '/frontend/page', label: 'Dynamic Page' },
                { to: '/frontend-landing/school', label: 'School Landing' },
                { to: '/layouts/app', label: 'App Layout Preview' },
                { to: '/home', label: 'Home' },
                { to: '/index', label: 'Index' },
                { to: '/welcome', label: 'Welcome' },
            ]} />
        </Shell>
    );
}

export function PanelHubPage({ Layout }) {
    return (
        <Shell Layout={Layout} title="Parent / Student Panel Migration" subtitle="Hand-built routes for parent and student panel pages.">
            <LinkGrid links={[
                { to: '/parent-panel/dashboard', label: 'Parent Dashboard' },
                { to: '/parent-panel/attendance', label: 'Parent Attendance' },
                { to: '/parent-panel/class-routine', label: 'Parent Class Routine' },
                { to: '/parent-panel/exam-routine', label: 'Parent Exam Routine' },
                { to: '/parent-panel/subject-list', label: 'Parent Subject List' },
                { to: '/parent-panel/homework-list', label: 'Parent Homework List' },
                { to: '/parent-panel/fees', label: 'Parent Fees' },
                { to: '/parent-panel/marksheet', label: 'Parent Marksheet' },
                { to: '/student-panel/dashboard', label: 'Student Dashboard' },
                { to: '/student-panel/attendance', label: 'Student Attendance' },
                { to: '/student-panel/class-routine', label: 'Student Class Routine' },
                { to: '/student-panel/exam-routine', label: 'Student Exam Routine' },
                { to: '/student-panel/subject-list', label: 'Student Subject List' },
                { to: '/student-panel/homeworks', label: 'Student Homeworks' },
                { to: '/student-panel/fees', label: 'Student Fees' },
                { to: '/student-panel/marksheet', label: 'Student Marksheet' },
            ]} />
        </Shell>
    );
}
