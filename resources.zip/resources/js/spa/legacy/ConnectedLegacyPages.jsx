import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

const xhrJson = { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' };

export function EndpointDataPage({ Layout, title, endpoint }) {
    const [payload, setPayload] = useState(null);
    const [err, setErr] = useState('');

    useEffect(() => {
        axios.get(endpoint, { headers: xhrJson })
            .then((r) => setPayload(r.data))
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load data.'));
    }, [endpoint]);

    return (
        <Layout>
            <div className="mx-auto max-w-6xl p-6">
                <h1 className="text-2xl font-bold">{title}</h1>
                {err ? <p className="mt-2 text-sm text-red-600">{err}</p> : null}
                <pre className="mt-4 overflow-auto rounded border bg-white p-4 text-xs">{JSON.stringify(payload, null, 2)}</pre>
            </div>
        </Layout>
    );
}

export function EndpointParamPage({ Layout, title, endpointTemplate }) {
    const params = useParams();
    const endpoint = Object.keys(params).reduce(
        (acc, key) => acc.replace(`:${key}`, params[key]),
        endpointTemplate
    );
    return <EndpointDataPage Layout={Layout} title={title} endpoint={endpoint} />;
}
