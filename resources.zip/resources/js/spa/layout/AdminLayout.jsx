import React, { useEffect, useMemo, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import axios from 'axios';

const cn = (...parts) => parts.filter(Boolean).join(' ');

function Icon({ name, className = 'h-5 w-5 shrink-0' }) {
    const common = { className: cn('text-gray-500 group-hover:text-blue-600', className), fill: 'none', viewBox: '0 0 24 24', strokeWidth: 1.5, stroke: 'currentColor' };
    switch (name) {
        case 'home':
            return (
                <svg xmlns="http://www.w3.org/2000/svg" {...common} aria-hidden="true">
                    <path strokeLinecap="round" strokeLinejoin="round" d="m2.25 12 8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25" />
                </svg>
            );
        case 'chart':
            return (
                <svg xmlns="http://www.w3.org/2000/svg" {...common} aria-hidden="true">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 013 19.875v-6.75zM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V8.625zM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V4.125z" />
                </svg>
            );
        case 'users':
            return (
                <svg xmlns="http://www.w3.org/2000/svg" {...common} aria-hidden="true">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M15 19.128a9.38 9.38 0 002.625.372 9.337 9.337 0 004.121-.952 4.125 4.125 0 00-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 018.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0111.964-3.07M12 6.375a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zm8.25 2.25a2.625 2.625 0 11-5.25 0 2.625 2.625 0 015.25 0z" />
                </svg>
            );
        case 'academic':
            return (
                <svg xmlns="http://www.w3.org/2000/svg" {...common} aria-hidden="true">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M4.26 10.147a60.438 60.438 0 00-.491 6.347A48.62 48.62 0 0112 20.904a48.62 48.62 0 018.232-4.41 60.46 60.46 0 00-.491-6.347m-15.482 0a50.636 50.636 0 00-2.658-.813A59.906 59.906 0 0112 3.493a59.903 59.903 0 0110.399 5.84c-.896.248-1.783.52-2.658.814m-15.482 0A50.717 50.717 0 0112 13.489a50.702 50.702 0 017.74-3.342M6.75 15a.75.75 0 100-1.5.75.75 0 000 1.5zm6 0a.75.75 0 100-1.5.75.75 0 000 1.5zm6 0a.75.75 0 100-1.5.75.75 0 000 1.5z" />
                </svg>
            );
        case 'money':
            return (
                <svg xmlns="http://www.w3.org/2000/svg" {...common} aria-hidden="true">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 18.75a60.07 60.07 0 0115.797 2.165c1.11.33 2.25-.036 2.973-1.022a60.858 60.858 0 014.92-4.92 1.11 1.11 0 00-.655-2.022 59.472 59.472 0 01-6.09-1.282 60.15 60.15 0 00-1.92-.234 59.64 59.64 0 00-6.335 0 60.05 60.05 0 00-1.92.234 59.472 59.472 0 01-6.09 1.282 1.11 1.11 0 00-.655 2.022 60.858 60.858 0 004.92 4.92 1.11 1.11 0 002.973 1.022 60.07 60.07 0 0115.797 2.165v-9.75a60.05 60.05 0 00-1.92-.234 59.64 59.64 0 00-6.335 0 60.15 60.15 0 00-1.92.234 59.472 59.472 0 01-6.09 1.282 1.11 1.11 0 00-.655 2.022 60.858 60.858 0 004.92 4.92 1.11 1.11 0 002.973 1.022 60.07 60.07 0 0115.797 2.165V9.75" />
                </svg>
            );
        case 'wallet':
            return (
                <svg xmlns="http://www.w3.org/2000/svg" {...common} aria-hidden="true">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M21 12a2.25 2.25 0 00-2.25-2.25H15a3 3 0 11-6 0H5.25A2.25 2.25 0 003 12m18 0v6a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 18v-6m18 0V9M3 12V9m18 0v3a2.25 2.25 0 01-2.25 2.25H15a3 3 0 01-6 0H5.25A2.25 2.25 0 013 12v-3" />
                </svg>
            );
        case 'book':
            return (
                <svg xmlns="http://www.w3.org/2000/svg" {...common} aria-hidden="true">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" />
                </svg>
            );
        case 'mail':
            return (
                <svg xmlns="http://www.w3.org/2000/svg" {...common} aria-hidden="true">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75" />
                </svg>
            );
        case 'cog':
            return (
                <svg xmlns="http://www.w3.org/2000/svg" {...common} aria-hidden="true">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9.594 3.94c.09-.542.56-.94 1.11-.94h2.593c.55 0 1.02.398 1.11.94l.213 1.281c.063.374.313.686.645.87.074.04.147.083.22.127.324.196.72.257 1.075.124l1.217-.456a1.125 1.125 0 011.37.49l1.296 2.247a1.125 1.125 0 01-.26 1.431l-1.003.827c-.293.24-.438.613-.431.992a6.723 6.723 0 010 .255c-.007.378.138.75.43.99l1.005.828c.424.35.534.954.26 1.43l-1.298 2.247a1.125 1.125 0 01-1.369.491l-1.217-.456c-.355-.133-.75-.072-1.076.124a6.57 6.57 0 01-.22.128c-.331.183-.581.495-.644.869l-.213 1.28c-.09.543-.56.941-1.11.941h-2.594c-.55 0-1.02-.398-1.11-.94l-.213-1.281c-.062-.374-.312-.686-.644-.87a6.52 6.52 0 01-.22-.127c-.325-.196-.72-.257-1.076-.124l-1.217.456a1.125 1.125 0 01-1.369-.49l-1.297-2.247a1.125 1.125 0 01.26-1.431l1.004-.827c.292-.24.437-.613.43-.992a6.932 6.932 0 010-.255c.007-.378-.138-.75-.43-.99l-1.004-.828a1.125 1.125 0 01-.26-1.43l1.297-2.247a1.125 1.125 0 011.37-.491l1.216.456c.356.133.751.072 1.076-.124.072-.044.146-.087.22-.128.332-.183.582-.495.644-.869l.214-1.281z" />
                    <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
            );
        case 'bars':
            return (
                <svg xmlns="http://www.w3.org/2000/svg" {...common} className={cn(className, 'h-6 w-6')} aria-hidden="true">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
                </svg>
            );
        case 'user-circle':
            return (
                <svg xmlns="http://www.w3.org/2000/svg" {...common} className={cn('text-gray-500', className)} aria-hidden="true">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M17.982 18.725A7.488 7.488 0 0012 15.75a7.488 7.488 0 00-5.982 2.975m11.963 0a9 9 0 10-11.963 0m11.963 0A8.966 8.966 0 0112 21a8.966 8.966 0 01-5.982-2.275M15 9.75a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
            );
        case 'chevron-down':
            return (
                <svg xmlns="http://www.w3.org/2000/svg" {...common} className={cn('h-4 w-4 text-gray-400 transition-transform', className)} aria-hidden="true">
                    <path strokeLinecap="round" strokeLinejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5" />
                </svg>
            );
        case 'document':
            return (
                <svg xmlns="http://www.w3.org/2000/svg" {...common} aria-hidden="true">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
                </svg>
            );
        default:
            return null;
    }
}

/** Match paths for sidebar active + open groups. Supports SPA `to` or Laravel `href`. */
function itemMatchPath(item) {
    if (item.to) return item.to;
    if (item.href) {
        const h = item.href.trim();
        if (h.startsWith('http://') || h.startsWith('https://')) {
            try {
                return new URL(h).pathname.replace(/\/$/, '') || '/';
            } catch {
                return h;
            }
        }
        return h.split('?')[0].replace(/\/$/, '') || '/';
    }
    return '';
}

function pathMatches(pathname, itemOrPath) {
    const to = typeof itemOrPath === 'string' ? itemOrPath : itemMatchPath(itemOrPath);
    if (!to) return false;
    if (to === '/dashboard') return pathname === '/dashboard';
    return pathname === to || pathname.startsWith(`${to}/`);
}

/**
 * Mirrors resources/views/backend/partials/sidebar.blade.php (order, labels, routes).
 * `to` = React Router; `href` = full Laravel URL when no SPA screen exists.
 */
const menuGroups = [
    {
        id: 'student',
        label: 'Student Info',
        icon: 'users',
        links: [
            { label: 'Students', to: '/students' },
            { label: 'Student Category', to: '/students/categories' },
            { label: 'Promote Students', to: '/students/promote' },
            { label: 'Guardian', to: '/parents' },
            { label: 'QR Code', to: '/students' },
            { label: 'Deleted student history', to: '/students/deleted-history' },
        ],
    },
    {
        id: 'academic',
        label: 'Academic',
        icon: 'academic',
        links: [
            { label: 'Class', to: '/academic/classes' },
            { label: 'Section', to: '/academic/sections' },
            { label: 'Class Setup', to: '/academic/class-setups' },
            { label: 'Subject', to: '/academic/subjects' },
            { label: 'Subject Assign', to: '/academic/subject-assigns' },
            { label: 'Time Schedule', to: '/academic/time-schedules' },
        ],
    },
    {
        id: 'fees',
        label: 'Fees',
        icon: 'money',
        links: [
            { label: 'Group', to: '/fees/groups' },
            { label: 'Type', to: '/fees/types' },
            { label: 'Master', to: '/fees/masters' },
            { label: 'Assign', to: '/fees/assignments' },
            { label: 'Collect', to: '/fees/collections' },
            { label: 'Transactions', to: '/fees/transactions' },
            { label: 'Online Transactions', to: '/fees/online-transactions' },
            { label: 'Amendments', to: '/fees/amendments' },
        ],
    },
    {
        id: 'accounts',
        label: 'Accounts',
        icon: 'wallet',
        links: [
            { label: 'Financial Dashboard', to: '/reports/accounting/dashboard' },
            { label: 'Chart of Accounts', to: '/accounts/chart-of-accounts' },
            { label: 'Payment Methods', to: '/accounts/payment-methods' },
            { label: 'Account Head', to: '/accounts/account-heads' },
            { label: 'Income', to: '/accounts/income' },
            { label: 'Expense', to: '/accounts/expense' },
            { label: 'Products', to: '/accounts/product' },
            { label: 'Items', to: '/accounts/item' },
            { label: 'Balance', to: '/accounts/balance' },
            { label: 'Bank Reconciliation', to: '/reports/accounting/bank-reconciliation' },
        ],
    },
    {
        id: 'report',
        label: 'Report',
        icon: 'document',
        links: [
            { label: 'Fees Collection', to: '/reports/fees-collection' },
            { label: 'Collection Summary', to: '/reports/fees-summary' },
            { label: 'Student List', to: '/reports/students' },
            { label: 'Fees Assignment By Year', to: '/reports/fees-by-year' },
            { label: 'Boarding Students Report', to: '/reports/boarding-students' },
            { label: 'Duplicate Students', to: '/reports/duplicate-students' },
            { label: 'Marksheet', to: '/reports/marksheet' },
            { label: 'Merit List', to: '/reports/merit-list' },
            { label: 'Accounts', to: '/reports/account' },
        ],
    },
    {
        id: 'communication',
        label: 'Communication',
        icon: 'mail',
        links: [
            { label: 'Notice Board', to: '/communication/notice-board' },
            { label: 'SMS / Mail', to: '/communication/smsmail' },
            { label: 'SMS Campaign', to: '/communication/smsmail/campaign' },
            { label: 'SMS/Mail Template', to: '/communication/template' },
        ],
    },
    {
        id: 'staff',
        label: 'Staff Manage',
        icon: 'users',
        links: [
            { label: 'Roles', to: '/roles' },
            { label: 'Staff', to: '/users' },
            { label: 'Department', to: '/staff/department' },
            { label: 'Batch Processing', to: '/staff/batch-processing' },
            { label: 'Designation', to: '/staff/designation' },
        ],
    },
    {
        id: 'settings',
        label: 'Settings',
        icon: 'cog',
        links: [
            { label: 'General Settings', to: '/settings/general' },
            { label: 'Notification Setting', to: '/settings/notification' },
            { label: 'Storage Settings', to: '/settings/storage' },
            { label: 'Task Schedules', to: '/settings/task-schedulers' },
            { label: 'Software Update', to: '/settings/software-update' },
            { label: 'Recaptcha Settings', to: '/settings/recaptcha' },
            { label: 'SMS Settings', to: '/settings/sms' },
            { label: 'Payment Gateway Settings', to: '/settings/payment-gateway' },
            { label: 'Email Settings', to: '/settings/email' },
            { label: 'Genders', to: '/settings/genders' },
            { label: 'Bank Accounts', to: '/banks-accounts' },
            { label: 'Religions', to: '/settings/religions' },
            { label: 'Blood Groups', to: '/blood-groups' },
            { label: 'Sessions', to: '/settings/sessions' },
        ],
    },
];

const linkClass = ({ isActive }) =>
    cn(
        'sidebar-link group flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition',
        isActive ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-50',
    );

const subLinkClass = ({ isActive }) =>
    cn(
        'sidebar-link flex items-center gap-2 rounded-lg py-2 pl-9 pr-3 text-sm transition',
        isActive ? 'bg-blue-50/80 font-medium text-blue-700' : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900',
    );

export function AdminLayout({ children }) {
    const loc = useLocation();
    const [sidebarOpen, setSidebarOpen] = useState(() => (typeof window !== 'undefined' ? window.innerWidth >= 1024 : true));
    const [userMenuOpen, setUserMenuOpen] = useState(false);
    const [openGroups, setOpenGroups] = useState(() => {
        const init = {};
        menuGroups.forEach((g, i) => {
            init[i] = g.links.some((item) => pathMatches(loc.pathname, item));
        });
        return init;
    });

    useEffect(() => {
        const next = {};
        menuGroups.forEach((g, i) => {
            next[i] = g.links.some((item) => pathMatches(loc.pathname, item));
        });
        setOpenGroups((prev) => {
            const merged = { ...prev };
            Object.keys(next).forEach((k) => {
                if (next[k]) merged[k] = true;
            });
            return merged;
        });
    }, [loc.pathname]);

    const pageTitle = useMemo(() => {
        if (loc.pathname === '/dashboard') return 'Dashboard';
        const parts = loc.pathname.split('/').filter(Boolean);
        const last = parts[parts.length - 1];
        if (!last) return 'Workspace';
        return last.replace(/-/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
    }, [loc.pathname]);

    const toggleGroup = (i) => {
        setOpenGroups((prev) => ({ ...prev, [i]: !prev[i] }));
    };

    return (
        <div className="flex min-h-screen flex-col overflow-hidden bg-gray-100 font-sans text-gray-700 antialiased">
            <div
                className="flex h-full min-h-0 flex-1 overflow-hidden"
                onKeyDown={(e) => {
                    if (e.key === 'Escape') setUserMenuOpen(false);
                }}
                role="presentation"
            >
                {sidebarOpen ? (
                    <button
                        type="button"
                        className="fixed inset-0 z-40 bg-gray-900/40 backdrop-blur-sm lg:hidden"
                        aria-label="Close menu"
                        onClick={() => setSidebarOpen(false)}
                    />
                ) : null}

                <aside
                    className={cn(
                        'fixed inset-y-0 left-0 z-50 flex h-full min-h-0 w-64 flex-col border-r border-gray-200 bg-white shadow-sm transition-transform duration-200 ease-out lg:static lg:translate-x-0',
                        sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0',
                    )}
                >
                    <div className="flex h-16 shrink-0 items-center gap-3 border-b border-gray-200 px-4">
                        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-blue-600 text-white shadow-sm">
                            <Icon name="chart" className="h-5 w-5 text-white group-hover:text-white" />
                        </span>
                        <span className="truncate bg-gradient-to-r from-blue-700 to-blue-600 bg-clip-text text-lg font-bold text-transparent">School Admin</span>
                    </div>

                    <nav className="flex-1 overflow-y-auto py-4">
                        <ul className="space-y-0.5 px-2">
                            <li>
                                <NavLink to="/dashboard" className={linkClass} end>
                                    <Icon name="home" />
                                    Dashboard
                                </NavLink>
                            </li>
                        </ul>

                        <div className="mt-3 px-2">
                            <p className="px-2 pb-2 text-[11px] font-semibold uppercase tracking-wide text-gray-400">Modules</p>
                        </div>

                        <ul className="space-y-1 px-2">
                            {menuGroups.map((group, i) => {
                                const expanded = !!openGroups[i];
                                const groupActive = group.links.some((item) => pathMatches(loc.pathname, item));
                                return (
                                    <li key={group.id} className="rounded-lg border border-transparent">
                                        <button
                                            type="button"
                                            onClick={() => toggleGroup(i)}
                                            className={cn(
                                                'flex w-full items-center justify-between gap-2 rounded-lg px-3 py-2.5 text-left text-sm font-medium transition',
                                                groupActive ? 'bg-blue-50/50 text-blue-800' : 'text-gray-800 hover:bg-gray-50',
                                            )}
                                        >
                                            <span className="flex min-w-0 items-center gap-3">
                                                <span className="group flex shrink-0">
                                                    <Icon name={group.icon} className={cn(groupActive ? 'text-blue-600' : '')} />
                                                </span>
                                                <span className="truncate">{group.label}</span>
                                            </span>
                                            <Icon name="chevron-down" className={cn(expanded ? 'rotate-180' : '')} />
                                        </button>
                                        {expanded ? (
                                            <ul className="mt-0.5 space-y-0.5 border-l border-gray-100 pb-1 pl-2 ml-3">
                                                {group.links.map((item) => {
                                                    const pathKey = item.to || item.href;
                                                    const isActive = pathMatches(loc.pathname, item);
                                                    const closeMobile = () => {
                                                        if (typeof window !== 'undefined' && window.innerWidth < 1024) {
                                                            setSidebarOpen(false);
                                                        }
                                                    };
                                                    return (
                                                        <li key={`${group.id}-${item.label}-${pathKey}`}>
                                                            {item.to ? (
                                                                <NavLink to={item.to} className={subLinkClass} onClick={closeMobile}>
                                                                    <span className="inline-block h-1.5 w-1.5 shrink-0 rounded-full bg-gray-300" />
                                                                    {item.label}
                                                                </NavLink>
                                                            ) : (
                                                                <a href={item.href} className={subLinkClass({ isActive })} onClick={closeMobile}>
                                                                    <span className="inline-block h-1.5 w-1.5 shrink-0 rounded-full bg-gray-300" />
                                                                    {item.label}
                                                                </a>
                                                            )}
                                                        </li>
                                                    );
                                                })}
                                            </ul>
                                        ) : null}
                                    </li>
                                );
                            })}
                        </ul>

                        <div className="mt-4 px-2">
                            <button
                                type="button"
                                className="sidebar-link flex w-full items-center gap-2 rounded-lg px-3 py-2.5 text-left text-sm font-medium text-red-600 transition hover:bg-red-50"
                                onClick={() => {
                                    axios.post('/logout').then(() => {
                                        window.location.href = '/login';
                                    });
                                }}
                            >
                                Log out
                            </button>
                        </div>
                    </nav>
                </aside>

                <div className="flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden">
                    <header className="z-30 flex h-16 shrink-0 items-center justify-between gap-4 border-b border-gray-200 bg-white px-4 shadow-sm">
                        <div className="flex min-w-0 items-center gap-3">
                            <button
                                type="button"
                                className="inline-flex h-9 w-9 items-center justify-center rounded-lg text-gray-500 transition hover:bg-gray-100 hover:text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500 lg:hidden"
                                onClick={() => setSidebarOpen((s) => !s)}
                                aria-label="Toggle sidebar"
                            >
                                <Icon name="bars" />
                            </button>
                            <h1 className="truncate text-lg font-semibold text-gray-800">{pageTitle}</h1>
                        </div>

                        <div className="relative">
                            <button
                                type="button"
                                className="flex items-center gap-2 rounded-lg border border-gray-200 bg-white px-3 py-2 text-sm font-medium text-gray-700 shadow-sm transition hover:bg-gray-50"
                                onClick={() => setUserMenuOpen((v) => !v)}
                            >
                                <Icon name="user-circle" className="h-8 w-8" />
                                <span className="hidden sm:inline">Account</span>
                                <Icon name="chevron-down" />
                            </button>
                            {userMenuOpen ? (
                                <>
                                    <button type="button" className="fixed inset-0 z-40 cursor-default" aria-label="Close" onClick={() => setUserMenuOpen(false)} />
                                    <div className="absolute right-0 z-50 mt-2 w-52 rounded-xl border border-gray-200 bg-white py-1 shadow-lg ring-1 ring-black/5">
                                        <a href="/my/profile" className="flex items-center gap-2 px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50">
                                            <Icon name="user-circle" className="h-4 w-4" />
                                            Profile
                                        </a>
                                        <form
                                            method="post"
                                            action="/logout"
                                            className="border-t border-gray-100"
                                            onSubmit={(e) => {
                                                e.preventDefault();
                                                axios.post('/logout').then(() => {
                                                    window.location.href = '/login';
                                                });
                                            }}
                                        >
                                            <button type="submit" className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-sm text-red-600 hover:bg-red-50">
                                                Log out
                                            </button>
                                        </form>
                                    </div>
                                </>
                            ) : null}
                        </div>
                    </header>

                    <main className="min-h-0 flex-1 overflow-y-auto p-4 sm:p-6">{children}</main>
                </div>
            </div>

        </div>
    );
}
