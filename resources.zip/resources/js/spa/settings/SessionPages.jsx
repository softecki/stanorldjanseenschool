import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link, useNavigate, useParams } from 'react-router-dom';

const xhrJson = { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' };

function Shell({ Layout, children }) {
    return <Layout><div className="mx-auto max-w-5xl space-y-6 p-6">{children}</div></Layout>;
}

export function SessionsListPage({ Layout }) {
    const [rows, setRows] = useState([]);
    const [meta, setMeta] = useState({});

    const load = () => axios.get('/sessions', { headers: xhrJson }).then((r) => {
        setRows(r.data?.data?.data || r.data?.data || []);
        setMeta(r.data?.meta || {});
    });

    useEffect(() => { load(); }, []);

    const remove = async (id) => {
        if (!window.confirm('Delete this session?')) return;
        await axios.delete(`/sessions/delete/${id}`, { headers: xhrJson });
        load();
    };

    return (
        <Shell Layout={Layout}>
            <div className="flex items-center justify-between">
                <h1 className="text-2xl font-bold">{meta.title || 'Sessions'}</h1>
                <Link className="rounded bg-blue-600 px-3 py-2 text-sm text-white" to="/settings/sessions/create">Create</Link>
            </div>
            <div className="rounded border bg-white p-3 text-sm">
                {rows.map((row) => (
                    <div key={row.id} className="flex items-center justify-between border-b py-2">
                        <span>{row.title || row.name}</span>
                        <div className="space-x-3">
                            <Link className="text-blue-700" to={`/settings/sessions/${row.id}/edit`}>Edit</Link>
                            <Link className="text-slate-700" to={`/settings/sessions/${row.id}/translate`}>Translate</Link>
                            <button className="text-red-700" onClick={() => remove(row.id)}>Delete</button>
                        </div>
                    </div>
                ))}
                {!rows.length ? <p className="py-6 text-center text-slate-500">No sessions found.</p> : null}
            </div>
        </Shell>
    );
}

export function SessionsFormPage({ Layout, edit = false }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [form, setForm] = useState({ title: '', status: 1 });

    useEffect(() => {
        const url = edit ? `/sessions/edit/${id}` : '/sessions/create';
        axios.get(url, { headers: xhrJson }).then((r) => {
            const item = r.data?.data?.session || r.data?.data || {};
            if (edit) setForm({ title: item.title || item.name || '', status: item.status ? 1 : 0 });
        });
    }, [edit, id]);

    const submit = async (e) => {
        e.preventDefault();
        if (edit) await axios.put(`/sessions/update/${id}`, form, { headers: xhrJson });
        else await axios.post('/sessions/store', form, { headers: xhrJson });
        nav('/settings/sessions');
    };

    return (
        <Shell Layout={Layout}>
            <h1 className="text-2xl font-bold">{edit ? 'Edit session' : 'Create session'}</h1>
            <form onSubmit={submit} className="grid max-w-xl gap-3 rounded border bg-white p-4">
                <input className="rounded border px-3 py-2" placeholder="Title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required />
                <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={!!form.status} onChange={(e) => setForm({ ...form, status: e.target.checked ? 1 : 0 })} /> Active</label>
                <button className="rounded bg-blue-600 px-3 py-2 text-white">{edit ? 'Update' : 'Create'}</button>
            </form>
        </Shell>
    );
}

export function SessionsTranslatePage({ Layout }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [languages, setLanguages] = useState([]);
    const [titles, setTitles] = useState({});

    useEffect(() => {
        axios.get(`/sessions/translate/${id}`, { headers: xhrJson }).then((r) => {
            const data = r.data?.data || {};
            const langs = data.languages || [];
            const trans = data.translates || {};
            const base = data.session || {};
            setLanguages(langs);
            const n = {};
            langs.forEach((l) => {
                const code = l.code || String(l.id);
                n[code] = trans[code]?.[0]?.title || base.title || '';
            });
            setTitles(n);
        });
    }, [id]);

    const submit = async (e) => {
        e.preventDefault();
        await axios.post(`/sessions/translateUpdate/${id}`, { title: titles }, { headers: xhrJson });
        nav('/settings/sessions');
    };

    return (
        <Shell Layout={Layout}>
            <h1 className="text-2xl font-bold">Translate session</h1>
            <form onSubmit={submit} className="grid max-w-xl gap-3 rounded border bg-white p-4">
                {languages.map((l) => {
                    const code = l.code || String(l.id);
                    return <input key={code} className="rounded border px-3 py-2" placeholder={`Title (${code})`} value={titles[code] || ''} onChange={(e) => setTitles({ ...titles, [code]: e.target.value })} />;
                })}
                <button className="rounded bg-blue-600 px-3 py-2 text-white">Save translations</button>
            </form>
        </Shell>
    );
}
