import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link, useNavigate, useParams } from 'react-router-dom';

const xhrJson = { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' };

function Shell({ Layout, children }) {
    return <Layout><div className="mx-auto max-w-5xl space-y-6 p-6">{children}</div></Layout>;
}

export function ReligionsListPage({ Layout }) {
    const [rows, setRows] = useState([]);
    const [meta, setMeta] = useState({});
    const [err, setErr] = useState('');

    const load = () => axios.get('/religions', { headers: xhrJson }).then((r) => {
        setRows(r.data?.data?.data || r.data?.data || []);
        setMeta(r.data?.meta || {});
    }).catch((ex) => setErr(ex.response?.data?.message || 'Failed to load religions.'));

    useEffect(() => { load(); }, []);

    const remove = async (id) => {
        if (!window.confirm('Delete this religion?')) return;
        await axios.delete(`/religions/delete/${id}`, { headers: xhrJson });
        load();
    };

    return (
        <Shell Layout={Layout}>
            <div className="flex items-center justify-between">
                <h1 className="text-2xl font-bold">{meta.title || 'Religions'}</h1>
                <Link className="rounded bg-blue-600 px-3 py-2 text-sm text-white" to="/settings/religions/create">Create</Link>
            </div>
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <div className="rounded border bg-white p-3 text-sm">
                {rows.map((row) => (
                    <div key={row.id} className="flex items-center justify-between border-b py-2">
                        <span>{row.name}</span>
                        <div className="space-x-3">
                            <Link className="text-blue-700" to={`/settings/religions/${row.id}/edit`}>Edit</Link>
                            <Link className="text-slate-700" to={`/settings/religions/${row.id}/translate`}>Translate</Link>
                            <button className="text-red-700" onClick={() => remove(row.id)}>Delete</button>
                        </div>
                    </div>
                ))}
                {!rows.length ? <p className="py-6 text-center text-slate-500">No religions found.</p> : null}
            </div>
        </Shell>
    );
}

export function ReligionsFormPage({ Layout, edit = false }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [form, setForm] = useState({ name: '', status: 1 });
    const [err, setErr] = useState('');

    useEffect(() => {
        const url = edit ? `/religions/edit/${id}` : '/religions/create';
        axios.get(url, { headers: xhrJson }).then((r) => {
            const rel = r.data?.data?.religion || r.data?.data || {};
            if (edit) setForm({ name: rel.name || '', status: rel.status ? 1 : 0 });
        }).catch((ex) => setErr(ex.response?.data?.message || 'Failed to load form.'));
    }, [edit, id]);

    const submit = async (e) => {
        e.preventDefault();
        if (edit) await axios.put(`/religions/update/${id}`, form, { headers: xhrJson });
        else await axios.post('/religions/store', form, { headers: xhrJson });
        nav('/settings/religions');
    };

    return (
        <Shell Layout={Layout}>
            <h1 className="text-2xl font-bold">{edit ? 'Edit religion' : 'Create religion'}</h1>
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <form onSubmit={submit} className="grid max-w-xl gap-3 rounded border bg-white p-4">
                <input className="rounded border px-3 py-2" placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
                <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={!!form.status} onChange={(e) => setForm({ ...form, status: e.target.checked ? 1 : 0 })} /> Active</label>
                <button className="rounded bg-blue-600 px-3 py-2 text-white">{edit ? 'Update' : 'Create'}</button>
            </form>
        </Shell>
    );
}

export function ReligionsTranslatePage({ Layout }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [languages, setLanguages] = useState([]);
    const [names, setNames] = useState({});

    useEffect(() => {
        axios.get(`/religions/translate/${id}`, { headers: xhrJson }).then((r) => {
            const data = r.data?.data || {};
            const langs = data.languages || [];
            const trans = data.translates || {};
            const base = data.religion || {};
            setLanguages(langs);
            const n = {};
            langs.forEach((l) => {
                const code = l.code || String(l.id);
                n[code] = trans[code]?.[0]?.name || base.name || '';
            });
            setNames(n);
        });
    }, [id]);

    const submit = async (e) => {
        e.preventDefault();
        await axios.post(`/religions/translate_update/${id}`, { name: names }, { headers: xhrJson });
        nav('/settings/religions');
    };

    return (
        <Shell Layout={Layout}>
            <h1 className="text-2xl font-bold">Translate religion</h1>
            <form onSubmit={submit} className="grid max-w-xl gap-3 rounded border bg-white p-4">
                {languages.map((l) => {
                    const code = l.code || String(l.id);
                    return <input key={code} className="rounded border px-3 py-2" placeholder={`Name (${code})`} value={names[code] || ''} onChange={(e) => setNames({ ...names, [code]: e.target.value })} />;
                })}
                <button className="rounded bg-blue-600 px-3 py-2 text-white">Save translations</button>
            </form>
        </Shell>
    );
}
