import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link, useNavigate, useParams } from 'react-router-dom';

const xhrJson = { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' };

function Shell({ Layout, children }) {
    return (
        <Layout>
            <div className="mx-auto max-w-3xl space-y-6 p-6">{children}</div>
        </Layout>
    );
}

export function BloodGroupsListPage({ Layout }) {
    const [rows, setRows] = useState([]);
    const [meta, setMeta] = useState({});
    const [err, setErr] = useState('');
    const load = () =>
        axios
            .get('/blood-groups', { headers: xhrJson })
            .then((r) => {
                const bg = r.data?.data?.bloodGroup;
                const list = Array.isArray(bg?.data) ? bg.data : Array.isArray(bg) ? bg : [];
                setRows(list);
                setMeta(r.data?.meta ?? {});
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));

    useEffect(() => {
        load();
    }, []);

    const remove = async (id) => {
        if (!window.confirm('Delete this blood group?')) return;
        try {
            await axios.delete(`/blood-groups/delete/${id}`, { headers: xhrJson });
            load();
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Delete failed.');
        }
    };

    return (
        <Shell Layout={Layout}>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900">{meta.title || 'Blood groups'}</h1>
                    <p className="text-sm text-slate-500">Settings reference data.</p>
                </div>
                <Link
                    to="/blood-groups/create"
                    className="inline-flex rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
                >
                    Add blood group
                </Link>
            </div>
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
                <table className="min-w-full divide-y divide-slate-200 text-sm">
                    <thead className="bg-slate-50 text-left text-xs font-semibold uppercase text-slate-600">
                        <tr>
                            <th className="px-4 py-3">Name</th>
                            <th className="px-4 py-3">Status</th>
                            <th className="px-4 py-3 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {rows.map((row) => (
                            <tr key={row.id} className="hover:bg-slate-50/80">
                                <td className="px-4 py-3 font-medium text-slate-900">{row.name}</td>
                                <td className="px-4 py-3">{row.status ? 'Active' : 'Inactive'}</td>
                                <td className="px-4 py-3 text-right">
                                    <Link className="mr-3 font-medium text-blue-600 hover:text-blue-800" to={`/blood-groups/${row.id}/edit`}>
                                        Edit
                                    </Link>
                                    <button type="button" className="text-sm text-red-600 hover:text-red-800" onClick={() => remove(row.id)}>
                                        Delete
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                {!rows.length ? <p className="px-4 py-8 text-center text-sm text-slate-500">No blood groups yet.</p> : null}
            </div>
        </Shell>
    );
}

export function BloodGroupsFormPage({ Layout, edit = false }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [meta, setMeta] = useState({});
    const [form, setForm] = useState({ name: '', status: 1 });
    const [err, setErr] = useState('');
    const [busy, setBusy] = useState(false);

    useEffect(() => {
        if (!edit) {
            axios.get('/blood-groups/create', { headers: xhrJson }).then((r) => setMeta(r.data?.meta || {}));
            return;
        }
        axios
            .get(`/blood-groups/edit/${id}`, { headers: xhrJson })
            .then((r) => {
                setMeta(r.data?.meta || {});
                const bg = r.data?.data?.bloodGroup ?? r.data?.data;
                setForm({ name: bg?.name ?? '', status: bg?.status ? 1 : 0 });
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));
    }, [edit, id]);

    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        setBusy(true);
        try {
            if (edit) {
                await axios.put(`/blood-groups/update/${id}`, { ...form, id }, { headers: xhrJson });
            } else {
                await axios.post('/blood-groups/store', form, { headers: xhrJson });
            }
            nav('/blood-groups');
        } catch (ex) {
            const msg = ex.response?.data?.message || ex.response?.data?.errors;
            setErr(typeof msg === 'object' ? JSON.stringify(msg) : msg || 'Save failed.');
        } finally {
            setBusy(false);
        }
    };

    return (
        <Shell Layout={Layout}>
            <h1 className="text-2xl font-bold text-slate-900">{meta.title || (edit ? 'Edit blood group' : 'Create blood group')}</h1>
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <form onSubmit={submit} className="grid max-w-lg gap-4 rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
                <label className="text-sm font-medium text-slate-700">
                    Name
                    <input
                        className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                        value={form.name}
                        onChange={(e) => setForm({ ...form, name: e.target.value })}
                        required
                    />
                </label>
                <label className="flex items-center gap-2 text-sm text-slate-700">
                    <input
                        type="checkbox"
                        checked={!!Number(form.status)}
                        onChange={(e) => setForm({ ...form, status: e.target.checked ? 1 : 0 })}
                    />
                    Active
                </label>
                <div className="flex gap-2">
                    <button
                        type="submit"
                        disabled={busy}
                        className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-50"
                    >
                        {busy ? 'Saving…' : 'Save'}
                    </button>
                    <Link to="/blood-groups" className="rounded-md border border-slate-300 px-4 py-2 text-sm text-slate-700">
                        Cancel
                    </Link>
                </div>
            </form>
        </Shell>
    );
}
