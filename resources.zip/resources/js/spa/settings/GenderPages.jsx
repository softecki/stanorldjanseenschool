import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link, useNavigate, useParams } from 'react-router-dom';

const xhrJson = { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' };

function Shell({ Layout, children }) {
    return (
        <Layout>
            <div className="mx-auto max-w-3xl space-y-6 p-6">{children}</div>
        </Layout>
    );
}

function paginateRows(res) {
    const p = res.data?.data;
    if (p && Array.isArray(p.data)) return { rows: p.data, paginator: p };
    const list = Array.isArray(p) ? p : [];
    return { rows: list, paginator: null };
}

export function GendersListPage({ Layout }) {
    const [rows, setRows] = useState([]);
    const [paginator, setPaginator] = useState(null);
    const [meta, setMeta] = useState({});
    const [err, setErr] = useState('');

    const load = (page = 1) =>
        axios
            .get('/genders', { headers: xhrJson, params: { page } })
            .then((r) => {
                const { rows: list, paginator: pg } = paginateRows(r);
                setRows(list);
                setPaginator(pg);
                setMeta(r.data?.meta ?? {});
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));

    useEffect(() => {
        load();
    }, []);

    const remove = async (id) => {
        if (!window.confirm('Delete this gender?')) return;
        try {
            await axios.delete(`/genders/delete/${id}`, { headers: xhrJson });
            load(paginator?.current_page || 1);
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Delete failed.');
        }
    };

    return (
        <Shell Layout={Layout}>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900">{meta.title || 'Genders'}</h1>
                    <p className="text-sm text-slate-500">Settings reference data.</p>
                </div>
                <Link
                    to="/settings/genders/create"
                    className="inline-flex rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
                >
                    Add gender
                </Link>
            </div>
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
                <table className="min-w-full divide-y divide-slate-200 text-sm">
                    <thead className="bg-slate-50 text-left text-xs font-semibold uppercase text-slate-600">
                        <tr>
                            <th className="px-4 py-3">Name</th>
                            <th className="px-4 py-3">Status</th>
                            <th className="px-4 py-3 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {rows.map((row) => (
                            <tr key={row.id} className="hover:bg-slate-50/80">
                                <td className="px-4 py-3 font-medium text-slate-900">{row.name}</td>
                                <td className="px-4 py-3">{row.status ? 'Active' : 'Inactive'}</td>
                                <td className="px-4 py-3 text-right">
                                    <Link
                                        className="mr-3 font-medium text-blue-600 hover:text-blue-800"
                                        to={`/settings/genders/${row.id}/edit`}
                                    >
                                        Edit
                                    </Link>
                                    <Link
                                        className="mr-3 font-medium text-slate-600 hover:text-slate-800"
                                        to={`/settings/genders/${row.id}/translate`}
                                    >
                                        Translate
                                    </Link>
                                    <button type="button" className="text-sm text-red-600 hover:text-red-800" onClick={() => remove(row.id)}>
                                        Delete
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                {!rows.length ? <p className="px-4 py-8 text-center text-sm text-slate-500">No genders yet.</p> : null}
            </div>
            {paginator && paginator.last_page > 1 ? (
                <div className="flex items-center justify-between text-sm text-slate-600">
                    <span>
                        Page {paginator.current_page} of {paginator.last_page}
                    </span>
                    <div className="flex gap-2">
                        <button
                            type="button"
                            disabled={paginator.current_page <= 1}
                            className="rounded-md border border-slate-300 px-3 py-1 disabled:opacity-50"
                            onClick={() => load(paginator.current_page - 1)}
                        >
                            Previous
                        </button>
                        <button
                            type="button"
                            disabled={paginator.current_page >= paginator.last_page}
                            className="rounded-md border border-slate-300 px-3 py-1 disabled:opacity-50"
                            onClick={() => load(paginator.current_page + 1)}
                        >
                            Next
                        </button>
                    </div>
                </div>
            ) : null}
        </Shell>
    );
}

export function GendersFormPage({ Layout, edit = false }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [meta, setMeta] = useState({});
    const [form, setForm] = useState({ name: '', status: 1 });
    const [err, setErr] = useState('');
    const [busy, setBusy] = useState(false);

    useEffect(() => {
        if (!edit) {
            axios.get('/genders/create', { headers: xhrJson }).then((r) => setMeta(r.data?.meta || {}));
            return;
        }
        axios
            .get(`/genders/edit/${id}`, { headers: xhrJson })
            .then((r) => {
                setMeta(r.data?.meta || {});
                const g = r.data?.data?.gender ?? r.data?.data;
                setForm({ name: g?.name ?? '', status: g?.status ? 1 : 0 });
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));
    }, [edit, id]);

    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        setBusy(true);
        try {
            if (edit) {
                await axios.put(`/genders/update/${id}`, { ...form, id }, { headers: xhrJson });
            } else {
                await axios.post('/genders/store', form, { headers: xhrJson });
            }
            nav('/settings/genders');
        } catch (ex) {
            const msg = ex.response?.data?.message || ex.response?.data?.errors;
            setErr(typeof msg === 'object' ? JSON.stringify(msg) : msg || 'Save failed.');
        } finally {
            setBusy(false);
        }
    };

    return (
        <Shell Layout={Layout}>
            <h1 className="text-2xl font-bold text-slate-900">{meta.title || (edit ? 'Edit gender' : 'Create gender')}</h1>
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <form onSubmit={submit} className="grid max-w-lg gap-4 rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
                <label className="text-sm font-medium text-slate-700">
                    Name
                    <input
                        className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
                        value={form.name}
                        onChange={(e) => setForm({ ...form, name: e.target.value })}
                        required
                    />
                </label>
                <label className="flex items-center gap-2 text-sm text-slate-700">
                    <input
                        type="checkbox"
                        checked={!!Number(form.status)}
                        onChange={(e) => setForm({ ...form, status: e.target.checked ? 1 : 0 })}
                    />
                    Active
                </label>
                <div className="flex gap-2">
                    <button
                        type="submit"
                        disabled={busy}
                        className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-50"
                    >
                        {busy ? 'Saving…' : 'Save'}
                    </button>
                    <Link to="/settings/genders" className="rounded-md border border-slate-300 px-4 py-2 text-sm text-slate-700">
                        Cancel
                    </Link>
                </div>
            </form>
        </Shell>
    );
}

export function GendersTranslatePage({ Layout }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [meta, setMeta] = useState({});
    const [langs, setLangs] = useState([]);
    const [names, setNames] = useState({});
    const [err, setErr] = useState('');
    const [busy, setBusy] = useState(false);

    useEffect(() => {
        axios
            .get(`/genders/translate/${id}`, { headers: xhrJson })
            .then((r) => {
                setMeta(r.data?.meta || {});
                const langsList = r.data?.data?.languages || [];
                setLangs(langsList);
                const tr = r.data?.data?.translates || {};
                const gender = r.data?.data?.gender;
                const n = {};
                langsList.forEach((l) => {
                    const code = l.code || String(l.id);
                    const row = tr[code]?.[0];
                    n[code] = row?.name ?? gender?.name ?? '';
                });
                setNames(n);
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'));
    }, [id]);

    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        setBusy(true);
        try {
            const fd = new FormData();
            langs.forEach((l) => {
                const code = l.code || String(l.id);
                fd.append(`name[${code}]`, names[code] ?? '');
            });
            await axios.post(`/genders/translate_update/${id}`, fd, {
                headers: { ...xhrJson, 'Content-Type': 'multipart/form-data' },
            });
            nav('/settings/genders');
        } catch (ex) {
            const msg = ex.response?.data?.message || ex.response?.data?.errors;
            setErr(typeof msg === 'object' ? JSON.stringify(msg) : msg || 'Save failed.');
        } finally {
            setBusy(false);
        }
    };

    return (
        <Shell Layout={Layout}>
            <h1 className="text-2xl font-bold text-slate-900">{meta.title || 'Translate gender'}</h1>
            {err ? <p className="text-sm text-red-600">{err}</p> : null}
            <form onSubmit={submit} className="grid max-w-2xl gap-4 rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
                {langs.map((l) => {
                    const code = l.code || String(l.id);
                    return (
                        <div key={code} className="space-y-2 rounded-lg border border-slate-100 p-3">
                            <p className="text-sm font-semibold text-slate-800">{l.name || code}</p>
                            <input
                                className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
                                placeholder="Name"
                                value={names[code] ?? ''}
                                onChange={(e) => setNames({ ...names, [code]: e.target.value })}
                            />
                        </div>
                    );
                })}
                <div className="flex gap-2">
                    <button
                        type="submit"
                        disabled={busy}
                        className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-50"
                    >
                        {busy ? 'Saving…' : 'Save translations'}
                    </button>
                    <Link to="/settings/genders" className="rounded-md border border-slate-300 px-4 py-2 text-sm text-slate-700">
                        Cancel
                    </Link>
                </div>
            </form>
        </Shell>
    );
}
