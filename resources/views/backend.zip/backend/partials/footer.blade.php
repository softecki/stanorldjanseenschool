<!-- Start footer  -->
<div class="footer">
    <p class="px-4">@ 2024 Michael Pre Primary School. All Rights Reserved.</p>
</div>
<!-- End Footer  -->
