<!DOCTYPE html>
<html>
<head>
    <title>Payments Record</title>
    <style>
body {
        font-family: 'Poppins', sans-serif;
        font-size: 14px;
        margin: 0;
        padding: 0;
        -webkit-print-color-adjust: exact !important;
}
.report {
    background: white;
}
.report_header {
    background: #392C7D;
    border-radius: 10px 10px 0 0;
    padding: 10px;

}
.report_header_logo {
    float: left;
    padding: 10px;
    border-right: #E6E6E6 3px solid;
    margin-right: 10px;
}
.report_header_logo img {
    height: 65px;
}
.report_header_content {
    color: white;
    align-content: center;
    width: 1000px;
}
.report_header_content h3 {
    font-size: 24px;
    margin: 0;
    text-align: center;
    width: 1000px;

}
.table-responsive {
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
}
.table{
    width: 100%;
}
.table_th {
    border-right: 0;
    border-color: transparent !important;
    text-align: left;
    background: #E6E6E6 !important;
    font-size: 16px;
    font-weight: 500;
    text-transform: capitalize;
    padding: 8px 4px;
}
.table_td {
    border-right: 0;
    border-color: transparent !important;
    text-align: left;
    font-size: 14px;
    padding: 8px 4px;
}
.table tr:nth-of-type(odd) {
    padding: 0;
    border-color: white;
    background: #F8F8F8;
}
.table tr:nth-of-type(even) {
    border: 0;
    border-color: white;
    background: #EFEFEF;
}
.footer {
    padding: 5px;
    text-align: center;
    background: #E6E6E6 !important;
    border-radius:  0 0 10px 10px;
}
.title{
    padding: 10px 0px;
    margin: 10px 0px;
    font-size: 16px;
    text-align: center;
    background: #E6E6E6;
}

</style>
    <?php
    function numberToWords($number) {
        // Example function to convert numbers to words (you can replace this with your implementation)
        $f = new NumberFormatter("en", NumberFormatter::SPELLOUT);
        return $f->format($number);
    }
    ?>
</head>
<body>
@foreach($allData as $index => $data)
    <div class="row">
        <div class="col-lg-12">
            <div class="report">

                <div class="">

                    @if (!empty($data['result']))
                    <table class="table">
                        <thead>
                        <tr>
                            <th class=""> 
                                 <img style="width: 150px; height: 150px" class="header_logo" src="../public/backend/uploads/settings/Capture.PNG" alt="{{ __('light logo') }}">
                            </th>
                            <th class=""><div class="col-md-6 ">
                                    <h4>{{ 'St MICHAEL SCHOOLS' }}</h4>
                                    <!-- <h4>{{ 'P.O.BOX 11 ARUSHA TANZANIA' }}</h4> -->
                                    <h4>{{ 'Phone: 0624054254 ' }}</h4>
                                </div></th>
                        </tr>
                        </thead>

                        <tbody>
                        <tr>
                            <th style="text-align: left" class="table_td">Receipt Number: {{ $data['result'][0]->transaction_id }}</th>
                            <th style="text-align: right" class="table_td">Receipt Date: {{ $data['result'][0]->date }}</th>
                        </tr>
                        <tr>
                            <th class="table_td">Student Name : {{$data['result'][0]->first_name}} {{$data['result'][0]->last_name}}</th>
                            <th style="text-align: right" class="table_td">{{$data['result'][0]->name}}</th>
                        </tr>
                        <tr>
                            <th style="text-align: left" class="table_td">Registration Number: {{$data['result'][0]->roll_no}} </th>
                            <th style="text-align: right" class="table_td"></th>
                        </tr>
                        <tr>
                            <th style="text-align: left" class="table_td">Being Payment Of:</th>
                            <th style="text-align: right" class="table_td">Amount</th>
                        </tr>

                        <tr>
                            <th style="text-align: left" class="table_td">{{$data['result'][0]->fee_name}}</th>
                            <th style="text-align: right" class="table_td">TZS {{number_format($data['result'][0]->amount, 2, '.', ',')}}</th>
                        </tr>

                        <tr>
                            <th style="text-align: left" class="table_td"></th>
                            <th style="text-align: right" class="table_td">Total Paid = TZS {{number_format($data['result'][0]->amount, 2, '.', ',')}}</th>
                        </tr>



                        </tbody>
                    </table>
                        <div class="row" style="text-align: center; display: flex; flex-direction: column; align-items: center; justify-content: center;">
                            <h4>Receiving Account | {{$data['result'][0]->account_number}}  {{$data['result'][0]->account_name}}</h4>
                            <p>Amount in words | <?php echo numberToWords($data['result'][0]->amount); ?> only</p>
                        </div>

                @endif

                <div class="footer">
                    <p>{{ $data['printedby'] }} : </p>
                    <p></p>
                   
                </div>
                <div>
                    <p></p>
                </div>
            </div>


        </div>
        </div>
    </div>
@endforeach
</body>
</html>
