<!DOCTYPE html>
<html>
<head>
    <title>Payments Record</title>
    <style>
body {
        font-family: 'Poppins', sans-serif;
        font-size: 14px;
        margin: 0;
        padding: 0;
        -webkit-print-color-adjust: exact !important;
}
.report {
    background: white;
}
.report_header {
    background: #392C7D;
    border-radius: 10px 10px 0 0;
    padding: 10px;

}
.report_header_logo {
    float: left;
    padding: 10px;
    border-right: #E6E6E6 3px solid;
    margin-right: 10px;
}
.report_header_logo img {
    height: 65px;
}
.report_header_content {
    color: white;
    align-content: center;
    width: 1000px;
}
.report_header_content h3 {
    font-size: 24px;
    margin: 0;
    text-align: center;
    width: 1000px;

}
.table-responsive {
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
}
.table{
    width: 100%;
}
.table_th {
    border-right: 0;
    border-color: transparent !important;
    text-align: left;
    background: #E6E6E6 !important;
    font-size: 16px;
    font-weight: 500;
    text-transform: capitalize;
    padding: 8px 4px;
}
.table_td {
    border-right: 0;
    border-color: transparent !important;
    text-align: left;
    font-size: 14px;
    padding: 8px 4px;
}
.table tr:nth-of-type(odd) {
    padding: 0;
    border-color: white;
    background: #F8F8F8;
}
.table tr:nth-of-type(even) {
    border: 0;
    border-color: white;
    background: #EFEFEF;
}
.footer {
    padding: 5px;
    text-align: center;
    background: #E6E6E6 !important;
    border-radius:  0 0 10px 10px;
}
.title{
    padding: 10px 0px;
    margin: 10px 0px;
    font-size: 16px;
    text-align: center;
    background: #E6E6E6;
}

</style>
</head>
<body>
    <div class="row">
        <div class="col-lg-12">
            <div class="report">
                

                <div class="">
                    @if (!empty($data['result']))
                     <a title="Print " class="btn btn-sm btn-outline-warning" href="{{ route('fees-collect.printReceipt',$data['result'][0]->student_id) }}">
                                                <span class="icon mr-1" ><i class="fa-solid fa-receipt"></i></span>
                                            </a>
                    <table class="table">
                        <thead>
                        
                        <tr>
                            <th class="table_td">Student Name:</th>
                            <th class="table_td">{{$data['result'][0]->first_name}} {{$data['result'][0]->last_name}}</th>
                         <th class="table_td">Class Name:</th>
                            <th class="table_td">{{$data['result'][0]->name}}</th>
                        </tr>
                     
                       

                        <tr>
                            <th class="table_td">Previous Balance:</th>
                            <th class="table_td">{{number_format($data['outstandingBalance'][0]->outstandingbalance, 2, '.', ',') }} TZS.</th>
                             <th class="table_td">Current Year Amount:</th>
                            <th class="table_td">{{number_format($data['otherFee'][0]->amount??0, 2, '.', ',') }}  TZS</th>
                        
                        </tr>
                      
                        <tr>
                            <th class="table_td">Total Amount:</th>
                            <th class="table_td">{{number_format($data['otherFee'][0]->amount + $data['outstandingBalance'][0]->outstandingbalance, 2, '.', ',') }}  TZS</th>
                             <th class="table_td">Total Amount Paid:</th>
                            <th class="table_td">
                                {{ number_format($data['outstandingBalance'][0]->remained_amount =='0' ?  ($data['otherFee'][0]->paid_amount ?? 0) + ($data['outstandingBalance'][0]->outstandingbalance??0) :
                                    ($data['otherFee'][0]->paid_amount ?? 0) + ($data['outstandingBalance'][0]->outstandingbalance - $data['outstandingBalance'][0]->remained_amount??0), 2, '.', ',') }} TZS
                            </th> 
                        </tr>
                      
                        <tr>
                            <th class="table_td">Total Amount Due:</th>
                            <th class="table_td">
                                {{ number_format(($data['otherFee'][0]->remained_amount ?? 0) + ($data['outstandingBalance'][0]->remained_amount ?? 0), 2, '.', ',') }} TZS
                            </th>                     
                        </tr>

                         <tr>
                            <th class="table_td">1st Term {{number_format($data['schoolfees'][0]->quater_one , 2, '.', ',') }} TZS</th>
                            <th class="table_td">2nd Term {{number_format($data['schoolfees'][0]->quater_two , 2, '.', ',') }}  TZS</th>
                             <th class="table_td">3rd Term {{number_format($data['schoolfees'][0]->quater_three , 2, '.', ',') }} TZS</th>
                            <th class="table_td">
                                4th Term {{ number_format($data['schoolfees'][0]->quater_four , 2, '.', ',') }} TZS
                            </th> 
                        </tr>

                         <tr>
                            <th class="table_td">1st Term {{number_format($data['transport'][0]->quater_one , 2, '.', ',') }} TZS</th>
                            <th class="table_td">2nd Term {{number_format($data['transport'][0]->quater_two , 2, '.', ',') }}  TZS</th>
                             <th class="table_td">3rd Term {{number_format($data['transport'][0]->quater_three , 2, '.', ',') }} TZS</th>
                            <th class="table_td">
                                4th Term {{ number_format($data['transport'][0]->quater_four , 2, '.', ',') }} TZS
                            </th> 
                        </tr>
                      
                        </thead>
                    </table>

                @endif
                <div class="table-responsive">
                    <h4>PAYMENT RECORD</h4>
                    <table class="table">
                        <thead>
                            <tr>
{{--                                <th class="table_th">{{___('common.#')}}</th>--}}
                                <th class="table_th">{{___('common.date')}}</th>
                                <th class="table_th">{{'Receipt Type'}}</th>
                                <th class="table_th">{{'Receipt Number'}}</th>
                                <th class="table_th">{{___('common.Amount')}} ({{ Setting('currency_symbol') }})</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($data['results'] as $key=>$item)
                            <tr>
{{--                                <td class="table_td">{{ ++$key }}</td>--}}
                                <td class="table_td">{{ dateFormat($item->date) }} </td>
                                <td class="table_td">{{ ++$key }} PAYMENT FEES</td>
                                <td class="table_td">{{ $item->transaction_id }}</td>
                                <td class="table_td">{{ number_format($item->amount, 2, '.', ',')}}</td>
{{--                                <td class="table_td">{{ number_format($item->feesCollect->amount + $item->feesCollect->fine_amount, 2, '.', ',') }}</td>--}}
                            </tr>
                            @endforeach
                        <tr>
                            <td></td>
                            <td></td>
                            <td class="table_td" >Total Received</td>
                            <td class="table_td"> {{ number_format($data['outstandingBalance'][0]->remained_amount =='0' ?  ($data['otherFee'][0]->paid_amount ?? 0) + ($data['outstandingBalance'][0]->outstandingbalance??0) :
                                ($data['otherFee'][0]->paid_amount ?? 0) + ($data['outstandingBalance'][0]->outstandingbalance - $data['outstandingBalance'][0]->remained_amount??0), 2, '.', ',') }} </td>
                        </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td class="table_td">Balance Remaining</td>
                                <td class="table_td"> {{ number_format(($data['otherFee'][0]->remained_amount ?? 0) + ($data['outstandingBalance'][0]->remained_amount ?? 0), 2, '.', ',') }}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                
            </div>


        </div>
    </div>
</body>
</html>
