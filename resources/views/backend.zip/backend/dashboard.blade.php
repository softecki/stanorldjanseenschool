@extends('backend.master')

@section('title')
    {{ ___('dashboard.Dashboard') }}
@endsection

@section('content')
    <div class="page-content">
        <div class="row ">

            {{-- Counter --}}
            @if (hasPermission('counter_read'))
                <div class="col-xl-3 col-lg-3 col-md-6">
                    <div class="ot_crm_summeryBox2 d-flex align-items-center mb-24">
                        <div class="icon style2">
                            <img class="img-fluid" src="{{ global_asset('backend/assets/images/crm/4.svg') }}"
                                alt="crm_summery1">
                        </div>
                        <div class="summeryContent">
                            <h4>{{ $data['student'] }}</h4>
                            <h6>{{ ___('dashboard.Student') }}</h6>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-6">
                    <div class="ot_crm_summeryBox2 d-flex align-items-center mb-24">
                        <div class="icon style3">
                            <img class="img-fluid" src="{{ global_asset('backend/assets/images/crm/2.svg') }}"
                                alt="crm_summery1">
                        </div>
                        <div class="summeryContent">
                            <h4>{{ $data['parent'] }}</h4>
                            <h6>{{ ___('dashboard.Parent') }}</h6>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-6">
                    <div class="ot_crm_summeryBox2 d-flex align-items-center mb-24">
                        <div class="summeryContent">
                            <h6 class="text-success">{{ number_format($data['fees_collect'], 2) }}</h6>
                            {{-- <h5 class="text-success" id="hiddenAmount" style="cursor: pointer;" onclick="showPasswordModal()">********</h5> --}}
                            <h6 class="text-success">{{ 'Total collection (TZS)' }}</h6>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-6">
                    <div class="ot_crm_summeryBox2 d-flex align-items-center mb-24">

                        <div class="text-danger summeryContent">
                            <h6 class="text-danger">{{ number_format($data['unpaid_amount'], 2) }}</h6>
                            {{-- <h5 class="text-danger" id="hiddenAmountA" style="cursor: pointer;" onclick="showPasswordModal()">********</h5> --}}
                            <h6 class="text-danger">{{ 'Due Amount (TZS)' }}</h6>
                        </div>
                    </div>
                </div>
            @endif

            <!-- Start Of Fees Collection -->

            <!-- End Of Fees Collection -->

            {{-- Fees collesction --}}
            @if (hasPermission('fees_collesction_read'))
                <div class="col-xxl-8 col-xl-12 ">
                    <div class="ot-card chart-card2 ot_heightFull mb-14">

                        {{-- Tittle --}}
                        <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap_20">
                            <div class="card-title ">
                                <h4 class="mb-0">{{ ___('dashboard.fees_collection') }} ({{ date('Y') }})</h4>
                            </div>
                        </div>

                        <div class="container my-4">
                            <div class="card">
                                {{-- <div class="card-header text-white d-flex justify-content-between align-items-right">

                                    <div class="dropdown">
                                        <button class="btn btn-light btn-sm dropdown-toggle" type="button"
                                            id="termDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                            Choose Term
                                        </button>
                                      <ul class="dropdown-menu" aria-labelledby="termDropdown">
                                            <li><a class="dropdown-item term-select" data-term="1" href="#">Term One</a></li>
                                            <li><a class="dropdown-item term-select" data-term="2" href="#">Term Two</a></li>
                                            <li><a class="dropdown-item term-select" data-term="3" href="#">Term Three</a></li>
                                            <li><a class="dropdown-item term-select" data-term="4" href="#">Term Four</a></li>
                                        </ul>
                                    </div>
                                </div> --}}


                                  

                                    <table class="table table-bordered text-center">
                                        <thead class="fw-bold">
                                            <tr>
                                                <th></th>
                                                <?php foreach ($data['fees_groups'] as $group): ?>
                                                    <th><?= htmlspecialchars($group->name) ?></th>
                                                <?php endforeach; ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            // Initialize arrays for storing totals, amounts paid, and amounts due
                                            $totals = [];
                                            $paid = [];
                                            $due = [];
                                            
                                            // Loop through the collection summary to get totals and paid amounts for each group
                                            foreach ($data['collection_summary'] as $groupName => $summary) {
                                                $totals[] = $summary['total'];
                                                $paid[] = $summary['paid'];
                                                $due[] = $summary['total'] - $summary['paid']; // Calculate amount due
                                            }
                                            ?>
                                            <tr>
                                                <th class="fw-bold">TOTAL</th>
                                                <?php foreach ($totals as $total): ?>
                                                    <td>{{ number_format( $total , 2) }}</td>
                                                <?php endforeach; ?>
                                            </tr>
                                            <tr>
                                                <th class="fw-bold">AMOUNT PAID</th>
                                                <?php foreach ($paid as $paidAmount): ?>
                                                    <td>{{ number_format( $paidAmount , 2) }}</td>
                                                <?php endforeach; ?>
                                            </tr>
                                            <tr>
                                                <th class="fw-bold">AMOUNT DUE</th>
                                                <?php foreach ($due as $dueAmount): ?>
                                                    <td>{{ number_format( $dueAmount, 2) }}</td>
                                                <?php endforeach; ?>
                                            </tr>
                                        </tbody>
                                    </table>



                                </div>
                        </div>

                    </div>
                </div>
            @endif

             <div class="col-12 col-lg-12 col-xl-12 col-xxl-8">
                <div class="ot-card mb-24 ot_heightFull">
                    <div class="card-header d-flex justify-content-between">
                        <div class="card-title">
                            <h4>{{ 'Todays Expenses' }} ({{ date('d M Y') }})</h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered role-table">
                                <thead class="thead">
                                    <tr>
                                        <th class="serial">{{ ___('common.sr_no') }}</th>
                                        <th class="purchase">{{ 'Expenses' }}</th>
                                        <th class="purchase">{{ 'Amount (TZS)' }}</th>
                                        <th class="purchase">{{ 'Date and Time' }} </th>
                                        <th class="purchase">{{ 'Reference Number' }}</th>
                                        <th class="action">{{ ___('common.action') }}</th>
                                    </tr>
                                </thead>
                                <tbody class="tbody">
                                    @foreach ($data['expense_list'] as $key => $row)
                                        <tr>
                                            <td class="serial">{{ ++$key }}</td>
                                            <td class="serial">{{ $row->name }}</td>
                                            <td class="serial">{{ number_format($row->amount, 2, '.', ',') }}</td>
                                            <td class="serial">{{ $row->created_at }}</td>
                                            <td class="serial">{{ $row->invoice_number }}</td>
                                            <td class="serial"> <a class="btn btn-outline-warning"
                                                    href="{{ route('student.edit', @$row->id) }}"><span
                                                        class="icon mr-8"><i class="fa-solid fa-pen-to-square"></i></span>
                                                    {{ 'View' }}</a></td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            {{-- Revenue --}}
            @if (hasPermission('revenue_read'))
                <!-- <div class="col-12 col-lg-12 col-xl-6 col-xxl-4">
                        <div class="ot-card ot_heightFull mb-24">
                            <div class="card-header d-flex justify-content-between">
                                <div class="card-title">
                                    <h4>{{ ___('dashboard.Revenue') }} ({{ date('Y') }})</h4>
                                </div>
                            </div>
                            <div class="d-flex flex-column align-items-center w-100">
                                <div class="d-flex justify-content-between align-items-center w-100">
                                    <div id="ot-line-chart-income"></div>
                                    <div class="chart-custom-content gap-0 flex-column align-items-start">
                                        <h3>{{ ___('dashboard.total_income') }}</h3>
                                        <div class="d-flex align-items-baseline gap-2">
                                            <h2 class="counter">{{ number_format($data['income'], 2, '.', ',') }}</h2>
                                        </div>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-between align-items-center w-100">
                                    <div id="ot-line-chart-expense"></div>
                                    <div class="chart-custom-content gap-0 flex-column align-items-start">
                                        <h3>{{ ___('dashboard.total_expense') }}</h3>
                                        <div class="d-flex align-items-baseline gap-2">
                                            <h2 class="counter">{{ number_format($data['expense'], 2, '.', ',') }}</h2>
                                        </div>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-between align-items-center w-100">
                                    <div id="ot-line-chart-revenue"></div>
                                    <div class="chart-custom-content gap-0 flex-column align-items-start">
                                        <h3>{{ ___('dashboard.total_balance') }}</h3>
                                        <div class="d-flex align-items-baseline gap-2">
                                            <h2 class="counter">{{ number_format($data['balance'], 2, '.', ',') }}</h2>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> -->
            @endif

            {{-- Fees collection this month --}}
            @if (hasPermission('fees_collection_this_month_read'))
                <!-- <div class="col-12 col-lg-12 col-xl-6 col-xxl-6">
                        <div class="ot-card mb-24 ot_heightFull">
                            <div class="card-header d-flex justify-content-between">
                                <div class="card-title">
                                    <h4>{{ ___('dashboard.fees_collection') }} ({{ date('M Y') }})</h4>
                                </div>
                            </div>
                            <div id="fees_collection_this_month"></div>
                        </div>
                    </div> -->
            @endif

            {{-- Income & Expense This Month --}}
            @if (hasPermission('income_expense_read'))
                <div class="col-12 col-lg-12 col-xl-6 col-xxl-6">
                    <div class="ot-card mb-24 ot_heightFull">
                        <div class="card-header d-flex justify-content-between">
                            <div class="card-title">
                                <h4>{{ ___('dashboard.income_and_expense') }} ({{ date('M Y') }})</h4>
                            </div>
                        </div>
                        <div id="income_expense_chart_this_month"></div>
                    </div>
                </div>
            @endif

            <!-- Upcoming Events -->
            @if (hasPermission('upcoming_events_read'))
                <div class="col-xxl-4 col-xl-6">
                    <div class="ot-card chart-card2 ot_heightFull mb-24">
                        <div
                            class="card-header d-flex justify-content-between align-items-center flex-wrap gap_10 card_header_border">
                            <div class="card-title">
                                <h4>{{ ___('dashboard.upcoming_events') }}</h4>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="event_upcoming_list">


                                @foreach ($data['events'] as $item)
                                    <!-- event_upcoming_single  -->
                                    <div class="event_upcoming_single d-flex align-items-center gap_20 flex-wrap">
                                        <div class="icon d-flex align-items-center flex-column justify-content-center">
                                            <h4>{{ date('d', strtotime($item->date)) }}</h4>
                                            <h5>{{ date('D', strtotime($item->date)) }}</h5>
                                        </div>
                                        <div class="event_content_info">
                                            <h4><a href="{{ route('event.edit', $item->id) }}">{!! Str::limit($item->title, 40) !!}</a>
                                            </h4>
                                            <p class="d-flex align-items-center gap-2 "> <svg width="11" height="11"
                                                    viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M8.42676 1.50024H10.4268C10.5594 1.50024 10.6865 1.55292 10.7803 1.64669C10.8741 1.74046 10.9268 1.86764 10.9268 2.00024V10.0002C10.9268 10.1329 10.8741 10.26 10.7803 10.3538C10.6865 10.4476 10.5594 10.5002 10.4268 10.5002H1.42676C1.29415 10.5002 1.16697 10.4476 1.0732 10.3538C0.979436 10.26 0.926758 10.1329 0.926758 10.0002V2.00024C0.926758 1.86764 0.979436 1.74046 1.0732 1.64669C1.16697 1.55292 1.29415 1.50024 1.42676 1.50024H3.42676V0.500244H4.42676V1.50024H7.42676V0.500244H8.42676V1.50024ZM9.92676 5.50024H1.92676V9.50024H9.92676V5.50024ZM7.42676 2.50024H4.42676V3.50024H3.42676V2.50024H1.92676V4.50024H9.92676V2.50024H8.42676V3.50024H7.42676V2.50024ZM2.92676 6.50024H3.92676V7.50024H2.92676V6.50024ZM5.42676 6.50024H6.42676V7.50024H5.42676V6.50024ZM7.92676 6.50024H8.92676V7.50024H7.92676V6.50024Z"
                                                        fill="#6B6B6B" />
                                                </svg>
                                                <span>{{ $item->date == date('Y-m-d') ? 'Today' : dateFormat($item->date) }}
                                                    | {{ timeFormat($item->start_time) }} -
                                                    {{ timeFormat($item->end_time) }}</span>
                                            </p>
                                        </div>
                                    </div>
                                @endforeach



                            </div>
                        </div>
                    </div>
                </div>
            @endif

            {{-- Attendance --}}
           

            {{-- Calendar --}}
            @if (hasPermission('calendar_read'))
                <div class="col-12">
                    <div class="ot-card mb-24">
                        <div id='calendar'></div>
                    </div>
                </div>
            @endif


        </div>
    </div>

    <!-- Password Modal -->
    <div class="modal fade" id="passwordModal" tabindex="-1" aria-labelledby="passwordModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Enter Password to View Amount</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="passwordForm">
                    <div class="modal-body">
                        <input type="password" id="amountPassword" class="form-control" placeholder="Enter Password"
                            required>
                        <input type="hidden" id="amountValue"
                            value="{{ number_format($data['fees_collect'], 2, '.', ',') }}">
                        <input type="hidden" id="amountValueA"
                            value="{{ number_format($data['unpaid_amount'], 2, '.', ',') }}">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" onclick="checkPassword()">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
<!-- JavaScript for modal logic -->
<script>
    function showPasswordModal() {
        var passwordModal = new bootstrap.Modal(document.getElementById('passwordModal'));
        passwordModal.show();
    }

    function checkPassword() {
        const enteredPassword = document.getElementById('amountPassword').value;

        fetch('{{ '/checkamountpassword' }}', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                },
                body: JSON.stringify({
                    password: enteredPassword
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('hiddenAmount').innerText = 'TZS ' + document.getElementById(
                        'amountValue').value;
                    document.getElementById('hiddenAmountA').innerText = 'TZS ' + document.getElementById(
                        'amountValueA').value;
                    bootstrap.Modal.getInstance(document.getElementById('passwordModal')).hide();
                } else {
                    alert('Incorrect password!');
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
    }
</script>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const dropdownItems = document.querySelectorAll(".term-select");

        dropdownItems.forEach(item => {
            item.addEventListener("click", function (e) {
                e.preventDefault();
                const term = this.dataset.term;

                fetch(`dashboardUpdate/${term}`)
                    .then(response => response.json())
                    .then(data => {
                        updateFeeTable(data);
                    })
                    .catch(error => {
                        console.error('Error fetching data:', error);
                    });
            });
        });

        function updateFeeTable(data) {
            const tbody = document.querySelector("table tbody");
            if (!tbody) return;
            tbody.innerHTML = data.html;
        }
    });
</script>


@push('script')
    <script src="{{ global_asset('backend') }}/assets/js/apex-chart.js"></script>
@endpush
