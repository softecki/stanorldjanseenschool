import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { AdminLayout } from '../layout/AdminLayout';

const xhrJson = { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' };

const STATUS_ACTIVE = 1;

function FullPageLoader({ text = 'Loading...' }) {
    return (
        <div className="flex min-h-[60vh] items-center justify-center rounded-xl border border-gray-200 bg-white shadow-sm">
            <div className="flex flex-col items-center gap-3">
                <div className="relative h-12 w-12">
                    <span className="absolute inset-0 rounded-full border-4 border-blue-200" />
                    <span className="absolute inset-0 animate-spin rounded-full border-4 border-transparent border-t-blue-600" />
                    <span className="absolute left-1/2 top-1/2 h-2.5 w-2.5 -translate-x-1/2 -translate-y-1/2 animate-ping rounded-full bg-blue-500" />
                </div>
                <p className="text-sm font-medium text-gray-600">{text}</p>
            </div>
        </div>
    );
}

function sectionOptionsFrom(meta) {
    const sections = meta?.sections || [];
    return sections.map((item) => ({
        id: item?.section?.id ?? item?.id ?? '',
        name: item?.section?.name ?? item?.name ?? '-',
    })).filter((x) => x.id);
}

function classOptionsFrom(meta) {
    const classes = meta?.classes || [];
    return classes.map((item) => ({
        id: item?.class?.id ?? item?.id ?? '',
        name: item?.class?.name ?? item?.name ?? '-',
    })).filter((x) => x.id);
}

function rowFromLegacy(row) {
    const student = row?.student || {};
    return {
        id: student.id ?? row?.id,
        admissionNo: student.admission_no || '-',
        fullName: `${student.first_name || ''} ${student.last_name || ''}`.trim() || '-',
        className: row?.class?.name || '-',
        sectionName: row?.section?.name || '-',
        mobile: student.mobile_no || student.mobile || '-',
        status: student.status,
    };
}

export function StudentsPage() {
    const [rows, setRows] = useState([]);
    const [meta, setMeta] = useState({});
    const [err, setErr] = useState('');
    const [loading, setLoading] = useState(false);
    const [filters, setFilters] = useState({ class: '', section: '', name: '' });

    const classOptions = useMemo(() => classOptionsFrom(meta), [meta]);
    const sectionOptions = useMemo(() => sectionOptionsFrom(meta), [meta]);

    const hydrateFromResponse = (payload) => {
        const paged = payload?.data || {};
        const list = paged?.data || [];
        setRows(list.map(rowFromLegacy));
        setMeta(payload?.meta || {});
    };

    const loadIndex = () => {
        setLoading(true);
        setErr('');
        axios.get('/student', { headers: xhrJson })
            .then((r) => hydrateFromResponse(r.data || {}))
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load students.'))
            .finally(() => setLoading(false));
    };

    const search = (nextFilters) => {
        setLoading(true);
        setErr('');
        axios.post('/student/search', nextFilters, { headers: xhrJson })
            .then((r) => hydrateFromResponse(r.data || {}))
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to search students.'))
            .finally(() => setLoading(false));
    };

    useEffect(() => { loadIndex(); }, []);

    useEffect(() => {
        const id = setTimeout(() => {
            if (!filters.class && !filters.section && !filters.name) {
                loadIndex();
            } else {
                search(filters);
            }
        }, 350);
        return () => clearTimeout(id);
    }, [filters.class, filters.section, filters.name]);

    return (
        <AdminLayout>
            <div className="mx-auto max-w-7xl p-6">
                <div className="mb-5 rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                    <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
                        <h1 className="text-2xl font-semibold text-gray-800">{meta.title || 'Students'}</h1>
                        <div className="flex flex-wrap gap-2">
                            <Link className="rounded-lg bg-blue-600 px-3.5 py-2 text-sm font-medium text-white transition hover:bg-blue-700" to="/students/create">Create</Link>
                            <Link className="rounded-lg border border-gray-200 px-3.5 py-2 text-sm font-medium text-gray-700 transition hover:bg-gray-50" to="/students/upload">Upload</Link>
                        </div>
                    </div>
                </div>

                <div className="mb-5 grid gap-3 rounded-xl border border-gray-200 bg-white p-4 shadow-sm sm:grid-cols-3">
                    <select
                        className="rounded-lg border border-gray-200 px-3 py-2 text-sm"
                        value={filters.class}
                        onChange={(e) => setFilters((f) => ({ ...f, class: e.target.value, section: '' }))}
                    >
                        <option value="">Select Class</option>
                        {classOptions.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                    </select>
                    <select
                        className="rounded-lg border border-gray-200 px-3 py-2 text-sm"
                        value={filters.section}
                        onChange={(e) => setFilters((f) => ({ ...f, section: e.target.value }))}
                    >
                        <option value="">Select Section</option>
                        {sectionOptions.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                    </select>
                    <input
                        className="rounded-lg border border-gray-200 px-3 py-2 text-sm"
                        placeholder="Search by student name"
                        value={filters.name}
                        onChange={(e) => setFilters((f) => ({ ...f, name: e.target.value }))}
                    />
                </div>

                {err ? <p className="mb-3 text-sm text-red-600">{err}</p> : null}
                {loading ? <FullPageLoader text="Loading students..." /> : null}
                {!loading ? <div className="overflow-auto rounded-xl border border-gray-200 bg-white shadow-sm">
                    <table className="min-w-full text-sm">
                        <thead className="bg-gray-50">
                        <tr className="border-b border-gray-200">
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Admission No</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Student Name</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Class</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Section</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Mobile</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Status</th>
                            <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wide text-gray-600">Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        {rows.map((s) => (
                            <tr key={s.id} className="border-b border-gray-100 transition hover:bg-blue-50/30">
                                <td className="px-4 py-3 font-medium text-gray-700">{s.admissionNo}</td>
                                <td className="px-4 py-3 text-gray-800">{s.fullName}</td>
                                <td className="px-4 py-3">{s.className}</td>
                                <td className="px-4 py-3">{s.sectionName}</td>
                                <td className="px-4 py-3">{s.mobile}</td>
                                <td className="px-4 py-3">
                                    <span className={`inline-flex rounded-full px-2.5 py-1 text-xs font-medium ${s.status === STATUS_ACTIVE ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'}`}>
                                        {s.status === STATUS_ACTIVE ? 'Active' : 'Inactive'}
                                    </span>
                                </td>
                                <td className="px-4 py-3">
                                    <div className="flex items-center justify-end gap-2">
                                        <Link to={`/students/${s.id}`} className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-gray-200 text-blue-600 transition hover:bg-blue-50" title="View">
                                            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2">
                                                <path strokeLinecap="round" strokeLinejoin="round" d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6z" />
                                                <circle cx="12" cy="12" r="3" />
                                            </svg>
                                        </Link>
                                        <Link to={`/students/${s.id}/edit`} className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-gray-200 text-amber-600 transition hover:bg-amber-50" title="Edit">
                                            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2">
                                                <path strokeLinecap="round" strokeLinejoin="round" d="M12 20h9" />
                                                <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 3.5a2.1 2.1 0 113 3L7 19l-4 1 1-4 12.5-12.5z" />
                                            </svg>
                                        </Link>
                                        <button
                                            type="button"
                                            onClick={async () => {
                                                if (!window.confirm('Delete this student?')) return;
                                                try {
                                                    await axios.delete(`/student/delete/${s.id}`, { headers: xhrJson });
                                                    loadIndex();
                                                } catch (ex) {
                                                    setErr(ex.response?.data?.message || 'Failed to delete student.');
                                                }
                                            }}
                                            className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-gray-200 text-rose-600 transition hover:bg-rose-50"
                                            title="Delete"
                                        >
                                            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2">
                                                <path strokeLinecap="round" strokeLinejoin="round" d="M3 6h18" />
                                                <path strokeLinecap="round" strokeLinejoin="round" d="M8 6V4h8v2" />
                                                <path strokeLinecap="round" strokeLinejoin="round" d="M19 6l-1 14H6L5 6" />
                                            </svg>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        ))}
                        </tbody>
                    </table>
                </div> : null}
            </div>
        </AdminLayout>
    );
}

