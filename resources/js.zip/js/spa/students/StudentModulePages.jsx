import React, { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';
import { AdminLayout } from '../layout/AdminLayout';

const xhrJson = { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' };

function FullPageLoader({ text = 'Loading...' }) {
    return (
        <div className="flex min-h-[60vh] items-center justify-center rounded-xl border border-gray-200 bg-white shadow-sm">
            <div className="flex flex-col items-center gap-3">
                <div className="relative h-12 w-12">
                    <span className="absolute inset-0 rounded-full border-4 border-blue-200" />
                    <span className="absolute inset-0 animate-spin rounded-full border-4 border-transparent border-t-blue-600" />
                    <span className="absolute left-1/2 top-1/2 h-2.5 w-2.5 -translate-x-1/2 -translate-y-1/2 animate-ping rounded-full bg-blue-500" />
                </div>
                <p className="text-sm font-medium text-gray-600">{text}</p>
            </div>
        </div>
    );
}

function mappedClassOptions(classes = []) {
    return classes.map((c) => ({
        id: c?.class?.id ?? c?.id,
        name: c?.class?.name ?? c?.name ?? '-',
    })).filter((c) => c.id);
}

export function StudentCreatePage() {
    const nav = useNavigate();
    const [meta, setMeta] = useState({});
    const [sections, setSections] = useState([]);
    const [parents, setParents] = useState([]);
    const [form, setForm] = useState({
        admission_no: '',
        first_name: '',
        last_name: '',
        date_of_birth: '',
        admission_date: '',
        gender: '',
        category: '',
        class: '',
        section: '',
        mobile: '',
        second_mobile: '',
        email: '',
        residance_address: '',
        parent: '',
        status: '1',
    });
    const [err, setErr] = useState('');
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        setLoading(true);
        axios.get('/student/create', { headers: xhrJson })
            .then((r) => {
                const m = r.data?.meta || {};
                setMeta(m);
                const classOptions = mappedClassOptions(m.classes || []);
                setForm((f) => ({
                    ...f,
                    category: m.categories?.[0]?.id || '',
                    gender: m.genders?.[0]?.id || '',
                    class: classOptions[0]?.id || '',
                }));
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load form.'))
            .finally(() => setLoading(false));
        axios.get('/parent', { headers: xhrJson })
            .then((r) => setParents(r.data?.data?.data || r.data?.data || []))
            .catch(() => setParents([]));
    }, []);

    useEffect(() => {
        if (!form.class) {
            setSections([]);
            return;
        }
        axios.get('/class-setup/get-sections', { headers: xhrJson, params: { id: form.class } })
            .then((r) => {
                const list = Array.isArray(r.data) ? r.data : (Array.isArray(r.data?.data) ? r.data.data : []);
                setSections(list);
                const firstId = list?.[0]?.section?.id || list?.[0]?.id || '';
                setForm((f) => ({ ...f, section: f.section || firstId }));
            })
            .catch(() => setSections([]));
    }, [form.class]);

    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        setSaving(true);
        try {
            await axios.post('/student/store', form, { headers: xhrJson });
            nav('/students');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Create failed.');
        } finally {
            setSaving(false);
        }
    };

    return (
        <AdminLayout>
            <div className="mx-auto max-w-7xl p-6">
                <div className="mb-5 rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                    <div className="flex items-center justify-between">
                        <h1 className="text-2xl font-semibold text-gray-800">{meta.title || 'Create Student'}</h1>
                        <Link to="/students" className="rounded-lg border border-gray-200 px-3.5 py-2 text-sm font-medium text-gray-700 transition hover:bg-gray-50">Back</Link>
                    </div>
                </div>
                {err ? <p className="mb-3 text-sm text-red-600">{err}</p> : null}
                {loading ? <FullPageLoader text="Loading student form..." /> : null}
                {!loading ? <form onSubmit={submit} className="grid gap-4 rounded-xl border border-gray-200 bg-white p-5 shadow-sm md:grid-cols-3">
                    <input className="rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="Admission No" value={form.admission_no} onChange={(e) => setForm({ ...form, admission_no: e.target.value })} />
                    <input className="rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="First name" value={form.first_name} onChange={(e) => setForm({ ...form, first_name: e.target.value })} required />
                    <input className="rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="Last name" value={form.last_name} onChange={(e) => setForm({ ...form, last_name: e.target.value })} required />
                    <input type="date" className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={form.date_of_birth} onChange={(e) => setForm({ ...form, date_of_birth: e.target.value })} />
                    <input type="date" className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={form.admission_date} onChange={(e) => setForm({ ...form, admission_date: e.target.value })} />
                    <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={form.gender} onChange={(e) => setForm({ ...form, gender: e.target.value })}>
                        <option value="">Select gender</option>
                        {(meta.genders || []).map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
                    </select>
                    <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
                        <option value="">Select category</option>
                        {(meta.categories || []).map((c) => <option key={c.id} value={c.id}>{c.title || c.name}</option>)}
                    </select>
                    <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={form.class} onChange={(e) => setForm({ ...form, class: e.target.value, section: '' })} required>
                        <option value="">Select class</option>
                        {mappedClassOptions(meta.classes || []).map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                    </select>
                    <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={form.section} onChange={(e) => setForm({ ...form, section: e.target.value })} required>
                        <option value="">Select section</option>
                        {sections.map((s) => <option key={s?.section?.id || s.id} value={s?.section?.id || s.id}>{s?.section?.name || s.name}</option>)}
                    </select>
                    <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={form.parent} onChange={(e) => setForm({ ...form, parent: e.target.value })}>
                        <option value="">Select parent</option>
                        {parents.map((p) => <option key={p.id} value={p.id}>{p.name || `${p.first_name || ''} ${p.last_name || ''}`.trim() || `Parent #${p.id}`}</option>)}
                    </select>
                    <input className="rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="Parent mobile" value={form.mobile} onChange={(e) => setForm({ ...form, mobile: e.target.value })} />
                    <input className="rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="Second mobile" value={form.second_mobile} onChange={(e) => setForm({ ...form, second_mobile: e.target.value })} />
                    <input className="rounded-lg border border-gray-200 px-3 py-2 text-sm md:col-span-2" placeholder="Email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
                    <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>
                        <option value="1">Active</option>
                        <option value="2">Inactive</option>
                    </select>
                    <input className="rounded-lg border border-gray-200 px-3 py-2 text-sm md:col-span-3" placeholder="Residence address" value={form.residance_address} onChange={(e) => setForm({ ...form, residance_address: e.target.value })} />
                    <div className="md:col-span-3 flex justify-end gap-2 border-t border-gray-100 pt-3">
                        <Link to="/students" className="rounded-lg border border-gray-200 px-3.5 py-2 text-sm font-medium text-gray-700 transition hover:bg-gray-50">Cancel</Link>
                        <button disabled={saving} className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-blue-700 disabled:opacity-60">{saving ? 'Saving...' : 'Create Student'}</button>
                    </div>
                </form> : null}
            </div>
        </AdminLayout>
    );
}

export function StudentUploadPage() {
    const nav = useNavigate();
    const [form, setForm] = useState({ document_format: '1', document_files: null });
    const [err, setErr] = useState('');
    const [msg, setMsg] = useState('');
    const [busy, setBusy] = useState(false);
    const submit = async (e) => {
        e.preventDefault();
        if (!form.document_files) {
            setErr('Please select a file to upload.');
            return;
        }
        setErr('');
        setMsg('');
        setBusy(true);
        const fd = new FormData();
        fd.append('document_format', form.document_format);
        fd.append('document_files', form.document_files);
        try {
            await axios.post('/student/uploadStudent', fd, { headers: { ...xhrJson, 'Content-Type': 'multipart/form-data' } });
            setMsg('Upload completed successfully.');
            setForm((f) => ({ ...f, document_files: null }));
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Upload failed.');
        } finally {
            setBusy(false);
        }
    };
    return (
        <AdminLayout>
            <div className="mx-auto max-w-5xl p-6">
                <div className="mb-5 rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                    <div className="flex items-center justify-between">
                        <h1 className="text-2xl font-semibold text-gray-800">Upload Students Details</h1>
                        <button type="button" onClick={() => nav('/students')} className="rounded-lg border border-gray-200 px-3.5 py-2 text-sm font-medium text-gray-700 transition hover:bg-gray-50">Back</button>
                    </div>
                </div>
                {err ? <p className="mb-3 text-sm text-red-600">{err}</p> : null}
                {msg ? <p className="mb-3 text-sm text-emerald-600">{msg}</p> : null}
                <form onSubmit={submit} className="grid gap-4 rounded-xl border border-gray-200 bg-white p-5 shadow-sm md:grid-cols-[220px_1fr_auto]">
                    <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={form.document_format} onChange={(e) => setForm((f) => ({ ...f, document_format: e.target.value }))}>
                        <option value="1">Format 1</option>
                        <option value="2">Format 2</option>
                    </select>
                    <input type="file" accept=".xlsx,.xls,.csv" className="rounded-lg border border-gray-200 px-3 py-2 text-sm" onChange={(e) => setForm((f) => ({ ...f, document_files: e.target.files?.[0] || null }))} />
                    <button className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-blue-700 disabled:opacity-60" disabled={busy}>
                        {busy ? 'Uploading...' : 'Submit'}
                    </button>
                </form>
                <div className="mt-4 rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800">
                    <p><strong>Format 1:</strong> includes fees assignment.</p>
                    <p><strong>Format 2:</strong> class-only student import (no fees assignment).</p>
                    <a href="/student/download-template" className="mt-2 inline-flex rounded-lg border border-amber-300 bg-white px-3 py-1.5 text-xs font-medium text-amber-700 transition hover:bg-amber-100">
                        Download Students Excel Format
                    </a>
                </div>
            </div>
        </AdminLayout>
    );
}

export function StudentShowPage() {
    const { id } = useParams();
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);
    useEffect(() => {
        setLoading(true);
        axios.get(`/student/show/${id}`, { headers: xhrJson })
            .then((r) => setData(r.data?.data || null))
            .finally(() => setLoading(false));
    }, [id]);
    return (
        <AdminLayout>
            <div className="mx-auto max-w-5xl p-6">
                <h1 className="text-2xl font-bold">Student Details</h1>
                {loading ? <FullPageLoader text="Loading student details..." /> : null}
                {!loading ? <pre className="mt-4 overflow-auto rounded bg-white p-4 text-xs">{JSON.stringify(data, null, 2)}</pre> : null}
                <div className="mt-3"><Link to={`/students/${id}/edit`} className="text-blue-700">Edit</Link></div>
            </div>
        </AdminLayout>
    );
}

export function StudentEditPage() {
    const { id } = useParams();
    const nav = useNavigate();
    const [form, setForm] = useState({});
    const [meta, setMeta] = useState({});
    const [sections, setSections] = useState([]);
    const [parents, setParents] = useState([]);
    const [err, setErr] = useState('');
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    useEffect(() => {
        setLoading(true);
        axios.get(`/student/edit/${id}`, { headers: xhrJson })
            .then((r) => {
                const payload = r.data?.data || {};
                const m = r.data?.meta || {};
                setMeta(m);
                setForm({
                    ...payload,
                    class: m?.session_class_student?.classes_id || '',
                    section: m?.session_class_student?.section_id || '',
                    parent: payload?.parent ?? payload?.parent_id ?? '',
                    status: String(payload?.status ?? '1'),
                });
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'))
            .finally(() => setLoading(false));
        axios.get('/parent', { headers: xhrJson })
            .then((r) => setParents(r.data?.data?.data || r.data?.data || []))
            .catch(() => setParents([]));
    }, [id]);

    useEffect(() => {
        if (!form.class) return;
        axios.get('/class-setup/get-sections', { headers: xhrJson, params: { id: form.class } })
            .then((r) => {
                const list = Array.isArray(r.data) ? r.data : (Array.isArray(r.data?.data) ? r.data.data : []);
                setSections(list);
            })
            .catch(() => setSections([]));
    }, [form.class]);

    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        setSaving(true);
        try {
            await axios.put('/student/update', { ...form, id }, { headers: xhrJson });
            nav('/students');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Update failed.');
        } finally {
            setSaving(false);
        }
    };
    return (
        <AdminLayout>
            <div className="mx-auto max-w-7xl p-6">
                <div className="mb-5 rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                    <div className="flex items-center justify-between">
                        <h1 className="text-2xl font-semibold text-gray-800">{meta.title || 'Edit Student'}</h1>
                        <Link to="/students" className="rounded-lg border border-gray-200 px-3.5 py-2 text-sm font-medium text-gray-700 transition hover:bg-gray-50">Back</Link>
                    </div>
                </div>
                {err ? <p className="mb-3 text-sm text-red-600">{err}</p> : null}
                {loading ? <FullPageLoader text="Loading student data..." /> : null}
                {!loading ? <form onSubmit={submit} className="grid gap-4 rounded-xl border border-gray-200 bg-white p-5 shadow-sm md:grid-cols-3">
                    <input className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={form.admission_no || ''} onChange={(e) => setForm({ ...form, admission_no: e.target.value })} placeholder="Admission No" />
                    <input className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={form.first_name || ''} onChange={(e) => setForm({ ...form, first_name: e.target.value })} placeholder="First Name" required />
                    <input className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={form.last_name || ''} onChange={(e) => setForm({ ...form, last_name: e.target.value })} placeholder="Last Name" required />
                    <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={form.class || ''} onChange={(e) => setForm({ ...form, class: e.target.value, section: '' })} required>
                        <option value="">Select class</option>
                        {mappedClassOptions(meta.classes || []).map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                    </select>
                    <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={form.section || ''} onChange={(e) => setForm({ ...form, section: e.target.value })} required>
                        <option value="">Select section</option>
                        {sections.map((s) => <option key={s?.section?.id || s.id} value={s?.section?.id || s.id}>{s?.section?.name || s.name}</option>)}
                    </select>
                    <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={form.parent || ''} onChange={(e) => setForm({ ...form, parent: e.target.value })} required>
                        <option value="">Select parent</option>
                        {parents.map((p) => <option key={p.id} value={p.id}>{p.name || `${p.first_name || ''} ${p.last_name || ''}`.trim() || `Parent #${p.id}`}</option>)}
                    </select>
                    <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={String(form.status || '1')} onChange={(e) => setForm({ ...form, status: e.target.value })} required>
                        <option value="1">Active</option>
                        <option value="2">Inactive</option>
                    </select>
                    <input className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={form.mobile || form.mobile_no || ''} onChange={(e) => setForm({ ...form, mobile: e.target.value })} placeholder="Mobile" />
                    <input className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={form.email || ''} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="Email" />
                    <div className="md:col-span-3 flex justify-end gap-2 border-t border-gray-100 pt-3">
                        <Link to="/students" className="rounded-lg border border-gray-200 px-3.5 py-2 text-sm font-medium text-gray-700 transition hover:bg-gray-50">Cancel</Link>
                        <button disabled={saving} className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-blue-700 disabled:opacity-60">{saving ? 'Saving...' : 'Save Changes'}</button>
                    </div>
                </form> : null}
            </div>
        </AdminLayout>
    );
}

export function StudentCategoriesPage() {
    const [rows, setRows] = useState([]);
    const [err, setErr] = useState('');
    const [loading, setLoading] = useState(true);
    const load = () => {
        setLoading(true);
        return axios.get('/student/category', { headers: xhrJson })
            .then((r) => setRows(r.data?.data?.data || r.data?.data || []))
            .finally(() => setLoading(false));
    };
    useEffect(() => { load(); }, []);

    const remove = async (id) => {
        if (!window.confirm('Delete this category?')) return;
        setErr('');
        try {
            await axios.delete(`/student/category/delete/${id}`, { headers: xhrJson });
            load();
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Failed to delete category.');
        }
    };

    return (
        <AdminLayout>
            <div className="mx-auto max-w-7xl p-6">
                <div className="mb-5 rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                    <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
                        <h1 className="text-2xl font-semibold text-gray-800">Student Categories</h1>
                        <Link to="/categories/create" className="rounded-lg bg-blue-600 px-3.5 py-2 text-sm font-medium text-white transition hover:bg-blue-700">
                            Create
                        </Link>
                    </div>
                </div>
                {err ? <p className="mb-3 text-sm text-red-600">{err}</p> : null}
                {loading ? <FullPageLoader text="Loading categories..." /> : null}
                {!loading ? <div className="overflow-auto rounded-xl border border-gray-200 bg-white shadow-sm">
                    <table className="min-w-full text-sm">
                        <thead className="bg-gray-50">
                        <tr className="border-b border-gray-200">
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">#</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Category Name</th>
                            <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wide text-gray-600">Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        {rows.map((c, idx) => (
                            <tr key={c.id} className="border-b border-gray-100 transition hover:bg-blue-50/30">
                                <td className="px-4 py-3 font-medium text-gray-700">{idx + 1}</td>
                                <td className="px-4 py-3 text-gray-800">{c.title || c.name || '-'}</td>
                                <td className="px-4 py-3">
                                    <div className="flex items-center justify-end gap-2">
                                        <Link to={`/categories/${c.id}/edit`} className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-gray-200 text-amber-600 transition hover:bg-amber-50" title="Edit">
                                            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2">
                                                <path strokeLinecap="round" strokeLinejoin="round" d="M12 20h9" />
                                                <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 3.5a2.1 2.1 0 113 3L7 19l-4 1 1-4 12.5-12.5z" />
                                            </svg>
                                        </Link>
                                        <button type="button" onClick={() => remove(c.id)} className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-gray-200 text-rose-600 transition hover:bg-rose-50" title="Delete">
                                            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2">
                                                <path strokeLinecap="round" strokeLinejoin="round" d="M3 6h18" />
                                                <path strokeLinecap="round" strokeLinejoin="round" d="M8 6V4h8v2" />
                                                <path strokeLinecap="round" strokeLinejoin="round" d="M19 6l-1 14H6L5 6" />
                                            </svg>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        ))}
                        </tbody>
                    </table>
                </div> : null}
            </div>
        </AdminLayout>
    );
}

export function StudentCategoryFormPage({ edit = false }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [form, setForm] = useState({ title: '' });
    const [err, setErr] = useState('');
    const [busy, setBusy] = useState(false);
    const [loading, setLoading] = useState(edit);

    useEffect(() => {
        if (!edit || !id) return;
        setLoading(true);
        axios.get(`/student/category/edit/${id}`, { headers: xhrJson })
            .then((r) => {
                const d = r.data?.data || r.data || {};
                setForm({ title: d.title || d.name || '' });
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load category.'))
            .finally(() => setLoading(false));
    }, [edit, id]);

    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        setBusy(true);
        try {
            if (edit) await axios.put(`/student/category/update/${id}`, form, { headers: xhrJson });
            else await axios.post('/student/category/store', form, { headers: xhrJson });
            nav('/categories');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Failed to save category.');
        } finally {
            setBusy(false);
        }
    };

    return (
        <AdminLayout>
            <div className="mx-auto max-w-5xl p-6">
                <div className="mb-5 rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                    <div className="flex items-center justify-between">
                        <h1 className="text-2xl font-semibold text-gray-800">{edit ? 'Edit Category' : 'Create Category'}</h1>
                        <Link to="/categories" className="rounded-lg border border-gray-200 px-3.5 py-2 text-sm font-medium text-gray-700 transition hover:bg-gray-50">Back</Link>
                    </div>
                </div>
                {err ? <p className="mb-3 text-sm text-red-600">{err}</p> : null}
                {loading ? <FullPageLoader text="Loading category form..." /> : null}
                {!loading ? <form onSubmit={submit} className="grid gap-4 rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
                    <div className="space-y-1">
                        <label className="text-xs font-semibold uppercase tracking-wide text-gray-600">Category Title</label>
                        <input
                            className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm"
                            placeholder="Enter category title"
                            value={form.title}
                            onChange={(e) => setForm({ title: e.target.value })}
                            required
                        />
                    </div>
                    <div className="flex justify-end gap-2 border-t border-gray-100 pt-3">
                        <Link to="/categories" className="rounded-lg border border-gray-200 px-3.5 py-2 text-sm font-medium text-gray-700 transition hover:bg-gray-50">Cancel</Link>
                        <button disabled={busy} className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-blue-700 disabled:opacity-60">
                            {busy ? 'Saving...' : (edit ? 'Update Category' : 'Create Category')}
                        </button>
                    </div>
                </form> : null}
            </div>
        </AdminLayout>
    );
}

export function ParentsPage() {
    const [rows, setRows] = useState([]);
    const [query, setQuery] = useState('');
    const [err, setErr] = useState('');
    const [loading, setLoading] = useState(false);

    const load = (keyword = '') => {
        setLoading(true);
        const req = keyword
            ? axios.post('/parent/search', { keyword }, { headers: xhrJson })
            : axios.get('/parent', { headers: xhrJson });
        req.then((r) => {
            setRows(r.data?.data?.data || r.data?.data || []);
            setErr('');
        }).catch((ex) => {
            setErr(ex.response?.data?.message || 'Failed to load parents.');
        }).finally(() => setLoading(false));
    };

    useEffect(() => { load(); }, []);

    const remove = async (id) => {
        if (!window.confirm('Delete this parent?')) return;
        try {
            await axios.delete(`/parent/delete/${id}`, { headers: xhrJson });
            load(query);
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Failed to delete parent.');
        }
    };

    return (
        <AdminLayout>
            <div className="mx-auto max-w-7xl p-6">
                <div className="mb-5 rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                    <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
                        <h1 className="text-2xl font-semibold text-gray-800">Parents</h1>
                        <div className="flex flex-wrap gap-2">
                            <input
                                value={query}
                                onChange={(e) => setQuery(e.target.value)}
                                placeholder="Search parent"
                                className="rounded-lg border border-gray-200 px-3 py-2 text-sm"
                            />
                            <button onClick={() => load(query)} className="rounded-lg border border-gray-200 px-3.5 py-2 text-sm font-medium text-gray-700 transition hover:bg-gray-50">Search</button>
                            <Link to="/parents/create" className="rounded-lg bg-blue-600 px-3.5 py-2 text-sm font-medium text-white transition hover:bg-blue-700">Create</Link>
                        </div>
                    </div>
                </div>
                {err ? <p className="mb-3 text-sm text-red-600">{err}</p> : null}
                {loading ? <FullPageLoader text="Loading parents..." /> : null}
                {!loading ? <div className="overflow-auto rounded-xl border border-gray-200 bg-white shadow-sm">
                    <table className="min-w-full text-sm">
                        <thead className="bg-gray-50">
                        <tr className="border-b border-gray-200">
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Name</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Phone</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Email</th>
                            <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wide text-gray-600">Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        {rows.map((p) => (
                            <tr className="border-b border-gray-100 transition hover:bg-blue-50/30" key={p.id}>
                                <td className="px-4 py-3 text-gray-800">{p.name || `${p.first_name || ''} ${p.last_name || ''}`.trim() || '-'}</td>
                                <td className="px-4 py-3 text-gray-700">{p.phone || p.mobile || p.mobile_no || '-'}</td>
                                <td className="px-4 py-3 text-gray-700">{p.email || '-'}</td>
                                <td className="px-4 py-3">
                                    <div className="flex items-center justify-end gap-2">
                                        <Link to={`/parents/${p.id}/edit`} className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-gray-200 text-amber-600 transition hover:bg-amber-50" title="Edit">
                                            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2">
                                                <path strokeLinecap="round" strokeLinejoin="round" d="M12 20h9" />
                                                <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 3.5a2.1 2.1 0 113 3L7 19l-4 1 1-4 12.5-12.5z" />
                                            </svg>
                                        </Link>
                                        <button type="button" onClick={() => remove(p.id)} className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-gray-200 text-rose-600 transition hover:bg-rose-50" title="Delete">
                                            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2">
                                                <path strokeLinecap="round" strokeLinejoin="round" d="M3 6h18" />
                                                <path strokeLinecap="round" strokeLinejoin="round" d="M8 6V4h8v2" />
                                                <path strokeLinecap="round" strokeLinejoin="round" d="M19 6l-1 14H6L5 6" />
                                            </svg>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        ))}
                        </tbody>
                    </table>
                </div> : null}
            </div>
        </AdminLayout>
    );
}

export function ParentFormPage({ edit = false }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [form, setForm] = useState({});
    const [err, setErr] = useState('');
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    useEffect(() => {
        const url = edit ? `/parent/edit/${id}` : '/parent/create';
        setLoading(true);
        axios.get(url, { headers: xhrJson }).then((r) => {
            if (edit) setForm(r.data?.data || {});
        }).catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.')).finally(() => setLoading(false));
    }, [edit, id]);
    const submit = async (e) => {
        e.preventDefault();
        setSaving(true);
        try {
            if (edit) await axios.put(`/parent/update/${id}`, form, { headers: xhrJson });
            else await axios.post('/parent/store', form, { headers: xhrJson });
            nav('/parents');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Save failed.');
        } finally {
            setSaving(false);
        }
    };
    return (
        <AdminLayout>
            <div className="mx-auto max-w-5xl p-6">
                <div className="mb-5 rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                    <div className="flex items-center justify-between">
                        <h1 className="text-2xl font-semibold text-gray-800">{edit ? 'Edit Parent' : 'Create Parent'}</h1>
                        <Link to="/parents" className="rounded-lg border border-gray-200 px-3.5 py-2 text-sm font-medium text-gray-700 transition hover:bg-gray-50">
                            Back
                        </Link>
                    </div>
                </div>
                {err ? <p className="mb-3 text-sm text-red-600">{err}</p> : null}
                {loading ? <FullPageLoader text="Loading parent form..." /> : null}
                {!loading ? <form onSubmit={submit} className="grid gap-4 rounded-xl border border-gray-200 bg-white p-5 shadow-sm md:grid-cols-2">
                    <div className="space-y-1">
                        <label className="text-xs font-semibold uppercase tracking-wide text-gray-600">First Name</label>
                        <input className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="First name" value={form.first_name || ''} onChange={(e) => setForm({ ...form, first_name: e.target.value })} />
                    </div>
                    <div className="space-y-1">
                        <label className="text-xs font-semibold uppercase tracking-wide text-gray-600">Last Name</label>
                        <input className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="Last name" value={form.last_name || ''} onChange={(e) => setForm({ ...form, last_name: e.target.value })} />
                    </div>
                    <div className="space-y-1 md:col-span-2">
                        <label className="text-xs font-semibold uppercase tracking-wide text-gray-600">Phone</label>
                        <input className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="Phone" value={form.phone || ''} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
                    </div>
                    <div className="md:col-span-2 flex items-center justify-end gap-2 border-t border-gray-100 pt-3">
                        <Link to="/parents" className="rounded-lg border border-gray-200 px-3.5 py-2 text-sm font-medium text-gray-700 transition hover:bg-gray-50">
                            Cancel
                        </Link>
                        <button disabled={saving} className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-blue-700 disabled:opacity-60">
                            {saving ? 'Saving...' : (edit ? 'Update Parent' : 'Create Parent')}
                        </button>
                    </div>
                </form> : null}
            </div>
        </AdminLayout>
    );
}

export function PromoteStudentsIndexPage() {
    return (
        <AdminLayout>
            <div className="mx-auto max-w-7xl p-6">
                <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
                    <div className="flex items-center justify-between">
                        <div>
                            <h1 className="text-2xl font-semibold text-gray-800">Promote Students</h1>
                            <p className="mt-1 text-sm text-gray-500">Create a promote session and search students to promote.</p>
                        </div>
                        <Link to="/promote/create" className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-blue-700">
                            Create
                        </Link>
                    </div>
                </div>
            </div>
        </AdminLayout>
    );
}

export function PromoteStudentsCreatePage() {
    const [meta, setMeta] = useState({});
    const [filters, setFilters] = useState({
        class: '',
        section: '',
        promote_session: '',
        promote_class: '',
        promote_section: '',
    });
    const [students, setStudents] = useState([]);
    const [results, setResults] = useState({});
    const [selected, setSelected] = useState({});
    const [rolls, setRolls] = useState({});
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [err, setErr] = useState('');

    const toList = (value) => {
        if (Array.isArray(value)) return value;
        if (Array.isArray(value?.data)) return value.data;
        return [];
    };

    const loadIndex = () => {
        setLoading(true);
        axios.get('/promote-students', { headers: xhrJson })
            .then((r) => {
                setMeta(r.data?.meta || {});
                setStudents([]);
                setResults({});
            })
            .finally(() => setLoading(false));
    };

    const loadSourceSections = (classId) => {
        if (!classId) return setMeta((m) => ({ ...m, sections: [] }));
        axios.get('/class-setup/get-sections', { headers: xhrJson, params: { id: classId } })
            .then((r) => setMeta((m) => ({ ...m, sections: toList(r.data) })))
            .catch(() => setMeta((m) => ({ ...m, sections: [] })));
    };

    const loadPromoteClasses = (sessionId) => {
        if (!sessionId) return setMeta((m) => ({ ...m, promoteClasses: [], promoteSections: [] }));
        axios.get('/promote/students/get-class', { headers: xhrJson, params: { id: sessionId } })
            .then((r) => setMeta((m) => ({ ...m, promoteClasses: toList(r.data), promoteSections: [] })))
            .catch(() => setMeta((m) => ({ ...m, promoteClasses: [], promoteSections: [] })));
    };

    const loadPromoteSections = (sessionId, classId) => {
        if (!sessionId || !classId) return setMeta((m) => ({ ...m, promoteSections: [] }));
        axios.get('/promote/students/get-sections', { headers: xhrJson, params: { session: sessionId, class: classId } })
            .then((r) => setMeta((m) => ({ ...m, promoteSections: toList(r.data) })))
            .catch(() => setMeta((m) => ({ ...m, promoteSections: [] })));
    };

    useEffect(() => {
        loadIndex();
    }, []);

    const doSearch = async (e) => {
        e.preventDefault();
        setLoading(true);
        setErr('');
        try {
            const r = await axios.post('/promote-students/search', filters, { headers: xhrJson });
            const data = r.data?.data || {};
            setStudents(data.students || []);
            setResults(data.results || {});
            setMeta(r.data?.meta || {});
            setSelected({});
            setRolls({});
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Failed to search students.');
        } finally {
            setLoading(false);
        }
    };

    const selectedCount = Object.values(selected).filter(Boolean).length;

    const submitPromote = async () => {
        const chosen = students.map((s, idx) => ({ s, idx })).filter(({ s }) => selected[s?.student?.id]);
        if (!chosen.length) {
            setErr('Select at least one student to promote.');
            return;
        }
        setSaving(true);
        setErr('');
        try {
            const fd = new FormData();
            fd.append('class', filters.class);
            fd.append('section', filters.section);
            fd.append('promote_session', filters.promote_session);
            fd.append('promote_class', filters.promote_class);
            fd.append('promote_section', filters.promote_section);

            chosen.forEach(({ s, idx }) => {
                const id = s?.student?.id;
                const pass = results?.[id] === 'Pass' ? 1 : 0;
                fd.append(`students[${idx}][]`, id);
                fd.append(`result[${idx}][]`, String(pass));
                fd.append(`roll[${idx}][]`, String(rolls[id] || ''));
            });

            await axios.post('/promote-students/store', fd, { headers: xhrJson });
            await doSearch({ preventDefault() {} });
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Failed to promote students.');
        } finally {
            setSaving(false);
        }
    };

    return (
        <AdminLayout>
            <div className="mx-auto max-w-7xl p-6">
                <div className="mb-5 rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                    <h1 className="text-2xl font-semibold text-gray-800">{meta.title || 'Promote Students'}</h1>
                    <p className="mt-1 text-sm text-gray-500">Search students and promote selected rows to the next session/class/section.</p>
                </div>

                <form className="mb-5 grid gap-3 rounded-xl border border-gray-200 bg-white p-4 shadow-sm md:grid-cols-5" onSubmit={doSearch}>
                    <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={filters.class} onChange={(e) => { const v = e.target.value; setFilters((f) => ({ ...f, class: v, section: '' })); loadSourceSections(v); }}>
                        <option value="">Current Class</option>
                        {(meta.classes || []).map((c) => <option key={c?.class?.id || c.id} value={c?.class?.id || c.id}>{c?.class?.name || c.name}</option>)}
                    </select>
                    <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={filters.section} onChange={(e) => setFilters((f) => ({ ...f, section: e.target.value }))}>
                        <option value="">Current Section</option>
                        {(meta.sections || []).map((s) => <option key={s?.section?.id || s.id} value={s?.section?.id || s.id}>{s?.section?.name || s.name}</option>)}
                    </select>
                    <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={filters.promote_session} onChange={(e) => { const v = e.target.value; setFilters((f) => ({ ...f, promote_session: v, promote_class: '', promote_section: '' })); loadPromoteClasses(v); }}>
                        <option value="">Promote Session</option>
                        {(meta.sessions || []).map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                    </select>
                    <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={filters.promote_class} onChange={(e) => { const v = e.target.value; setFilters((f) => ({ ...f, promote_class: v, promote_section: '' })); loadPromoteSections(filters.promote_session, v); }}>
                        <option value="">Promote Class</option>
                        {(meta.promoteClasses || []).map((c) => <option key={c?.class?.id || c.id} value={c?.class?.id || c.id}>{c?.class?.name || c.name}</option>)}
                    </select>
                    <div className="flex gap-2">
                        <select className="min-w-0 flex-1 rounded-lg border border-gray-200 px-3 py-2 text-sm" value={filters.promote_section} onChange={(e) => setFilters((f) => ({ ...f, promote_section: e.target.value }))}>
                            <option value="">Promote Section</option>
                            {(meta.promoteSections || []).map((s) => <option key={s?.section?.id || s.id} value={s?.section?.id || s.id}>{s?.section?.name || s.name}</option>)}
                        </select>
                        <button className="rounded-lg bg-blue-600 px-3.5 py-2 text-sm font-medium text-white transition hover:bg-blue-700">Search</button>
                    </div>
                </form>

                {err ? <p className="mb-3 text-sm text-red-600">{err}</p> : null}
                {loading ? <FullPageLoader text="Loading promote students..." /> : null}
                {!loading ? <div className="overflow-auto rounded-xl border border-gray-200 bg-white shadow-sm">
                    <table className="min-w-full text-sm">
                        <thead className="bg-gray-50">
                        <tr className="border-b border-gray-200">
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">
                                <input
                                    type="checkbox"
                                    checked={students.length > 0 && selectedCount === students.length}
                                    onChange={(e) => {
                                        const checked = e.target.checked;
                                        const next = {};
                                        students.forEach((s) => { next[s?.student?.id] = checked; });
                                        setSelected(next);
                                    }}
                                />
                            </th>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Admission No</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Student Name</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Guardian</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Mobile</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Result</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Roll</th>
                            <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wide text-gray-600">Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        {students.map((item) => {
                            const sid = item?.student?.id;
                            const pass = results?.[sid] === 'Pass';
                            return (
                                <tr key={sid} className="border-b border-gray-100 transition hover:bg-blue-50/30">
                                    <td className="px-4 py-3">
                                        <input type="checkbox" checked={!!selected[sid]} onChange={(e) => setSelected((prev) => ({ ...prev, [sid]: e.target.checked }))} />
                                    </td>
                                    <td className="px-4 py-3 font-medium text-gray-700">{item?.student?.admission_no || '-'}</td>
                                    <td className="px-4 py-3 text-gray-800">{`${item?.student?.first_name || ''} ${item?.student?.last_name || ''}`.trim() || '-'}</td>
                                    <td className="px-4 py-3 text-gray-700">{item?.student?.parent?.guardian_name || '-'}</td>
                                    <td className="px-4 py-3 text-gray-700">{item?.student?.mobile_no || item?.student?.mobile || '-'}</td>
                                    <td className="px-4 py-3">
                                        <span className={`inline-flex rounded-full px-2.5 py-1 text-xs font-medium ${pass ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'}`}>
                                            {pass ? 'Passed' : 'Pending/Failed'}
                                        </span>
                                    </td>
                                    <td className="px-4 py-3">
                                        <input
                                            type="number"
                                            className="w-20 rounded-lg border border-gray-200 px-2 py-1.5 text-sm"
                                            value={rolls[sid] || ''}
                                            onChange={(e) => setRolls((prev) => ({ ...prev, [sid]: e.target.value }))}
                                        />
                                    </td>
                                    <td className="px-4 py-3">
                                        <div className="flex items-center justify-end gap-2">
                                            <Link to={`/students/${sid}`} className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-gray-200 text-blue-600 transition hover:bg-blue-50" title="View">
                                                <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6z" /><circle cx="12" cy="12" r="3" /></svg>
                                            </Link>
                                            <Link to={`/students/${sid}/edit`} className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-gray-200 text-amber-600 transition hover:bg-amber-50" title="Edit">
                                                <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M12 20h9" /><path strokeLinecap="round" strokeLinejoin="round" d="M16.5 3.5a2.1 2.1 0 113 3L7 19l-4 1 1-4 12.5-12.5z" /></svg>
                                            </Link>
                                        </div>
                                    </td>
                                </tr>
                            );
                        })}
                        </tbody>
                    </table>
                </div> : null}

                {!loading && students.length ? (
                    <div className="mt-4 flex items-center justify-between">
                        <p className="text-sm text-gray-600">{selectedCount} selected</p>
                        <button type="button" disabled={saving} onClick={submitPromote} className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-emerald-700 disabled:cursor-not-allowed disabled:opacity-60">
                            {saving ? 'Promoting...' : 'Promote Selected'}
                        </button>
                    </div>
                ) : null}
            </div>
        </AdminLayout>
    );
}

export function DisabledStudentsPage() {
    const [meta, setMeta] = useState({});
    const [rows, setRows] = useState([]);
    const [filters, setFilters] = useState({ class: '', section: '' });
    const [err, setErr] = useState('');
    const [loading, setLoading] = useState(false);

    const toList = (value) => {
        if (Array.isArray(value)) return value;
        if (Array.isArray(value?.data)) return value.data;
        return [];
    };

    const loadIndex = () => {
        axios.get('/disabled-students', { headers: xhrJson }).then((r) => {
            setMeta(r.data?.meta || {});
            setRows([]);
        });
    };

    const loadSections = (classId) => {
        if (!classId) return setMeta((m) => ({ ...m, sections: [] }));
        axios.get('/class-setup/get-sections', { headers: xhrJson, params: { id: classId } })
            .then((r) => setMeta((m) => ({ ...m, sections: toList(r.data) })))
            .catch(() => setMeta((m) => ({ ...m, sections: [] })));
    };

    useEffect(() => {
        loadIndex();
    }, []);

    const doSearch = async (e) => {
        e.preventDefault();
        setLoading(true);
        setErr('');
        try {
            const r = await axios.post('/disabled-students/search', filters, { headers: xhrJson });
            setRows(r.data?.data || []);
            setMeta(r.data?.meta || {});
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Failed to search disabled students.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <AdminLayout>
            <div className="mx-auto max-w-7xl p-6">
                <div className="mb-5 rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                    <h1 className="text-2xl font-semibold text-gray-800">{meta.title || 'Disabled Students'}</h1>
                </div>

                <form className="mb-5 grid gap-3 rounded-xl border border-gray-200 bg-white p-4 shadow-sm md:grid-cols-3" onSubmit={doSearch}>
                    <select
                        className="rounded-lg border border-gray-200 px-3 py-2 text-sm"
                        value={filters.class}
                        onChange={(e) => {
                            const v = e.target.value;
                            setFilters((f) => ({ ...f, class: v, section: '' }));
                            loadSections(v);
                        }}
                    >
                        <option value="">Select Class</option>
                        {(meta.classes || []).map((c) => <option key={c?.class?.id || c.id} value={c?.class?.id || c.id}>{c?.class?.name || c.name}</option>)}
                    </select>
                    <select
                        className="rounded-lg border border-gray-200 px-3 py-2 text-sm"
                        value={filters.section}
                        onChange={(e) => setFilters((f) => ({ ...f, section: e.target.value }))}
                    >
                        <option value="">Select Section</option>
                        {(meta.sections || []).map((s) => <option key={s?.section?.id || s.id} value={s?.section?.id || s.id}>{s?.section?.name || s.name}</option>)}
                    </select>
                    <div className="flex justify-end">
                        <button className="rounded-lg bg-blue-600 px-3.5 py-2 text-sm font-medium text-white transition hover:bg-blue-700">Search</button>
                    </div>
                </form>

                {err ? <p className="mb-3 text-sm text-red-600">{err}</p> : null}
                {loading ? <FullPageLoader text="Loading disabled students..." /> : null}
                {!loading ? <div className="overflow-auto rounded-xl border border-gray-200 bg-white shadow-sm">
                    <table className="min-w-full text-sm">
                        <thead className="bg-gray-50">
                        <tr className="border-b border-gray-200">
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Admission No</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Student Name</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Class (Section)</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Guardian</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">DOB</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Gender</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Mobile</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Status</th>
                            <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wide text-gray-600">Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        {rows.map((item) => {
                            const sid = item?.student?.id;
                            const isActive = Number(item?.student?.status) === 1;
                            return (
                                <tr key={sid || `${item?.classes_id}-${item?.section_id}`} className="border-b border-gray-100 transition hover:bg-blue-50/30">
                                    <td className="px-4 py-3 font-medium text-gray-700">{item?.student?.admission_no || '-'}</td>
                                    <td className="px-4 py-3 text-gray-800">{`${item?.student?.first_name || ''} ${item?.student?.last_name || ''}`.trim() || '-'}</td>
                                    <td className="px-4 py-3 text-gray-700">{`${item?.class?.name || '-'} (${item?.section?.name || '-'})`}</td>
                                    <td className="px-4 py-3 text-gray-700">{item?.student?.parent?.guardian_name || '-'}</td>
                                    <td className="px-4 py-3 text-gray-700">{item?.student?.dob || '-'}</td>
                                    <td className="px-4 py-3 text-gray-700">{item?.student?.gender?.name || '-'}</td>
                                    <td className="px-4 py-3 text-gray-700">{item?.student?.mobile_no || item?.student?.mobile || '-'}</td>
                                    <td className="px-4 py-3">
                                        <span className={`inline-flex rounded-full px-2.5 py-1 text-xs font-medium ${isActive ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'}`}>
                                            {isActive ? 'Active' : 'Inactive'}
                                        </span>
                                    </td>
                                    <td className="px-4 py-3">
                                        <div className="flex items-center justify-end gap-2">
                                            <Link to={`/students/${sid}`} className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-gray-200 text-blue-600 transition hover:bg-blue-50" title="View">
                                                <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6z" /><circle cx="12" cy="12" r="3" /></svg>
                                            </Link>
                                            <Link to={`/students/${sid}/edit`} className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-gray-200 text-amber-600 transition hover:bg-amber-50" title="Edit">
                                                <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M12 20h9" /><path strokeLinecap="round" strokeLinejoin="round" d="M16.5 3.5a2.1 2.1 0 113 3L7 19l-4 1 1-4 12.5-12.5z" /></svg>
                                            </Link>
                                        </div>
                                    </td>
                                </tr>
                            );
                        })}
                        </tbody>
                    </table>
                </div> : null}
            </div>
        </AdminLayout>
    );
}
