import React, { useEffect, useMemo, useRef, useState } from 'react';
import axios from 'axios';
import { Link, useNavigate, useParams } from 'react-router-dom';

const xhrJson = { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' };

function FullPageLoader({ text = 'Loading fees data...' }) {
    return (
        <div className="flex min-h-[60vh] items-center justify-center rounded-xl border border-gray-200 bg-white shadow-sm">
            <div className="flex flex-col items-center gap-3">
                <div className="relative h-12 w-12">
                    <span className="absolute inset-0 rounded-full border-4 border-blue-200" />
                    <span className="absolute inset-0 animate-spin rounded-full border-4 border-transparent border-t-blue-600" />
                    <span className="absolute left-1/2 top-1/2 h-2.5 w-2.5 -translate-x-1/2 -translate-y-1/2 animate-ping rounded-full bg-blue-500" />
                </div>
                <p className="text-sm font-medium text-gray-600">{text}</p>
            </div>
        </div>
    );
}

function panelTitle(metaTitle, fallback) {
    return metaTitle || fallback;
}

function optionLabel(item) {
    return item?.name || item?.title || item?.class?.name || item?.group?.name || `#${item?.id ?? '-'}`;
}

function studentsTableClass() {
    return 'overflow-auto rounded-xl border border-gray-200 bg-white shadow-sm';
}

function ActionButtons({ viewTo, editTo, onDelete, busy = false, hideDelete = false }) {
    return (
        <div className="flex items-center justify-end gap-2">
            {viewTo ? (
                <Link to={viewTo} className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-gray-200 text-blue-600 transition hover:bg-blue-50" title="View">
                    <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6z" /><circle cx="12" cy="12" r="3" /></svg>
                </Link>
            ) : null}
            {editTo ? (
                <Link to={editTo} className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-gray-200 text-amber-600 transition hover:bg-amber-50" title="Edit">
                    <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M12 20h9" /><path strokeLinecap="round" strokeLinejoin="round" d="M16.5 3.5a2.1 2.1 0 113 3L7 19l-4 1 1-4 12.5-12.5z" /></svg>
                </Link>
            ) : null}
            {!hideDelete ? (
                <button type="button" disabled={busy} onClick={onDelete} className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-gray-200 text-rose-600 transition hover:bg-rose-50 disabled:opacity-60" title="Delete">
                    <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M3 6h18" /><path strokeLinecap="round" strokeLinejoin="round" d="M8 6V4h8v2" /><path strokeLinecap="round" strokeLinejoin="round" d="M19 6l-1 14H6L5 6" /></svg>
                </button>
            ) : null}
        </div>
    );
}

function EntityListPage({ Layout, title, endpoint, baseRoute, createRoute, deleteEndpoint, columns }) {
    const [rows, setRows] = useState([]);
    const [meta, setMeta] = useState({});
    const [err, setErr] = useState('');
    const [loading, setLoading] = useState(true);
    const [busyId, setBusyId] = useState(null);

    const load = () => {
        setLoading(true);
        setErr('');
        axios.get(endpoint, { headers: xhrJson }).then((r) => {
            setRows(r.data?.data?.data || r.data?.data || []);
            setMeta(r.data?.meta || {});
        }).catch((ex) => setErr(ex.response?.data?.message || 'Failed to load data.')).finally(() => setLoading(false));
    };

    useEffect(() => { load(); }, [endpoint]);

    const remove = async (id) => {
        if (!window.confirm('Delete this item?')) return;
        setBusyId(id);
        setErr('');
        try {
            await axios.delete(`${deleteEndpoint}/${id}`, { headers: xhrJson });
            setRows((prev) => prev.filter((r) => Number(r.id) !== Number(id)));
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Delete failed.');
        } finally {
            setBusyId(null);
        }
    };

    return (
        <Layout>
            <div className="mx-auto max-w-7xl p-6">
                <div className="mb-5 rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                    <div className="flex items-center justify-between">
                        <h1 className="text-2xl font-semibold text-gray-800">{panelTitle(meta?.title, title)}</h1>
                        <Link to={createRoute} className="rounded-lg bg-blue-600 px-3.5 py-2 text-sm font-medium text-white transition hover:bg-blue-700">Create</Link>
                    </div>
                </div>
                {err ? <p className="mb-3 text-sm text-red-600">{err}</p> : null}
                {loading ? <FullPageLoader text={`Loading ${title.toLowerCase()}...`} /> : null}
                {!loading ? <div className={studentsTableClass()}>
                    <table className="min-w-full text-sm">
                        <thead className="bg-gray-50">
                        <tr className="border-b border-gray-200">
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">#</th>
                            {columns.map((c) => <th key={c.key} className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">{c.label}</th>)}
                            <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wide text-gray-600">Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        {rows.map((row, idx) => (
                            <tr key={row.id || idx} className="border-b border-gray-100 transition hover:bg-blue-50/30">
                                <td className="px-4 py-3 font-medium text-gray-700">{idx + 1}</td>
                                {columns.map((c) => <td key={c.key} className="px-4 py-3 text-gray-800">{c.render ? c.render(row) : (row?.[c.key] ?? '-')}</td>)}
                                <td className="px-4 py-3">
                                    <ActionButtons
                                        viewTo={`${baseRoute}/${row.id}`}
                                        editTo={`${baseRoute}/${row.id}/edit`}
                                        onDelete={() => remove(row.id)}
                                        busy={busyId === row.id}
                                    />
                                </td>
                            </tr>
                        ))}
                        </tbody>
                    </table>
                </div> : null}
            </div>
        </Layout>
    );
}

function EntityViewPage({ Layout, title, loadEndpoint, backTo, editBase }) {
    const { id } = useParams();
    const [data, setData] = useState(null);
    const [err, setErr] = useState('');
    const [loading, setLoading] = useState(true);
    useEffect(() => {
        setLoading(true);
        axios.get(`${loadEndpoint}/edit/${id}`, { headers: xhrJson }).then((r) => {
            setData(r.data?.data || {});
        }).catch((ex) => setErr(ex.response?.data?.message || 'Failed to load data.')).finally(() => setLoading(false));
    }, [id, loadEndpoint]);

    return (
        <Layout>
            <div className="mx-auto max-w-5xl p-6">
                <div className="mb-5 rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                    <h1 className="text-2xl font-semibold text-gray-800">{title}</h1>
                </div>
                {loading ? <FullPageLoader text="Loading details..." /> : null}
                {err ? <p className="mb-3 text-sm text-red-600">{err}</p> : null}
                {!loading ? <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
                    <dl className="grid gap-3 text-sm md:grid-cols-2">
                        {Object.entries(data || {}).map(([k, v]) => (
                            <div key={k}>
                                <dt className="text-xs font-semibold uppercase tracking-wide text-gray-500">{k.replaceAll('_', ' ')}</dt>
                                <dd className="mt-1 text-gray-800">{typeof v === 'object' ? JSON.stringify(v) : String(v ?? '-')}</dd>
                            </div>
                        ))}
                    </dl>
                    <div className="mt-4 flex justify-end gap-2 border-t border-gray-100 pt-3">
                        <Link to={backTo} className="rounded-lg border border-gray-200 px-3.5 py-2 text-sm font-medium text-gray-700 transition hover:bg-gray-50">Back</Link>
                        <Link to={`${editBase}/${id}/edit`} className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-blue-700">Edit</Link>
                    </div>
                </div> : null}
            </div>
        </Layout>
    );
}

function statusChoices() {
    return (
        <>
            <option value="1">Active</option>
            <option value="2">Inactive</option>
        </>
    );
}

function FeesEntityFormPage({ Layout, edit = false, titleCreate, titleEdit, loadUrl, createUrl, updateUrl, backTo, fields }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [meta, setMeta] = useState({});
    const [form, setForm] = useState({});
    const [err, setErr] = useState('');
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        setLoading(true);
        const url = edit ? `${loadUrl}/edit/${id}` : `${loadUrl}/create`;
        axios.get(url, { headers: xhrJson }).then((r) => {
            setMeta(r.data?.meta || {});
            if (edit) setForm(r.data?.data || {});
            else setForm((f) => ({ status: '1', ...f }));
        }).catch((ex) => setErr(ex.response?.data?.message || 'Failed to load form.')).finally(() => setLoading(false));
    }, [edit, id, loadUrl]);

    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        setSaving(true);
        try {
            if (edit) await axios.put(`${updateUrl}/${id}`, form, { headers: xhrJson });
            else await axios.post(createUrl, form, { headers: xhrJson });
            nav(backTo);
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Save failed.');
        } finally {
            setSaving(false);
        }
    };

    return (
        <Layout>
            <div className="mx-auto max-w-6xl p-6">
                <div className="mb-5 rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                    <h1 className="text-2xl font-semibold text-gray-800">{edit ? titleEdit : titleCreate}</h1>
                </div>
                {err ? <p className="mb-3 text-sm text-red-600">{err}</p> : null}
                {loading ? <FullPageLoader text="Loading form..." /> : null}
                {!loading ? <form onSubmit={submit} className="grid gap-4 rounded-xl border border-gray-200 bg-white p-5 shadow-sm md:grid-cols-2">
                    {fields({ meta, form, setForm, statusChoices })}
                    <div className="md:col-span-2 flex justify-end gap-2 border-t border-gray-100 pt-3">
                        <Link to={backTo} className="rounded-lg border border-gray-200 px-3.5 py-2 text-sm font-medium text-gray-700 transition hover:bg-gray-50">Cancel</Link>
                        <button disabled={saving} className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-blue-700 disabled:opacity-60">{saving ? 'Saving...' : (edit ? 'Update' : 'Create')}</button>
                    </div>
                </form> : null}
            </div>
        </Layout>
    );
}

export function FeesGroupsPage({ Layout }) {
    return <EntityListPage Layout={Layout} title="Fees Groups" endpoint="/fees-group" baseRoute="/fees/groups" createRoute="/fees/groups/create" deleteEndpoint="/fees-group/delete" columns={[
        { key: 'name', label: 'Name', render: (r) => r?.name || r?.title || '-' },
        { key: 'description', label: 'Description', render: (r) => r?.description || '-' },
        { key: 'status', label: 'Status', render: (r) => Number(r?.status) === 1 ? 'Active' : 'Inactive' },
    ]} />;
}

export function FeesGroupViewPage({ Layout }) {
    return <EntityViewPage Layout={Layout} title="Fees Group Details" loadEndpoint="/fees-group" backTo="/fees/groups" editBase="/fees/groups" />;
}

export function FeesGroupFormPage({ Layout, edit = false }) {
    return (
        <FeesEntityFormPage
            Layout={Layout}
            edit={edit}
            titleCreate="Create Fees Group"
            titleEdit="Edit Fees Group"
            loadUrl="/fees-group"
            createUrl="/fees-group/store"
            updateUrl="/fees-group/update"
            backTo="/fees/groups"
            fields={({ form, setForm, statusChoices }) => (
                <>
                    <input className="rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="Name" value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
                    <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={String(form.status || '1')} onChange={(e) => setForm({ ...form, status: e.target.value })}>{statusChoices()}</select>
                    <textarea className="rounded-lg border border-gray-200 px-3 py-2 text-sm md:col-span-2" rows={3} placeholder="Description" value={form.description || ''} onChange={(e) => setForm({ ...form, description: e.target.value })} />
                    <label className="inline-flex items-center gap-2 text-sm text-gray-700 md:col-span-2">
                        <input type="checkbox" checked={String(form.online_admission_fees || '0') === '1'} onChange={(e) => setForm({ ...form, online_admission_fees: e.target.checked ? 1 : 0 })} />
                        Online Admission Fees
                    </label>
                </>
            )}
        />
    );
}

export function FeesTypesPage({ Layout }) {
    return <EntityListPage Layout={Layout} title="Fees Types" endpoint="/fees-type" baseRoute="/fees/types" createRoute="/fees/types/create" deleteEndpoint="/fees-type/delete" columns={[
        { key: 'name', label: 'Name', render: (r) => r?.name || '-' },
        { key: 'code', label: 'Code', render: (r) => r?.code || '-' },
        { key: 'status', label: 'Status', render: (r) => Number(r?.status) === 1 ? 'Active' : 'Inactive' },
    ]} />;
}

export function FeesTypeViewPage({ Layout }) {
    return <EntityViewPage Layout={Layout} title="Fees Type Details" loadEndpoint="/fees-type" backTo="/fees/types" editBase="/fees/types" />;
}

export function FeesTypeFormPage({ Layout, edit = false }) {
    return (
        <FeesEntityFormPage
            Layout={Layout}
            edit={edit}
            titleCreate="Create Fees Type"
            titleEdit="Edit Fees Type"
            loadUrl="/fees-type"
            createUrl="/fees-type/store"
            updateUrl="/fees-type/update"
            backTo="/fees/types"
            fields={({ meta, form, setForm, statusChoices }) => (
                <>
                    <input className="rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="Name" value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
                    <input className="rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="Code" value={form.code || ''} onChange={(e) => setForm({ ...form, code: e.target.value })} />
                    <textarea className="rounded-lg border border-gray-200 px-3 py-2 text-sm md:col-span-2" rows={3} placeholder="Description" value={form.description || ''} onChange={(e) => setForm({ ...form, description: e.target.value })} />
                    <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={String(form.class_id || '0')} onChange={(e) => setForm({ ...form, class_id: e.target.value })}>
                        <option value="0">None</option>
                        {(meta.classes || []).map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                    </select>
                    <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={String(form.status || '1')} onChange={(e) => setForm({ ...form, status: e.target.value })}>{statusChoices()}</select>
                </>
            )}
        />
    );
}

export function FeesMastersPage({ Layout }) {
    return <EntityListPage Layout={Layout} title="Fees Masters" endpoint="/fees-master" baseRoute="/fees/masters" createRoute="/fees/masters/create" deleteEndpoint="/fees-master/delete" columns={[
        { key: 'fees_group', label: 'Fees Group', render: (r) => r?.group?.name || r?.fees_group?.name || '-' },
        { key: 'fees_type', label: 'Fees Type', render: (r) => r?.type?.name || r?.fees_type?.name || '-' },
        { key: 'amount', label: 'Amount', render: (r) => r?.amount || '-' },
        { key: 'due_date', label: 'Due Date', render: (r) => r?.due_date || '-' },
    ]} />;
}

export function FeesMasterViewPage({ Layout }) {
    return <EntityViewPage Layout={Layout} title="Fees Master Details" loadEndpoint="/fees-master" backTo="/fees/masters" editBase="/fees/masters" />;
}

export function FeesMasterFormPage({ Layout, edit = false }) {
    return (
        <FeesEntityFormPage
            Layout={Layout}
            edit={edit}
            titleCreate="Create Fees Master"
            titleEdit="Edit Fees Master"
            loadUrl="/fees-master"
            createUrl="/fees-master/store"
            updateUrl="/fees-master/update"
            backTo="/fees/masters"
            fields={({ meta, form, setForm, statusChoices }) => (
                <>
                    <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={form.fees_group_id || ''} onChange={(e) => setForm({ ...form, fees_group_id: e.target.value })} required>
                        <option value="">Select Fees Group</option>
                        {(meta.fees_groups || []).map((g) => <option key={g.id} value={g.id}>{optionLabel(g)}</option>)}
                    </select>
                    <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={form.fees_type_id || ''} onChange={(e) => setForm({ ...form, fees_type_id: e.target.value })} required>
                        <option value="">Select Fees Type</option>
                        {(meta.fees_types || []).map((t) => <option key={t.id} value={t.id}>{optionLabel(t)}</option>)}
                    </select>
                    <input type="date" className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={form.due_date || ''} onChange={(e) => setForm({ ...form, due_date: e.target.value })} />
                    <input type="number" className="rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="Amount" value={form.amount || ''} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
                    <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={String(form.fine_type || '1')} onChange={(e) => setForm({ ...form, fine_type: e.target.value })}>
                        <option value="1">None</option>
                        <option value="2">Percentage</option>
                        <option value="3">Fixed Amount</option>
                    </select>
                    <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={String(form.status || '1')} onChange={(e) => setForm({ ...form, status: e.target.value })}>{statusChoices()}</select>
                    <input type="number" className="rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="Percentage" value={form.percentage || 0} onChange={(e) => setForm({ ...form, percentage: e.target.value })} />
                    <input type="number" className="rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="Fine Amount" value={form.fine_amount || 0} onChange={(e) => setForm({ ...form, fine_amount: e.target.value })} />
                </>
            )}
        />
    );
}

export function FeesAssignmentsPage({ Layout }) {
    return <EntityListPage Layout={Layout} title="Fees Assignments" endpoint="/fees-assign" baseRoute="/fees/assignments" createRoute="/fees/assignments/create" deleteEndpoint="/fees-assign/delete" columns={[
        { key: 'fees_group', label: 'Fees Group', render: (r) => r?.group?.name || r?.fees_group?.name || '-' },
        { key: 'class', label: 'Class', render: (r) => r?.class?.name || '-' },
        { key: 'session', label: 'Session', render: (r) => r?.session?.name || '-' },
        { key: 'status', label: 'Status', render: (r) => Number(r?.status) === 1 ? 'Active' : 'Inactive' },
    ]} />;
}

export function FeesAssignmentViewPage({ Layout }) {
    return <EntityViewPage Layout={Layout} title="Fees Assignment Details" loadEndpoint="/fees-assign" backTo="/fees/assignments" editBase="/fees/assignments" />;
}

export function FeesAssignmentFormPage({ Layout, edit = false }) {
    const { id } = useParams();
    const nav = useNavigate();
    const editStudentsSyncedRef = useRef(false);
    const [meta, setMeta] = useState({});
    const [form, setForm] = useState({
        fees_group: '',
        class: '',
        category: '',
        fees_master_ids: [],
        student_ids: [],
    });
    const [err, setErr] = useState('');
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [mastersLoading, setMastersLoading] = useState(false);
    const [studentsLoading, setStudentsLoading] = useState(false);
    const [studentRows, setStudentRows] = useState([]);
    const [masters, setMasters] = useState([]);

    useEffect(() => {
        editStudentsSyncedRef.current = false;
    }, [edit, id]);

    useEffect(() => {
        setLoading(true);
        const url = edit ? `/fees-assign/edit/${id}` : '/fees-assign/create';
        axios.get(url, { headers: xhrJson }).then((r) => {
            const m = r.data?.meta || {};
            setMeta(m);
            if (edit) {
                const d = r.data?.data || {};
                const assignedMasters = (m?.assigned_fes_masters || []).map((x) => Number(x));
                setForm({
                    fees_group: String(d?.fees_group_id ?? ''),
                    class: String(d?.classes_id ?? ''),
                    category: '',
                    fees_master_ids: assignedMasters,
                    student_ids: [],
                });
            } else {
                setForm({
                    fees_group: '',
                    class: '',
                    category: '',
                    fees_master_ids: [],
                    student_ids: [],
                });
            }
        }).catch((ex) => setErr(ex.response?.data?.message || 'Failed to load form.')).finally(() => setLoading(false));
    }, [edit, id]);

    useEffect(() => {
        if (!form.fees_group) {
            setMasters([]);
            return;
        }
        setMastersLoading(true);
        axios
            .get('/fees-assign/get-all-type', { headers: xhrJson, params: { id: form.fees_group } })
            .then((r) => setMasters(r.data?.data || []))
            .catch(() => setMasters([]))
            .finally(() => setMastersLoading(false));
    }, [form.fees_group]);

    useEffect(() => {
        if (!form.class) {
            setStudentRows([]);
            return;
        }
        setStudentsLoading(true);
        const params = { class: form.class };
        if (form.category) params.category = form.category;
        if (edit && id) params.fees_assign_id = id;
        axios
            .get('/fees-assign/get-fees-assign-students', { headers: xhrJson, params })
            .then((r) => {
                const rows = r.data?.data || [];
                setStudentRows(rows);
                const assigned = (r.data?.meta?.assigned_student_ids || []).map(Number);
                if (edit && id && !editStudentsSyncedRef.current) {
                    setForm((f) => ({ ...f, student_ids: assigned }));
                    editStudentsSyncedRef.current = true;
                }
            })
            .catch(() => setStudentRows([]))
            .finally(() => setStudentsLoading(false));
    }, [form.class, form.category, edit, id]);

    const selectedStudentCount = useMemo(() => (form.student_ids || []).length, [form.student_ids]);

    const toggleStudent = (studentTableId, checked) => {
        const sid = Number(studentTableId);
        setForm((f) => ({
            ...f,
            student_ids: checked
                ? [...new Set([...(f.student_ids || []), sid])]
                : (f.student_ids || []).filter((x) => Number(x) !== sid),
        }));
    };

    const toggleAllVisibleStudents = (checked) => {
        const visibleIds = studentRows.map((row) => Number(row.student_id));
        setForm((f) => {
            const cur = (f.student_ids || []).map(Number);
            if (checked) {
                return { ...f, student_ids: [...new Set([...cur, ...visibleIds])] };
            }
            return { ...f, student_ids: cur.filter((sid) => !visibleIds.includes(sid)) };
        });
    };

    const visibleAllSelected =
        studentRows.length > 0 &&
        studentRows.every((row) => (form.student_ids || []).map(Number).includes(Number(row.student_id)));

    const toggleFeesMaster = (masterId, checked) => {
        const mid = Number(masterId);
        setForm((f) => ({
            ...f,
            fees_master_ids: checked
                ? [...new Set([...(f.fees_master_ids || []), mid])]
                : (f.fees_master_ids || []).filter((x) => Number(x) !== mid),
        }));
    };

    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        const feesMasterIds = (form.fees_master_ids || []).map(Number).filter((n) => !Number.isNaN(n));
        const studentIds = (form.student_ids || []).map(Number).filter((n) => !Number.isNaN(n));
        if (feesMasterIds.length === 0) {
            setErr('Please select at least one fees type.');
            return;
        }
        if (studentIds.length === 0) {
            setErr('Please select at least one student.');
            return;
        }
        setSaving(true);
        try {
            const payload = {
                fees_group: form.fees_group,
                class: form.class,
                fees_master_ids: feesMasterIds,
                student_ids: studentIds,
            };
            if (edit) await axios.put(`/fees-assign/update/${id}`, payload, { headers: xhrJson });
            else await axios.post('/fees-assign/store', payload, { headers: xhrJson });
            nav('/fees/assignments');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Save failed.');
        } finally {
            setSaving(false);
        }
    };

    return (
        <Layout>
            <div className="mx-auto max-w-7xl p-6">
                <div className="mb-5 rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                    <h1 className="text-2xl font-semibold text-gray-800">{edit ? 'Edit Fees Assignment' : 'Create Fees Assignment'}</h1>
                </div>
                {err ? <p className="mb-3 text-sm text-red-600">{err}</p> : null}
                {loading ? <FullPageLoader text="Loading assignment form..." /> : null}
                {!loading ? (
                    <form onSubmit={submit} className="space-y-4">
                        <div className="grid gap-3 rounded-xl border border-gray-200 bg-white p-4 shadow-sm md:grid-cols-3">
                            <select
                                className="rounded-lg border border-gray-200 px-3 py-2 text-sm"
                                value={form.fees_group}
                                onChange={(e) =>
                                    setForm((f) => ({
                                        ...f,
                                        fees_group: e.target.value,
                                        fees_master_ids: [],
                                    }))
                                }
                                required
                            >
                                <option value="">Select Fees Group</option>
                                {(meta.fees_groups || []).map((g) => (
                                    <option key={g?.group?.id || g.id} value={g?.group?.id || g.id}>
                                        {g?.group?.name || g.name}
                                    </option>
                                ))}
                            </select>
                            <select
                                className="rounded-lg border border-gray-200 px-3 py-2 text-sm"
                                value={form.class}
                                onChange={(e) =>
                                    setForm((f) => ({
                                        ...f,
                                        class: e.target.value,
                                        student_ids: edit ? f.student_ids : [],
                                    }))
                                }
                                required
                            >
                                <option value="">Select Class</option>
                                {(meta.classes || []).map((c) => (
                                    <option key={c?.class?.id || c.classes_id || c.id} value={c?.class?.id || c.classes_id || c.id}>
                                        {c?.class?.name || c.name}
                                    </option>
                                ))}
                            </select>
                            <select
                                className="rounded-lg border border-gray-200 px-3 py-2 text-sm"
                                value={form.category}
                                onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}
                            >
                                <option value="">All categories</option>
                                {(meta.categories || []).map((cat) => (
                                    <option key={cat.id} value={cat.id}>
                                        {cat.name}
                                    </option>
                                ))}
                            </select>
                        </div>
                        <div className="grid gap-4 lg:grid-cols-2">
                            <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                                <p className="mb-2 text-sm font-semibold text-gray-700">Fees types</p>
                                {mastersLoading ? <p className="text-sm text-gray-500">Loading fees types…</p> : null}
                                {!mastersLoading && masters.length === 0 ? (
                                    <p className="text-sm text-gray-500">Select a fees group to load types.</p>
                                ) : null}
                                {!mastersLoading && masters.length > 0 ? (
                                    <div className={studentsTableClass()}>
                                        <table className="min-w-full text-sm">
                                            <thead className="bg-gray-50">
                                                <tr className="border-b border-gray-200">
                                                    <th className="px-3 py-2 text-left text-xs font-semibold uppercase text-gray-600"> </th>
                                                    <th className="px-3 py-2 text-left text-xs font-semibold uppercase text-gray-600">Name</th>
                                                    <th className="px-3 py-2 text-right text-xs font-semibold uppercase text-gray-600">Amount</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {masters.map((m) => {
                                                    const checked = (form.fees_master_ids || []).map(Number).includes(Number(m.id));
                                                    return (
                                                        <tr key={m.id} className="border-b border-gray-100">
                                                            <td className="px-3 py-2">
                                                                <input
                                                                    type="checkbox"
                                                                    checked={checked}
                                                                    onChange={(e) => toggleFeesMaster(m.id, e.target.checked)}
                                                                />
                                                            </td>
                                                            <td className="px-3 py-2 text-gray-800">{m?.type?.name || optionLabel(m)}</td>
                                                            <td className="px-3 py-2 text-right text-gray-800">{m?.amount ?? '-'}</td>
                                                        </tr>
                                                    );
                                                })}
                                            </tbody>
                                        </table>
                                    </div>
                                ) : null}
                            </div>
                            <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                                <p className="mb-2 text-sm font-semibold text-gray-700">
                                    Students ({selectedStudentCount} selected)
                                </p>
                                {studentsLoading ? <p className="text-sm text-gray-500">Loading students…</p> : null}
                                {!studentsLoading && !form.class ? (
                                    <p className="text-sm text-gray-500">Select a class to load students.</p>
                                ) : null}
                                {!studentsLoading && form.class && studentRows.length === 0 ? (
                                    <p className="text-sm text-gray-500">No students found for this class.</p>
                                ) : null}
                                {!studentsLoading && studentRows.length > 0 ? (
                                    <div className={`${studentsTableClass()} max-h-[28rem]`}>
                                        <table className="min-w-full text-sm">
                                            <thead className="sticky top-0 bg-gray-50">
                                                <tr className="border-b border-gray-200">
                                                    <th className="px-3 py-2 text-left text-xs font-semibold uppercase text-gray-600">
                                                        <input
                                                            type="checkbox"
                                                            checked={visibleAllSelected}
                                                            onChange={(e) => toggleAllVisibleStudents(e.target.checked)}
                                                            title="Select all visible"
                                                        />
                                                    </th>
                                                    <th className="px-3 py-2 text-left text-xs font-semibold uppercase text-gray-600">Admission</th>
                                                    <th className="px-3 py-2 text-left text-xs font-semibold uppercase text-gray-600">Name</th>
                                                    <th className="px-3 py-2 text-left text-xs font-semibold uppercase text-gray-600">Class</th>
                                                    <th className="px-3 py-2 text-left text-xs font-semibold uppercase text-gray-600">Guardian</th>
                                                    <th className="px-3 py-2 text-left text-xs font-semibold uppercase text-gray-600">Mobile</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {studentRows.map((row) => {
                                                    const sid = Number(row.student_id);
                                                    const st = row.student;
                                                    const checked = (form.student_ids || []).map(Number).includes(sid);
                                                    const name = st
                                                        ? `${st.first_name || ''} ${st.last_name || ''}`.trim()
                                                        : `Student #${sid}`;
                                                    return (
                                                        <tr key={`${row.id}-${sid}`} className="border-b border-gray-100">
                                                            <td className="px-3 py-2">
                                                                <input
                                                                    type="checkbox"
                                                                    checked={checked}
                                                                    onChange={(e) => toggleStudent(sid, e.target.checked)}
                                                                />
                                                            </td>
                                                            <td className="px-3 py-2 text-gray-800">{st?.admission_no ?? '-'}</td>
                                                            <td className="px-3 py-2 text-gray-800">{name}</td>
                                                            <td className="px-3 py-2 text-gray-800">{row?.class?.name ?? '-'}</td>
                                                            <td className="px-3 py-2 text-gray-800">{st?.parent?.guardian_name ?? '-'}</td>
                                                            <td className="px-3 py-2 text-gray-800">{st?.mobile ?? '-'}</td>
                                                        </tr>
                                                    );
                                                })}
                                            </tbody>
                                        </table>
                                    </div>
                                ) : null}
                            </div>
                        </div>
                        <div className="flex justify-end gap-2 border-t border-gray-100 pt-3">
                            <Link
                                to="/fees/assignments"
                                className="rounded-lg border border-gray-200 px-3.5 py-2 text-sm font-medium text-gray-700 transition hover:bg-gray-50"
                            >
                                Cancel
                            </Link>
                            <button
                                disabled={saving}
                                className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-blue-700 disabled:opacity-60"
                            >
                                {saving ? 'Saving...' : edit ? 'Update' : 'Create'}
                            </button>
                        </div>
                    </form>
                ) : null}
            </div>
        </Layout>
    );
}

export function FeesCollectionsPage({ Layout }) {
    return <EntityListPage Layout={Layout} title="Fees Collections" endpoint="/fees-collect" baseRoute="/fees/collections" createRoute="/fees/collections/create" deleteEndpoint="/fees-collect/delete" columns={[
        { key: 'student', label: 'Student', render: (r) => r?.student_name || r?.student?.full_name || r?.student?.first_name || '-' },
        { key: 'class', label: 'Class', render: (r) => r?.class?.name || '-' },
        { key: 'amount', label: 'Amount', render: (r) => r?.paid_amount || r?.amount || '-' },
        { key: 'date', label: 'Date', render: (r) => r?.date || '-' },
    ]} />;
}

export function FeesCollectionViewPage({ Layout }) {
    return <EntityViewPage Layout={Layout} title="Fees Collection Details" loadEndpoint="/fees-collect" backTo="/fees/collections" editBase="/fees/collections" />;
}

export function FeesCollectionEditPage({ Layout }) {
    const { id } = useParams();
    const nav = useNavigate();
    const [form, setForm] = useState({});
    const [err, setErr] = useState('');
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        setLoading(true);
        axios.get(`/fees-collect/edit/${id}`, { headers: xhrJson }).then((r) => setForm(r.data?.data || {})).catch((ex) => setErr(ex.response?.data?.message || 'Failed to load data.')).finally(() => setLoading(false));
    }, [id]);

    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        setSaving(true);
        try {
            await axios.put(`/fees-collect/update/${id}`, form, { headers: xhrJson });
            nav('/fees/collections');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Update failed.');
        } finally {
            setSaving(false);
        }
    };

    return (
        <Layout>
            <div className="mx-auto max-w-5xl p-6">
                <div className="mb-5 rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                    <h1 className="text-2xl font-semibold text-gray-800">Edit Fees Collection</h1>
                </div>
                {err ? <p className="mb-3 text-sm text-red-600">{err}</p> : null}
                {loading ? <FullPageLoader text="Loading collection..." /> : null}
                {!loading ? <form onSubmit={submit} className="grid gap-4 rounded-xl border border-gray-200 bg-white p-5 shadow-sm md:grid-cols-2">
                    <input type="number" className="rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="Paid Amount" value={form.paid_amount || ''} onChange={(e) => setForm({ ...form, paid_amount: e.target.value })} />
                    <input type="number" className="rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="Remained Amount" value={form.remained_amount || ''} onChange={(e) => setForm({ ...form, remained_amount: e.target.value })} />
                    <div className="md:col-span-2 flex justify-end gap-2 border-t border-gray-100 pt-3">
                        <Link to="/fees/collections" className="rounded-lg border border-gray-200 px-3.5 py-2 text-sm font-medium text-gray-700 transition hover:bg-gray-50">Cancel</Link>
                        <button disabled={saving} className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-blue-700 disabled:opacity-60">{saving ? 'Saving...' : 'Update'}</button>
                    </div>
                </form> : null}
            </div>
        </Layout>
    );
}

function normalizeFeesTransactionRows(payload) {
    if (payload == null) return [];
    if (Array.isArray(payload)) return payload;
    if (typeof payload === 'object' && Array.isArray(payload.data)) return payload.data;
    return [];
}

function TransactionsListPage({ Layout, title, endpoint, variant = 'cash', canCancelPush = false }) {
    const [rows, setRows] = useState([]);
    const [meta, setMeta] = useState({});
    const [loading, setLoading] = useState(true);
    const [err, setErr] = useState('');
    const [busyId, setBusyId] = useState(null);
    const [page, setPage] = useState(1);

    const load = (pageNum = 1) => {
        setLoading(true);
        setErr('');
        const params = {};
        if (variant === 'cash' && pageNum > 1) params.page = pageNum;
        axios
            .get(endpoint, { headers: xhrJson, params })
            .then((r) => {
                const normalized = normalizeFeesTransactionRows(r.data?.data);
                setRows(normalized);
                setMeta(r.data?.meta || {});
                setPage(pageNum);
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load transactions.'))
            .finally(() => setLoading(false));
    };

    useEffect(() => {
        setPage(1);
        load(1);
    }, [endpoint, variant]);

    const onCancelPush = async (id) => {
        if (!window.confirm('Cancel this push transaction?')) return;
        setBusyId(id);
        try {
            await axios.post(`/fees-collect/cancel-push-transaction/${id}`, {}, { headers: xhrJson });
            load(page);
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Failed to cancel transaction.');
        } finally {
            setBusyId(null);
        }
    };

    const pg = meta?.pagination;
    const studentName = (r) => {
        const fn = r?.first_name || r?.student?.first_name || '';
        const ln = r?.last_name || r?.student?.last_name || '';
        const s = `${fn} ${ln}`.trim();
        return s || r?.student_name || '-';
    };

    const receiptId = (r) => r?.fees_collect_id || r?.id;

    return (
        <Layout>
            <div className="mx-auto max-w-7xl p-6">
                <div className="mb-5 rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                    <h1 className="text-2xl font-semibold text-gray-800">{panelTitle(meta?.title, title)}</h1>
                </div>
                {err ? <p className="mb-3 text-sm text-red-600">{err}</p> : null}
                {loading ? <FullPageLoader text={`Loading ${title.toLowerCase()}...`} /> : null}
                {!loading ? (
                    <div className="space-y-4">
                        <div className={studentsTableClass()}>
                            <table className="min-w-full text-sm">
                                <thead className="bg-gray-50">
                                    <tr className="border-b border-gray-200">
                                        <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">#</th>
                                        {variant === 'cash' ? (
                                            <>
                                                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Note</th>
                                                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Student</th>
                                                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Fee type</th>
                                                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Date</th>
                                                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Amount</th>
                                                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Bank</th>
                                            </>
                                        ) : null}
                                        {variant === 'online' ? (
                                            <>
                                                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Receipt</th>
                                                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Student</th>
                                                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Settlement</th>
                                                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Date</th>
                                                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Amount</th>
                                                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Bank</th>
                                            </>
                                        ) : null}
                                        {variant === 'amendments' ? (
                                            <>
                                                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Student</th>
                                                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Amendment</th>
                                                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Promise date</th>
                                                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Paid</th>
                                                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Remained</th>
                                            </>
                                        ) : null}
                                        <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wide text-gray-600">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {rows.map((r, idx) => (
                                        <tr key={receiptId(r) || r?.fees_assign_children_id || idx} className="border-b border-gray-100 transition hover:bg-blue-50/30">
                                            <td className="px-4 py-3 text-gray-700">{idx + 1 + (pg ? (pg.current_page - 1) * pg.per_page : 0)}</td>
                                            {variant === 'cash' ? (
                                                <>
                                                    <td className="px-4 py-3 text-gray-800">{r?.comments ?? '—'}</td>
                                                    <td className="px-4 py-3 text-gray-800">{studentName(r)}</td>
                                                    <td className="px-4 py-3 text-gray-800">{r?.fees_type_name ?? '—'}</td>
                                                    <td className="px-4 py-3 text-gray-800">{r?.transaction_date ?? r?.created_at ?? '—'}</td>
                                                    <td className="px-4 py-3 text-gray-800">{r?.transaction_amount ?? r?.amount ?? '—'}</td>
                                                    <td className="px-4 py-3 text-gray-800">
                                                        {[r?.bank_name, r?.account_number].filter(Boolean).join(' ') || '—'}
                                                    </td>
                                                </>
                                            ) : null}
                                            {variant === 'online' ? (
                                                <>
                                                    <td className="px-4 py-3 text-gray-800">{r?.payment_receipt ?? '—'}</td>
                                                    <td className="px-4 py-3 text-gray-800">{studentName(r)}</td>
                                                    <td className="px-4 py-3 text-gray-800">{r?.settlement_receipt ?? '—'}</td>
                                                    <td className="px-4 py-3 text-gray-800">{r?.transaction_date ?? '—'}</td>
                                                    <td className="px-4 py-3 text-gray-800">{r?.transaction_amount ?? '—'}</td>
                                                    <td className="px-4 py-3 text-gray-800">
                                                        {[r?.bank_name, r?.account_number].filter(Boolean).join(' ') || '—'}
                                                    </td>
                                                </>
                                            ) : null}
                                            {variant === 'amendments' ? (
                                                <>
                                                    <td className="px-4 py-3 text-gray-800">{studentName(r)}</td>
                                                    <td className="px-4 py-3 text-gray-800">
                                                        {[r?.parent_name, r?.description].filter(Boolean).join(' — ') || '—'}
                                                    </td>
                                                    <td className="px-4 py-3 text-gray-800">{r?.date ?? '—'}</td>
                                                    <td className="px-4 py-3 text-gray-800">{r?.paid_amount ?? '—'}</td>
                                                    <td className="px-4 py-3 text-gray-800">{r?.remained_amount ?? r?.transaction_amount ?? '—'}</td>
                                                </>
                                            ) : null}
                                            <td className="px-4 py-3">
                                                <div className="flex items-center justify-end gap-2">
                                                    {variant === 'amendments' && r?.student_id ? (
                                                        <a
                                                            href={`/fees-collect/collect/${r.student_id}`}
                                                            className="rounded-lg border border-gray-200 px-2 py-1 text-xs font-medium text-blue-600 transition hover:bg-blue-50"
                                                        >
                                                            Collect
                                                        </a>
                                                    ) : null}
                                                    {variant === 'cash' && receiptId(r) ? (
                                                        <a
                                                            href={`/fees-collect/printTransactionReceipt/${receiptId(r)}`}
                                                            className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-gray-200 text-blue-600 transition hover:bg-blue-50"
                                                            title="Receipt"
                                                        >
                                                            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M6 9V2h12v7" /><path strokeLinecap="round" strokeLinejoin="round" d="M6 18h12v4H6z" /><path strokeLinecap="round" strokeLinejoin="round" d="M6 14H4a2 2 0 01-2-2v-2a2 2 0 012-2h16a2 2 0 012 2v2a2 2 0 01-2 2h-2" /></svg>
                                                        </a>
                                                    ) : null}
                                                    {canCancelPush && receiptId(r) ? (
                                                        <button
                                                            type="button"
                                                            disabled={busyId === receiptId(r)}
                                                            onClick={() => onCancelPush(receiptId(r))}
                                                            className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-gray-200 text-rose-600 transition hover:bg-rose-50 disabled:opacity-60"
                                                            title="Cancel push"
                                                        >
                                                            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
                                                        </button>
                                                    ) : null}
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                        {pg && pg.last_page > 1 ? (
                            <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-gray-200 bg-white px-4 py-3 text-sm text-gray-600 shadow-sm">
                                <span>
                                    Page {pg.current_page} of {pg.last_page} ({pg.total} total)
                                </span>
                                <div className="flex gap-2">
                                    <button
                                        type="button"
                                        disabled={pg.current_page <= 1 || loading}
                                        className="rounded-lg border border-gray-200 px-3 py-1.5 font-medium transition hover:bg-gray-50 disabled:opacity-50"
                                        onClick={() => load(pg.current_page - 1)}
                                    >
                                        Previous
                                    </button>
                                    <button
                                        type="button"
                                        disabled={pg.current_page >= pg.last_page || loading}
                                        className="rounded-lg border border-gray-200 px-3 py-1.5 font-medium transition hover:bg-gray-50 disabled:opacity-50"
                                        onClick={() => load(pg.current_page + 1)}
                                    >
                                        Next
                                    </button>
                                </div>
                            </div>
                        ) : null}
                    </div>
                ) : null}
            </div>
        </Layout>
    );
}

export function FeesTransactionsPage({ Layout }) {
    return <TransactionsListPage Layout={Layout} title="Fees Transactions" endpoint="/fees-collect/collect-list" variant="cash" />;
}

export function FeesOnlineTransactionsPage({ Layout }) {
    return <TransactionsListPage Layout={Layout} title="Online Transactions" endpoint="/fees-collect/collect-transactions" variant="online" canCancelPush />;
}

export function FeesAmendmentsPage({ Layout }) {
    return <TransactionsListPage Layout={Layout} title="Amendments" endpoint="/fees-collect/collect-amendment" variant="amendments" />;
}

