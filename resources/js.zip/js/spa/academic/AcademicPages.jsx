import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link, useNavigate, useParams } from 'react-router-dom';

const xhrJson = { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' };

function FullPageLoader({ text = 'Loading...' }) {
    return (
        <div className="flex min-h-[60vh] items-center justify-center rounded-xl border border-gray-200 bg-white shadow-sm">
            <div className="flex flex-col items-center gap-3">
                <div className="relative h-12 w-12">
                    <span className="absolute inset-0 rounded-full border-4 border-blue-200" />
                    <span className="absolute inset-0 animate-spin rounded-full border-4 border-transparent border-t-blue-600" />
                    <span className="absolute left-1/2 top-1/2 h-2.5 w-2.5 -translate-x-1/2 -translate-y-1/2 animate-ping rounded-full bg-blue-500" />
                </div>
                <p className="text-sm font-medium text-gray-600">{text}</p>
            </div>
        </div>
    );
}

function Panel({ Layout, title, children }) {
    return (
        <Layout>
            <div className="mx-auto max-w-7xl p-6">
                <div className="mb-5 rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                    <h1 className="text-2xl font-semibold text-gray-800">{title}</h1>
                </div>
                {children}
            </div>
        </Layout>
    );
}

function firstValue(row, keys) {
    for (const key of keys) {
        const v = row?.[key];
        if (v !== undefined && v !== null && v !== '') return v;
    }
    return '-';
}

function normalizeRows(payload) {
    if (Array.isArray(payload?.data?.data)) return payload.data.data;
    if (Array.isArray(payload?.data)) return payload.data;
    if (Array.isArray(payload)) return payload;
    return [];
}

function optionFrom(item) {
    return {
        id: item?.id ?? item?.class?.id ?? item?.section?.id ?? item?.subject?.id ?? item?.teacher?.id ?? '',
        name: item?.name
            ?? item?.title
            ?? (item?.first_name || item?.last_name ? `${item?.first_name || ''} ${item?.last_name || ''}`.trim() : '')
            ?? item?.class?.name
            ?? item?.section?.name
            ?? item?.subject?.name
            ?? item?.teacher?.name
            ?? `#${item?.id ?? ''}`,
    };
}

export function AcademicHomePage({ Layout }) {
    const links = [
        ['/classes', 'Classes'],
        ['/sections', 'Sections'],
        ['/subjects', 'Subjects'],
        ['/shifts', 'Shifts'],
        ['/class-rooms', 'Class Rooms'],
        ['/class-setups', 'Class Setups'],
        ['/subject-assigns', 'Subject Assigns'],
        ['/time-schedules', 'Time Schedules'],
        ['/class-routines', 'Class Routines'],
        ['/exam-routines', 'Exam Routines'],
    ];
    return (
        <Panel Layout={Layout} title="Academic">
            <div className="grid grid-cols-1 gap-2 text-sm md:grid-cols-2 lg:grid-cols-3">
                {links.map(([to, label]) => <Link key={to} className="rounded-xl border border-gray-200 bg-white p-3 shadow-sm transition hover:bg-blue-50/40" to={to}>{label}</Link>)}
            </div>
        </Panel>
    );
}

export function AcademicListPage({ Layout, title, endpoint, createTo, editBase, viewBase }) {
    const [rows, setRows] = useState([]);
    const [err, setErr] = useState('');
    const [busyId, setBusyId] = useState(null);
    const [loading, setLoading] = useState(true);
    useEffect(() => {
        setLoading(true);
        axios.get(endpoint, { headers: xhrJson })
            .then((r) => setRows(normalizeRows(r.data)))
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load data.'))
            .finally(() => setLoading(false));
    }, [endpoint]);
    const deleteRow = async (id) => {
        if (!window.confirm('Delete this item?')) return;
        setBusyId(id);
        setErr('');
        try {
            await axios.delete(`${endpoint}/delete/${id}`, { headers: xhrJson });
            setRows((prev) => prev.filter((r) => r.id !== id));
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Failed to delete item.');
        } finally {
            setBusyId(null);
        }
    };
    return (
        <Panel Layout={Layout} title={title}>
            <div className="mb-4 flex justify-end">
                <Link to={createTo} className="rounded-lg bg-blue-600 px-3.5 py-2 text-sm font-medium text-white transition hover:bg-blue-700">Create</Link>
            </div>
            {err ? <p className="mb-2 text-sm text-red-600">{err}</p> : null}
            {loading ? <FullPageLoader text="Loading academic items..." /> : null}
            {!loading ? <div className="overflow-auto rounded-xl border border-gray-200 bg-white shadow-sm">
                <table className="min-w-full text-sm">
                    <thead className="bg-gray-50">
                    <tr className="border-b border-gray-200">
                        <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">#</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Name</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Status</th>
                        <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wide text-gray-600">Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    {rows.map((row, idx) => (
                        <tr key={row.id || idx} className="border-b border-gray-100 transition hover:bg-blue-50/30">
                            <td className="px-4 py-3 font-medium text-gray-700">{idx + 1}</td>
                            <td className="px-4 py-3 text-gray-800">{firstValue(row, ['name', 'title', 'type'])}</td>
                            <td className="px-4 py-3 text-gray-700">{String(firstValue(row, ['status'])) === '1' ? 'Active' : (firstValue(row, ['status']) === '-' ? '-' : 'Inactive')}</td>
                            <td className="px-4 py-3">
                                <div className="flex items-center justify-end gap-2">
                                    <Link to={`${viewBase}/${row.id}`} className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-gray-200 text-blue-600 transition hover:bg-blue-50" title="View">
                                        <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6z" /><circle cx="12" cy="12" r="3" /></svg>
                                    </Link>
                                    <Link to={`${editBase}/${row.id}/edit`} className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-gray-200 text-amber-600 transition hover:bg-amber-50" title="Edit">
                                        <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M12 20h9" /><path strokeLinecap="round" strokeLinejoin="round" d="M16.5 3.5a2.1 2.1 0 113 3L7 19l-4 1 1-4 12.5-12.5z" /></svg>
                                    </Link>
                                    <button type="button" disabled={busyId === row.id} onClick={() => deleteRow(row.id)} className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-gray-200 text-rose-600 transition hover:bg-rose-50 disabled:opacity-60" title="Delete">
                                        <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M3 6h18" /><path strokeLinecap="round" strokeLinejoin="round" d="M8 6V4h8v2" /><path strokeLinecap="round" strokeLinejoin="round" d="M19 6l-1 14H6L5 6" /></svg>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    ))}
                    </tbody>
                </table>
            </div> : null}
        </Panel>
    );
}

export function AcademicFormPage({ Layout, titleCreate, titleEdit, loadEndpoint, storeEndpoint, updateEndpoint, backTo }) {
    const { id } = useParams();
    const edit = Boolean(id);
    const nav = useNavigate();
    const [meta, setMeta] = useState({});
    const [form, setForm] = useState({ name: '', title: '', code: '', status: '1', type: '1', start_time: '', end_time: '' });
    const [sectionIds, setSectionIds] = useState([]);
    const [subjectRows, setSubjectRows] = useState([{ subject: '', teacher: '' }]);
    const [err, setErr] = useState('');
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const isClassSetup = loadEndpoint === '/class-setup';
    const isSubjectAssign = loadEndpoint === '/assign-subject';

    useEffect(() => {
        const url = edit ? `${loadEndpoint}/edit/${id}` : `${loadEndpoint}/create`;
        setLoading(true);
        axios.get(url, { headers: xhrJson })
            .then((r) => {
                const m = r.data?.meta || {};
                setMeta(m);
                if (edit) {
                    setForm((prev) => ({ ...prev, ...(r.data?.data || {}) }));
                    if (isClassSetup) setSectionIds(m.class_setup_sections || []);
                }
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load form.'))
            .finally(() => setLoading(false));
    }, [edit, id, loadEndpoint]);

    useEffect(() => {
        if (!isSubjectAssign) return;
        const loadRows = async () => {
            try {
                if (edit && id) {
                    const r = await axios.get('/assign-subject/show', { headers: xhrJson, params: { id } });
                    const rows = (r.data?.data || []).map((x) => ({ subject: x.subject_id, teacher: x.teacher_id }));
                    setSubjectRows(rows.length ? rows : [{ subject: '', teacher: '' }]);
                } else {
                    const r = await axios.get('/assign-subject/add-subject-teacher', { headers: xhrJson, params: { counter: 1 } });
                    setMeta((m) => ({ ...m, ...(r.data?.meta || {}) }));
                    setSubjectRows([{ subject: '', teacher: '' }]);
                }
            } catch {
                setSubjectRows([{ subject: '', teacher: '' }]);
            }
        };
        loadRows();
    }, [isSubjectAssign, edit, id]);

    const submit = async (e) => {
        e.preventDefault();
        setErr('');
        setSaving(true);
        try {
            const payload = { ...form };
            if (isClassSetup) payload.sections = sectionIds;
            if (isSubjectAssign) {
                payload.subjects = subjectRows.map((r) => r.subject).filter(Boolean);
                payload.teachers = subjectRows.map((r) => r.teacher).filter(Boolean);
            }
            if (edit) await axios.put(`${updateEndpoint}/${id}`, payload, { headers: xhrJson });
            else await axios.post(`${storeEndpoint}`, payload, { headers: xhrJson });
            nav(backTo);
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Save failed.');
        } finally {
            setSaving(false);
        }
    };

    return (
        <Panel Layout={Layout} title={edit ? titleEdit : titleCreate}>
            {err ? <p className="mb-2 text-sm text-red-600">{err}</p> : null}
            {loading ? <FullPageLoader text="Loading form..." /> : null}
            {!loading ? <form onSubmit={submit} className="grid gap-3 rounded-xl border border-gray-200 bg-white p-5 shadow-sm md:grid-cols-2">
                <input className="rounded-lg border border-gray-200 px-3 py-2 text-sm md:col-span-2" placeholder="Name" value={form.name || form.title || ''} onChange={(e) => setForm({ ...form, name: e.target.value, title: e.target.value })} />
                <input className="rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="Code" value={form.code || ''} onChange={(e) => setForm({ ...form, code: e.target.value })} />
                <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={String(form.status ?? '1')} onChange={(e) => setForm({ ...form, status: e.target.value })}>
                    <option value="1">Active</option>
                    <option value="2">Inactive</option>
                </select>
                {(meta.classes || []).length ? (
                    <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={form.classes || form.class || ''} onChange={(e) => setForm({ ...form, classes: e.target.value, class: e.target.value })}>
                        <option value="">Select class</option>
                        {(meta.classes || []).map((i) => { const o = optionFrom(i); return <option key={o.id} value={o.id}>{o.name}</option>; })}
                    </select>
                ) : null}
                {(meta.section || meta.sections || []).length ? (
                    <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={form.section || form.sections || ''} onChange={(e) => setForm({ ...form, section: e.target.value, sections: e.target.value })}>
                        <option value="">Select section</option>
                        {(meta.section || meta.sections || []).map((i) => { const o = optionFrom(i); return <option key={o.id} value={o.id}>{o.name}</option>; })}
                    </select>
                ) : null}
                {isClassSetup && (meta.section || []).length ? (
                    <div className="md:col-span-2 rounded-lg border border-gray-200 p-3">
                        <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-gray-600">Sections</p>
                        <div className="grid gap-2 sm:grid-cols-2">
                            {(meta.section || []).map((s) => {
                                const opt = optionFrom(s);
                                const checked = sectionIds.includes(opt.id);
                                return (
                                    <label key={opt.id} className="inline-flex items-center gap-2 text-sm text-gray-700">
                                        <input
                                            type="checkbox"
                                            checked={checked}
                                            onChange={(e) => {
                                                const on = e.target.checked;
                                                setSectionIds((prev) => on ? [...new Set([...prev, opt.id])] : prev.filter((x) => x !== opt.id));
                                            }}
                                        />
                                        {opt.name}
                                    </label>
                                );
                            })}
                        </div>
                    </div>
                ) : null}
                {(meta.subject || meta.subjects || []).length ? (
                    <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={form.subject || ''} onChange={(e) => setForm({ ...form, subject: e.target.value })}>
                        <option value="">Select subject</option>
                        {(meta.subject || meta.subjects || []).map((i) => { const o = optionFrom(i); return <option key={o.id} value={o.id}>{o.name}</option>; })}
                    </select>
                ) : null}
                {(meta.teachers || []).length ? (
                    <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={form.teacher || ''} onChange={(e) => setForm({ ...form, teacher: e.target.value })}>
                        <option value="">Select teacher</option>
                        {(meta.teachers || []).map((i) => { const o = optionFrom(i); return <option key={o.id} value={o.id}>{o.name}</option>; })}
                    </select>
                ) : null}
                {String(loadEndpoint).includes('/time/schedule') ? (
                    <>
                        <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={String(form.type || '1')} onChange={(e) => setForm({ ...form, type: e.target.value })}>
                            <option value="1">Class</option>
                            <option value="2">Exam</option>
                        </select>
                        <input type="time" className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={form.start_time || ''} onChange={(e) => setForm({ ...form, start_time: e.target.value })} />
                        <input type="time" className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={form.end_time || ''} onChange={(e) => setForm({ ...form, end_time: e.target.value })} />
                    </>
                ) : null}
                {isSubjectAssign ? (
                    <div className="md:col-span-2 rounded-lg border border-gray-200 p-3">
                        <div className="mb-2 flex items-center justify-between">
                            <p className="text-xs font-semibold uppercase tracking-wide text-gray-600">Subject and Teacher</p>
                            <button
                                type="button"
                                className="rounded-lg border border-gray-200 px-2.5 py-1 text-xs font-medium text-gray-700 transition hover:bg-gray-50"
                                onClick={() => setSubjectRows((prev) => [...prev, { subject: '', teacher: '' }])}
                            >
                                Add Row
                            </button>
                        </div>
                        <div className="space-y-2">
                            {subjectRows.map((row, idx) => (
                                <div key={idx} className="grid gap-2 md:grid-cols-[1fr_1fr_auto]">
                                    <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={row.subject || ''} onChange={(e) => setSubjectRows((prev) => prev.map((r, i) => i === idx ? { ...r, subject: e.target.value } : r))}>
                                        <option value="">Select subject</option>
                                        {(meta.subjects || meta.subject || []).map((i) => { const o = optionFrom(i); return <option key={o.id} value={o.id}>{o.name}</option>; })}
                                    </select>
                                    <select className="rounded-lg border border-gray-200 px-3 py-2 text-sm" value={row.teacher || ''} onChange={(e) => setSubjectRows((prev) => prev.map((r, i) => i === idx ? { ...r, teacher: e.target.value } : r))}>
                                        <option value="">Select teacher</option>
                                        {(meta.teachers || []).map((i) => { const o = optionFrom(i); return <option key={o.id} value={o.id}>{o.name}</option>; })}
                                    </select>
                                    <button type="button" className="rounded-lg border border-gray-200 px-3 py-2 text-sm text-rose-600 transition hover:bg-rose-50" onClick={() => setSubjectRows((prev) => prev.length > 1 ? prev.filter((_, i) => i !== idx) : prev)}>
                                        Remove
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>
                ) : null}
                <div className="md:col-span-2 flex justify-end gap-2 border-t border-gray-100 pt-3">
                    <Link to={backTo} className="rounded-lg border border-gray-200 px-3.5 py-2 text-sm font-medium text-gray-700 transition hover:bg-gray-50">Cancel</Link>
                    <button disabled={saving} className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-blue-700 disabled:opacity-60">{saving ? 'Saving...' : (edit ? 'Update' : 'Create')}</button>
                </div>
            </form> : null}
        </Panel>
    );
}

export function AcademicViewPage({ Layout, title, loadEndpoint, backTo, editBase }) {
    const { id } = useParams();
    const [data, setData] = useState(null);
    const [err, setErr] = useState('');
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        let mounted = true;
        const load = async () => {
            setLoading(true);
            try {
                const r = await axios.get(`${loadEndpoint}/edit/${id}`, { headers: xhrJson });
                if (!mounted) return;
                setData(r.data?.data || null);
                setErr('');
            } catch (ex) {
                if (!mounted) return;
                setErr(ex.response?.data?.message || 'Failed to load record.');
            } finally {
                if (mounted) setLoading(false);
            }
        };
        load();
        return () => { mounted = false; };
    }, [id, loadEndpoint]);

    return (
        <Panel Layout={Layout} title={title}>
            {loading ? <FullPageLoader text="Loading record..." /> : null}
            {err ? <p className="mb-3 text-sm text-red-600">{err}</p> : null}
            <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
                <dl className="grid gap-3 text-sm md:grid-cols-2">
                    {Object.entries(data || {}).map(([k, v]) => (
                        <div key={k}>
                            <dt className="text-xs font-semibold uppercase tracking-wide text-gray-500">{k.replace(/_/g, ' ')}</dt>
                            <dd className="mt-1 text-gray-800">{typeof v === 'object' ? JSON.stringify(v) : String(v ?? '-')}</dd>
                        </div>
                    ))}
                </dl>
                <div className="mt-4 flex justify-end gap-2 border-t border-gray-100 pt-3">
                    <Link to={backTo} className="rounded-lg border border-gray-200 px-3.5 py-2 text-sm font-medium text-gray-700 transition hover:bg-gray-50">Back</Link>
                    <Link to={`${editBase}/${id}/edit`} className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-blue-700">Edit</Link>
                </div>
            </div>
        </Panel>
    );
}
