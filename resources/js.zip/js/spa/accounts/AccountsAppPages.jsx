import React, { useEffect, useMemo, useState } from 'react';
import axios from 'axios';
import { Link, useNavigate, useParams } from 'react-router-dom';
import {
    AccountCard,
    AccountEmptyState,
    AccountPageHeader,
    AccountTable,
    AccountTD,
    AccountTH,
    AccountTHead,
    AccountTR,
} from './components/AccountUi';

const xhrJson = { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' };

function AccountFullPageLoader({ text = 'Loading...' }) {
    return (
        <div className="flex min-h-[40vh] items-center justify-center rounded-xl border border-gray-200 bg-white p-8 shadow-sm">
            <div className="flex flex-col items-center gap-3">
                <div className="relative h-10 w-10">
                    <span className="absolute inset-0 rounded-full border-4 border-blue-200" />
                    <span className="absolute inset-0 animate-spin rounded-full border-4 border-transparent border-t-blue-600" />
                </div>
                <p className="text-sm font-medium text-gray-600">{text}</p>
            </div>
        </div>
    );
}

/** Outer chrome matching Fees module (max width + padded shell). */
export function AccountsPageShell({ children }) {
    return <div className="mx-auto max-w-7xl p-6">{children}</div>;
}

/** Card header row: title + optional actions. */
function AccountsSectionHeader({ title, subtitle, actions }) {
    return (
        <div className="mb-5 rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-2xl font-semibold text-gray-800">{title}</h1>
                    {subtitle ? <p className="mt-1 text-sm text-gray-500">{subtitle}</p> : null}
                </div>
                {actions ? <div className="flex flex-wrap items-center gap-2">{actions}</div> : null}
            </div>
        </div>
    );
}

const btnPrimary = 'inline-flex rounded-lg bg-blue-600 px-3.5 py-2 text-sm font-medium text-white shadow-sm transition hover:bg-blue-700';
const btnGhost = 'inline-flex rounded-lg border border-gray-200 px-3.5 py-2 text-sm font-medium text-gray-700 transition hover:bg-gray-50';
const inputClass = 'rounded-lg border border-gray-200 px-3 py-2 text-sm text-gray-900 shadow-inner focus:border-blue-400 focus:outline-none focus:ring-2 focus:ring-blue-100';

function AccountsHomePageComponent({ Layout }) {
    const tiles = useMemo(
        () => [
            { to: '/accounts/chart-of-accounts', title: 'Chart of Accounts', desc: 'Ledger structure', icon: '📒' },
            { to: '/accounts/payment-methods', title: 'Payment Methods', desc: 'How you get paid', icon: '💳' },
            { to: '/accounts/account-heads', title: 'Account Heads', desc: 'Categories for entries', icon: '📄' },
            { to: '/accounts/income', title: 'Income', desc: 'Record income', icon: '📈' },
            { to: '/accounts/expense', title: 'Expense', desc: 'Record expenses', icon: '📉' },
            { to: '/accounts/cash', title: 'Cash', desc: 'Cash position snapshot', icon: '💵' },
            { to: '/accounts/deposits', title: 'Deposits', desc: 'Bank deposits', icon: '🏦' },
            { to: '/accounts/payments', title: 'Payments', desc: 'Outgoing payments', icon: '🧾' },
            { to: '/accounts/transactions', title: 'Transactions', desc: 'Journal-style list', icon: '↔️' },
            { to: '/accounts/suppliers', title: 'Suppliers', desc: 'Vendor directory', icon: '🚚' },
            { to: '/accounts/invoices', title: 'Invoices', desc: 'Billing documents', icon: '📋' },
            { to: '/accounts/product', title: 'Products', desc: 'Inventory & product cash', icon: '📦' },
            { to: '/accounts/item', title: 'Items', desc: 'Stock items', icon: '🏷️' },
            { to: '/accounts/balance', title: 'Balance', desc: 'Account balances', icon: '⚖️' },
        ],
        [],
    );

    return (
        <Layout>
            <AccountsPageShell>
                <AccountsSectionHeader
                    title="Accounts"
                    subtitle="Accounting tools and ledgers in one place — layout aligned with Fees and other admin modules."
                />
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                    {tiles.map((t) => (
                        <Link
                            key={t.to}
                            to={t.to}
                            className="group flex flex-col rounded-xl border border-gray-200 bg-white p-5 shadow-sm transition hover:border-blue-200 hover:shadow-md"
                        >
                            <span className="text-2xl" aria-hidden>
                                {t.icon}
                            </span>
                            <span className="mt-3 text-lg font-semibold text-gray-900 group-hover:text-blue-700">{t.title}</span>
                            <span className="mt-1 text-sm text-gray-500">{t.desc}</span>
                        </Link>
                    ))}
                </div>
            </AccountsPageShell>
        </Layout>
    );
}

function extractRows(responseData) {
    const d = responseData?.data;
    if (Array.isArray(d)) return d;
    if (d && Array.isArray(d.data)) return d.data;
    if (responseData?.data?.data && Array.isArray(responseData.data.data)) return responseData.data.data;
    return [];
}

/** Generic list: name column + edit link + loading. */
function AccountsCrudListPage({ Layout, title, subtitle, endpoint, createTo, rowLabel = (row) => row.name || row.title || `#${row.id}` }) {
    const [rows, setRows] = useState([]);
    const [err, setErr] = useState('');
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        setLoading(true);
        setErr('');
        axios
            .get(endpoint, { headers: xhrJson })
            .then((r) => setRows(extractRows(r.data)))
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load data.'))
            .finally(() => setLoading(false));
    }, [endpoint]);

    return (
        <Layout>
            <AccountsPageShell>
                <AccountsSectionHeader
                    title={title}
                    subtitle={subtitle}
                    actions={
                        createTo ? (
                            <Link to={createTo} className={btnPrimary}>
                                Create
                            </Link>
                        ) : null
                    }
                />
                {err ? <p className="mb-4 text-sm text-red-600">{err}</p> : null}
                {loading ? <AccountFullPageLoader text={`Loading ${title.toLowerCase()}…`} /> : null}
                {!loading ? (
                    <AccountCard>
                        {!rows.length ? (
                            <AccountEmptyState message="No records yet. Create one to get started." />
                        ) : (
                            <AccountTable>
                                <AccountTHead>
                                    <AccountTR>
                                        <AccountTH>Name</AccountTH>
                                        <AccountTH className="text-right">Actions</AccountTH>
                                    </AccountTR>
                                </AccountTHead>
                                <tbody className="divide-y divide-gray-100 bg-white">
                                    {rows.map((row) => (
                                        <AccountTR key={row.id}>
                                            <AccountTD>
                                                <Link className="font-medium text-blue-600 hover:text-blue-800" to={createTo.replace('/create', `/${row.id}/edit`)}>
                                                    {rowLabel(row)}
                                                </Link>
                                            </AccountTD>
                                            <AccountTD className="text-right">
                                                <Link className="text-sm font-medium text-amber-700 hover:text-amber-900" to={createTo.replace('/create', `/${row.id}/edit`)}>
                                                    Edit
                                                </Link>
                                            </AccountTD>
                                        </AccountTR>
                                    ))}
                                </tbody>
                            </AccountTable>
                        )}
                    </AccountCard>
                ) : null}
            </AccountsPageShell>
        </Layout>
    );
}

function AccountsSimpleFormPage({ Layout, title, edit, id, loadPath, storePath, updatePath, backTo, children }) {
    const nav = useNavigate();
    const [form, setForm] = useState({});
    const [meta, setMeta] = useState({});
    const [err, setErr] = useState('');
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        setLoading(true);
        const url = edit ? `${loadPath}/edit/${id}` : `${loadPath}/create`;
        axios
            .get(url, { headers: xhrJson })
            .then((r) => {
                setMeta(r.data?.meta || {});
                if (edit) setForm(r.data?.data || {});
            })
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load form.'))
            .finally(() => setLoading(false));
    }, [edit, id, loadPath]);

    const submit = async (e) => {
        e.preventDefault();
        setSaving(true);
        setErr('');
        try {
            if (edit) await axios.put(`${updatePath}/${id}`, form, { headers: xhrJson });
            else await axios.post(storePath, form, { headers: xhrJson });
            nav(backTo);
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Save failed.');
        } finally {
            setSaving(false);
        }
    };

    return (
        <Layout>
            <AccountsPageShell>
                <AccountsSectionHeader title={title} />
                {err ? <p className="mb-4 text-sm text-red-600">{err}</p> : null}
                {loading ? <AccountFullPageLoader /> : null}
                {!loading ? (
                    <form onSubmit={submit} className="space-y-4 rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
                        {typeof children === 'function' ? children({ form, setForm, meta }) : children}
                        <div className="flex justify-end gap-2 border-t border-gray-100 pt-4">
                            <Link to={backTo} className={btnGhost}>
                                Cancel
                            </Link>
                            <button type="submit" disabled={saving} className={btnPrimary + ' disabled:opacity-60'}>
                                {saving ? 'Saving…' : edit ? 'Update' : 'Create'}
                            </button>
                        </div>
                    </form>
                ) : null}
            </AccountsPageShell>
        </Layout>
    );
}

/* —— Exported pages —— */

export function AccountsHomePage({ Layout }) {
    return <AccountsHomePageComponent Layout={Layout} />;
}

export function ChartOfAccountsPage({ Layout }) {
    return (
        <AccountsCrudListPage
            Layout={Layout}
            title="Chart of Accounts"
            subtitle="Ledger accounts for income, expense, assets, and liabilities."
            endpoint="/chart-of-accounts"
            createTo="/accounts/chart-of-accounts/create"
            rowLabel={(row) => row.name || row.title || `Account #${row.id}`}
        />
    );
}

function chartFormFields({ form, setForm }) {
    return (
        <>
            <input className={inputClass} placeholder="Name" value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            <select className={inputClass} value={form.type || 'income'} onChange={(e) => setForm({ ...form, type: e.target.value })}>
                <option value="income">Income</option>
                <option value="expense">Expense</option>
                <option value="asset">Asset</option>
                <option value="liability">Liability</option>
            </select>
            <input className={inputClass} placeholder="Code" value={form.code || ''} onChange={(e) => setForm({ ...form, code: e.target.value })} />
        </>
    );
}

export function ChartOfAccountsFormPage({ Layout, edit = false }) {
    const { id } = useParams();
    return (
        <AccountsSimpleFormPage
            Layout={Layout}
            title={edit ? 'Edit chart of account' : 'Create chart of account'}
            edit={edit}
            id={id}
            loadPath="/chart-of-accounts"
            storePath="/chart-of-accounts/store"
            updatePath="/chart-of-accounts/update"
            backTo="/accounts/chart-of-accounts"
        >
            {chartFormFields}
        </AccountsSimpleFormPage>
    );
}

export function PaymentMethodsPage({ Layout }) {
    return (
        <AccountsCrudListPage
            Layout={Layout}
            title="Payment Methods"
            subtitle="Tender types and channels used when recording fees and accounting."
            endpoint="/payment-methods"
            createTo="/accounts/payment-methods/create"
        />
    );
}

export function PaymentMethodFormPage({ Layout, edit = false }) {
    const { id } = useParams();
    return (
        <AccountsSimpleFormPage
            Layout={Layout}
            title={edit ? 'Edit payment method' : 'Create payment method'}
            edit={edit}
            id={id}
            loadPath="/payment-methods"
            storePath="/payment-methods/store"
            updatePath="/payment-methods/update"
            backTo="/accounts/payment-methods"
        >
            {({ form, setForm }) => <input className={inputClass} placeholder="Name" value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} />}
        </AccountsSimpleFormPage>
    );
}

export function AccountHeadsPage({ Layout }) {
    return (
        <AccountsCrudListPage
            Layout={Layout}
            title="Account Heads"
            subtitle="Headings used to classify income and expense lines."
            endpoint="/account-head"
            createTo="/accounts/account-heads/create"
        />
    );
}

export function AccountHeadFormPage({ Layout, edit = false }) {
    const { id } = useParams();
    return (
        <AccountsSimpleFormPage
            Layout={Layout}
            title={edit ? 'Edit account head' : 'Create account head'}
            edit={edit}
            id={id}
            loadPath="/account-head"
            storePath="/account-head/store"
            updatePath="/account-head/update"
            backTo="/accounts/account-heads"
        >
            {({ form, setForm }) => <input className={inputClass} placeholder="Name" value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} />}
        </AccountsSimpleFormPage>
    );
}

export function IncomePage({ Layout }) {
    return (
        <AccountsCrudListPage Layout={Layout} title="Income" subtitle="Recorded income entries." endpoint="/income" createTo="/accounts/income/create" />
    );
}

export function IncomeFormPage({ Layout, edit = false }) {
    const { id } = useParams();
    return (
        <AccountsSimpleFormPage
            Layout={Layout}
            title={edit ? 'Edit income' : 'Create income'}
            edit={edit}
            id={id}
            loadPath="/income"
            storePath="/income/store"
            updatePath="/income/update"
            backTo="/accounts/income"
        >
            {({ form, setForm, meta }) => (
                <>
                    <input className={inputClass} placeholder="Name" value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                    <input className={inputClass} placeholder="Amount" value={form.amount || ''} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
                    <select className={inputClass} value={form.income_head || ''} onChange={(e) => setForm({ ...form, income_head: e.target.value })}>
                        <option value="">Select head</option>
                        {(meta.heads || []).map((h) => (
                            <option key={h.id} value={h.id}>
                                {h.name || h.title}
                            </option>
                        ))}
                    </select>
                </>
            )}
        </AccountsSimpleFormPage>
    );
}

export function ExpensePage({ Layout }) {
    return (
        <AccountsCrudListPage Layout={Layout} title="Expense" subtitle="Recorded expense entries." endpoint="/expense" createTo="/accounts/expense/create" />
    );
}

export function ExpenseFormPage({ Layout, edit = false }) {
    const { id } = useParams();
    return (
        <AccountsSimpleFormPage
            Layout={Layout}
            title={edit ? 'Edit expense' : 'Create expense'}
            edit={edit}
            id={id}
            loadPath="/expense"
            storePath="/expense/store"
            updatePath="/expense/update"
            backTo="/accounts/expense"
        >
            {({ form, setForm, meta }) => (
                <>
                    <input className={inputClass} placeholder="Name" value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                    <input className={inputClass} placeholder="Amount" value={form.amount || ''} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
                    <select className={inputClass} value={form.expense_head || ''} onChange={(e) => setForm({ ...form, expense_head: e.target.value })}>
                        <option value="">Select head</option>
                        {(meta.heads || []).map((h) => (
                            <option key={h.id} value={h.id}>
                                {h.name || h.title}
                            </option>
                        ))}
                    </select>
                </>
            )}
        </AccountsSimpleFormPage>
    );
}

/** Payload / JSON report pages with readable layout. */
export function AccountsDataReportPage({ Layout, title, endpoint }) {
    const [payload, setPayload] = useState(null);
    const [err, setErr] = useState('');
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        setLoading(true);
        axios
            .get(endpoint, { headers: xhrJson })
            .then((r) => setPayload(r.data ?? null))
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load.'))
            .finally(() => setLoading(false));
    }, [endpoint]);

    return (
        <Layout>
            <AccountsPageShell>
                <AccountsSectionHeader title={title} subtitle="Live data from the API (read-only in this view)." />
                {err ? <p className="mb-4 text-sm text-red-600">{err}</p> : null}
                {loading ? <AccountFullPageLoader /> : null}
                {!loading && !err ? (
                    <AccountCard className="p-4">
                        <pre className="max-h-[70vh] overflow-auto rounded-lg bg-gray-50 p-4 font-mono text-xs text-gray-800">{JSON.stringify(payload, null, 2)}</pre>
                    </AccountCard>
                ) : null}
            </AccountsPageShell>
        </Layout>
    );
}

export function CashPage({ Layout }) {
    return <AccountsDataReportPage Layout={Layout} title="Cash" endpoint="/cash/cash" />;
}

export function ProductPage({ Layout }) {
    return <AccountsDataReportPage Layout={Layout} title="Product (cash)" endpoint="/product/cash" />;
}

export function ItemPage({ Layout }) {
    return <AccountsDataReportPage Layout={Layout} title="Item (cash)" endpoint="/item/cash" />;
}

export function BalancePage({ Layout }) {
    return <AccountsDataReportPage Layout={Layout} title="Balance" endpoint="/balance/cash" />;
}

export function ProductCreatePage({ Layout }) {
    const nav = useNavigate();
    const [meta, setMeta] = useState({});
    const [form, setForm] = useState({ name: '', quantity: '', price: '' });
    const [err, setErr] = useState('');
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        axios
            .get('/product/create', { headers: xhrJson })
            .then((r) => setMeta(r.data?.meta || {}))
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load form.'))
            .finally(() => setLoading(false));
    }, []);

    const submit = async (e) => {
        e.preventDefault();
        setSaving(true);
        try {
            await axios.post('/product/store', form, { headers: xhrJson });
            nav('/accounts/product');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Save failed.');
        } finally {
            setSaving(false);
        }
    };

    return (
        <Layout>
            <AccountsPageShell>
                <AccountsSectionHeader title={meta.title || 'Create product'} />
                {err ? <p className="mb-4 text-sm text-red-600">{err}</p> : null}
                {loading ? <AccountFullPageLoader /> : null}
                {!loading ? (
                    <form onSubmit={submit} className="space-y-4 rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
                        <input className={inputClass} placeholder="Name" value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                        <input className={inputClass} placeholder="Quantity" value={form.quantity || ''} onChange={(e) => setForm({ ...form, quantity: e.target.value })} />
                        <input className={inputClass} placeholder="Price" value={form.price || ''} onChange={(e) => setForm({ ...form, price: e.target.value })} />
                        <div className="flex justify-end gap-2 border-t border-gray-100 pt-4">
                            <Link to="/accounts/product" className={btnGhost}>
                                Cancel
                            </Link>
                            <button type="submit" disabled={saving} className={btnPrimary + ' disabled:opacity-60'}>
                                {saving ? 'Saving…' : 'Save'}
                            </button>
                        </div>
                    </form>
                ) : null}
            </AccountsPageShell>
        </Layout>
    );
}

export function ProductSellPage({ Layout }) {
    const nav = useNavigate();
    const [meta, setMeta] = useState({});
    const [form, setForm] = useState({ name: '', quantity: '', date: '', receipt: '' });
    const [err, setErr] = useState('');
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        axios
            .get('/product/sell', { headers: xhrJson })
            .then((r) => setMeta(r.data?.meta || {}))
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load form.'))
            .finally(() => setLoading(false));
    }, []);

    const submit = async (e) => {
        e.preventDefault();
        setSaving(true);
        try {
            await axios.post('/product/sellout', form, { headers: xhrJson });
            nav('/accounts/product');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Save failed.');
        } finally {
            setSaving(false);
        }
    };

    return (
        <Layout>
            <AccountsPageShell>
                <AccountsSectionHeader title={meta.title || 'Sell product'} />
                {err ? <p className="mb-4 text-sm text-red-600">{err}</p> : null}
                {loading ? <AccountFullPageLoader /> : null}
                {!loading ? (
                    <form onSubmit={submit} className="space-y-4 rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
                        <select className={inputClass} value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })}>
                            <option value="">Select item</option>
                            {(meta.items || []).map((i) => (
                                <option key={i.id} value={i.id}>
                                    {i.name || i.title}
                                </option>
                            ))}
                        </select>
                        <input className={inputClass} placeholder="Quantity" value={form.quantity || ''} onChange={(e) => setForm({ ...form, quantity: e.target.value })} />
                        <input type="date" className={inputClass} placeholder="Date" value={form.date || ''} onChange={(e) => setForm({ ...form, date: e.target.value })} />
                        <input className={inputClass} placeholder="Receipt" value={form.receipt || ''} onChange={(e) => setForm({ ...form, receipt: e.target.value })} />
                        <div className="flex justify-end gap-2 border-t border-gray-100 pt-4">
                            <Link to="/accounts/product" className={btnGhost}>
                                Cancel
                            </Link>
                            <button type="submit" disabled={saving} className={btnPrimary + ' disabled:opacity-60'}>
                                {saving ? 'Saving…' : 'Save'}
                            </button>
                        </div>
                    </form>
                ) : null}
            </AccountsPageShell>
        </Layout>
    );
}

export function ItemCreatePage({ Layout }) {
    const nav = useNavigate();
    const [meta, setMeta] = useState({});
    const [form, setForm] = useState({ name: '', description: '' });
    const [err, setErr] = useState('');
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        axios
            .get('/item/create', { headers: xhrJson })
            .then((r) => setMeta(r.data?.meta || {}))
            .catch((ex) => setErr(ex.response?.data?.message || 'Failed to load form.'))
            .finally(() => setLoading(false));
    }, []);

    const submit = async (e) => {
        e.preventDefault();
        setSaving(true);
        try {
            await axios.post('/item/store', form, { headers: xhrJson });
            nav('/accounts/item');
        } catch (ex) {
            setErr(ex.response?.data?.message || 'Save failed.');
        } finally {
            setSaving(false);
        }
    };

    return (
        <Layout>
            <AccountsPageShell>
                <AccountsSectionHeader title={meta.title || 'Create item'} />
                {err ? <p className="mb-4 text-sm text-red-600">{err}</p> : null}
                {loading ? <AccountFullPageLoader /> : null}
                {!loading ? (
                    <form onSubmit={submit} className="space-y-4 rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
                        <input className={inputClass} placeholder="Name" value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                        <textarea className={inputClass} placeholder="Description" rows={3} value={form.description || ''} onChange={(e) => setForm({ ...form, description: e.target.value })} />
                        <div className="flex justify-end gap-2 border-t border-gray-100 pt-4">
                            <Link to="/accounts/item" className={btnGhost}>
                                Cancel
                            </Link>
                            <button type="submit" disabled={saving} className={btnPrimary + ' disabled:opacity-60'}>
                                {saving ? 'Saving…' : 'Save'}
                            </button>
                        </div>
                    </form>
                ) : null}
            </AccountsPageShell>
        </Layout>
    );
}
