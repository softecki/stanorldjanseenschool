import React from 'react';

/** Page chrome for accounting lists/forms (Tailwind only). */
export function AccountPageHeader({ title, actions }) {
    return (
        <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <h1 className="text-2xl font-semibold text-gray-800">{title}</h1>
            {actions ? <div className="flex flex-wrap gap-2">{actions}</div> : null}
        </div>
    );
}

export function AccountCard({ children, className = '' }) {
    return <div className={`rounded-xl border border-gray-200 bg-white shadow-sm ${className}`}>{children}</div>;
}

export function AccountTable({ children }) {
    return (
        <div className="overflow-x-auto rounded-xl border border-gray-200 bg-white shadow-sm">
            <table className="min-w-full divide-y divide-gray-200 text-sm">{children}</table>
        </div>
    );
}

export function AccountTHead({ children }) {
    return <thead className="bg-gray-50 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">{children}</thead>;
}

export function AccountTR({ children, className = '' }) {
    return <tr className={`border-b border-gray-100 transition hover:bg-blue-50/30 ${className}`}>{children}</tr>;
}

export function AccountTH({ children, className = '' }) {
    return <th className={`px-4 py-3 ${className}`}>{children}</th>;
}

export function AccountTD({ children, className = '' }) {
    return <td className={`px-4 py-3 text-gray-800 ${className}`}>{children}</td>;
}

export function AccountEmptyState({ message }) {
    return (
        <div className="rounded-xl border border-dashed border-gray-200 bg-gray-50 px-6 py-10 text-center text-sm text-gray-500">
            {message || 'No records yet.'}
        </div>
    );
}

export function AccountFullPageLoader({ text = 'Loading…' }) {
    return (
        <div className="flex min-h-[40vh] items-center justify-center rounded-xl border border-gray-200 bg-white p-8 shadow-sm">
            <div className="flex flex-col items-center gap-3">
                <div className="relative h-10 w-10">
                    <span className="absolute inset-0 rounded-full border-4 border-blue-200" />
                    <span className="absolute inset-0 animate-spin rounded-full border-4 border-transparent border-t-blue-600" />
                </div>
                <p className="text-sm font-medium text-gray-600">{text}</p>
            </div>
        </div>
    );
}
